// file      : odb/boost/details/config.hxx
// license   : GNU GPL v2; see accompanying LICENSE file

#ifndef ODB_BOOST_DETAILS_CONFIG_HXX
#define ODB_BOOST_DETAILS_CONFIG_HXX

// no pre

#ifdef ODB_COMPILER
#  define LIBODB_BOOST_STATIC
#endif

// no post

#endif // ODB_BOOST_DETAILS_CONFIG_HXX
