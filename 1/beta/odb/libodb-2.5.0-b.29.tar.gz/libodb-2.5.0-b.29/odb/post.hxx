// file      : odb/post.hxx
// license   : GNU GPL v2; see accompanying LICENSE file

#ifdef _MSC_VER
#  pragma warning (pop)
#endif
