// file      : evolution/alter-column/test2.hxx
// license   : GNU GPL v2; see accompanying LICENSE file

#ifndef TEST2_HXX
#define TEST2_HXX

#define MODEL_VERSION 2
#include "model.hxx"
#undef MODEL_VERSION

#endif // TEST2_HXX
