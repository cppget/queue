// file      : odb/oracle/details/config.hxx
// license   : ODB NCUEL; see accompanying LICENSE file

#ifndef ODB_ORACLE_DETAILS_CONFIG_HXX
#define ODB_ORACLE_DETAILS_CONFIG_HXX

// no pre

#ifdef ODB_COMPILER
#  error libodb-oracle header included in odb-compiled header
#endif

// no post

#endif // ODB_ORACLE_DETAILS_CONFIG_HXX
