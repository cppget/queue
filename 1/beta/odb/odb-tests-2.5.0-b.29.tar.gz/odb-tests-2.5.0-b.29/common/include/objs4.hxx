// file      : common/include/objs1.hxx
// license   : GNU GPL v2; see accompanying LICENSE file

#ifndef OBJS4_HXX
#define OBJS4_HXX

#include <common/include/obj1.hxx>
#include <common/include/obj2.hxx>
#include <common/include/obj3.hxx>

#endif // OBJS4_HXX
