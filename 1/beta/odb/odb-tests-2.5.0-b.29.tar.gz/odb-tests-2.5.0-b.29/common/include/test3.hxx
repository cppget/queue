// file      : common/include/test3.hxx
// license   : GNU GPL v2; see accompanying LICENSE file

#ifndef TEST3_HXX
#define TEST3_HXX

// Test preference of longer (more qualified) paths.
//
#include "objs2.hxx"
#include "objs3.hxx"

#endif // TEST3_HXX
