// file      : evolution/data/test3.hxx
// license   : GNU GPL v2; see accompanying LICENSE file

#ifndef TEST3_HXX
#define TEST3_HXX

#define MODEL_VERSION 3
#include "model.hxx"
#undef MODEL_VERSION

#endif // TEST3_HXX
