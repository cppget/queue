// file      : odb/mssql/statements-base.cxx
// copyright : Copyright (c) 2005-2019 Code Synthesis Tools CC
// license   : ODB NCUEL; see accompanying LICENSE file

#include <odb/mssql/statements-base.hxx>

namespace odb
{
  namespace mssql
  {
    statements_base::
    ~statements_base ()
    {
    }
  }
}
