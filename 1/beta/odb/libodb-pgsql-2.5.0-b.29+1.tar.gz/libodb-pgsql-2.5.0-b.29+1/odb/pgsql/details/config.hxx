// file      : odb/pgsql/details/config.hxx
// license   : GNU GPL v2; see accompanying LICENSE file

#ifndef ODB_PGSQL_DETAILS_CONFIG_HXX
#define ODB_PGSQL_DETAILS_CONFIG_HXX

// no pre

#ifdef ODB_COMPILER
#  error libodb-pgsql header included in odb-compiled header
#endif

// no post

#endif // ODB_PGSQL_DETAILS_CONFIG_HXX
