// file      : odb/mssql/simple-object-statements.cxx
// license   : ODB NCUEL; see accompanying LICENSE file

#include <odb/mssql/simple-object-statements.hxx>

namespace odb
{
  namespace mssql
  {
    object_statements_base::
    ~object_statements_base ()
    {
    }
  }
}
