// file      : odb/mssql/prepared-query.cxx
// license   : ODB NCUEL; see accompanying LICENSE file

#include <odb/mssql/prepared-query.hxx>

namespace odb
{
  namespace mssql
  {
    prepared_query_impl::
    ~prepared_query_impl ()
    {
    }
  }
}
