// file      : odb/pgsql/statements-base.cxx
// copyright : Copyright (c) 2005-2019 Code Synthesis Tools CC
// license   : GNU GPL v2; see accompanying LICENSE file

#include <odb/pgsql/statements-base.hxx>

namespace odb
{
  namespace pgsql
  {
    statements_base::
    ~statements_base ()
    {
    }
  }
}
