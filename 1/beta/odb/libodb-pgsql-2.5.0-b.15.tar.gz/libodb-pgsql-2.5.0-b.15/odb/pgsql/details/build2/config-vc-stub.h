/* file      : odb/pgsql/details/build2/config-vc-stub.h
 * copyright : Copyright (c) 2009-2019 Code Synthesis Tools CC
 * license   : GNU GPL v2; see accompanying LICENSE file
 */

#include <odb/pgsql/details/config-vc.h>
