#include <plf_colony.h>

int main()
{
    
}