# libbitmagic

C++ library
