#define BM64ADDR
#include "bm.h"
