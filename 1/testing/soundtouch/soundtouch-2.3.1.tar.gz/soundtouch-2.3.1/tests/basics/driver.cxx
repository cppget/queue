#include <soundtouch/SoundTouch.h>

int main() {
  soundtouch::SoundTouch lib;
  return 0;
}
