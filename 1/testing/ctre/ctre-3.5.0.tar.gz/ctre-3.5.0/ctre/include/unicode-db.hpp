#ifndef CTRE_V2__UNICODE_CODE_DB__HPP
#define CTRE_V2__UNICODE_CODE_DB__HPP

#include "unicode-db/unicode-db.hpp"

#endif
