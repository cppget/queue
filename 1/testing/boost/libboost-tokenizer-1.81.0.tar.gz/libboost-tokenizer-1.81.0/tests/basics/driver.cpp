#include <boost/tokenizer.hpp>

int
main ()
{
  return 0;
}
