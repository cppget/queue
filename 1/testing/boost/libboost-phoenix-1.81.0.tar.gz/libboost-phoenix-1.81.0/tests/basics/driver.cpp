#include <boost/phoenix/phoenix.hpp>

int
main ()
{
  return 0;
}
