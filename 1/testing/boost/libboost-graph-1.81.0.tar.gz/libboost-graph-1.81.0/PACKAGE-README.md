# libboost-graph

The `build2` package of `libboost-graph` supports the following configuration
variables:


### `config.libboost_graph.graphviz`

Enable graphviz input support. Default is `false`. Note that enabling this
support will cause the package to depend on `libboost-regex`.
