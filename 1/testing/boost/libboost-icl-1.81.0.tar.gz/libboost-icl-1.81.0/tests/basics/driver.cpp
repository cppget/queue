#include <boost/icl/closed_interval.hpp>
#include <boost/icl/continuous_interval.hpp>
#include <boost/icl/discrete_interval.hpp>
#include <boost/icl/dynamic_interval_traits.hpp>
#include <boost/icl/functors.hpp>
#include <boost/icl/gregorian.hpp>
#include <boost/icl/impl_config.hpp>
#include <boost/icl/interval_base_set.hpp>
#include <boost/icl/interval_bounds.hpp>
#include <boost/icl/interval_combining_style.hpp>
#include <boost/icl/interval.hpp>
#include <boost/icl/interval_map.hpp>
#include <boost/icl/interval_set.hpp>
#include <boost/icl/interval_traits.hpp>
#include <boost/icl/iterator.hpp>
#include <boost/icl/left_open_interval.hpp>
#include <boost/icl/map.hpp>
#include <boost/icl/open_interval.hpp>
#include <boost/icl/ptime.hpp>
#include <boost/icl/rational.hpp>
#include <boost/icl/right_open_interval.hpp>
#include <boost/icl/separate_interval_set.hpp>
#include <boost/icl/set.hpp>
#include <boost/icl/split_interval_map.hpp>
#include <boost/icl/split_interval_set.hpp>

int
main ()
{
  return 0;
}
