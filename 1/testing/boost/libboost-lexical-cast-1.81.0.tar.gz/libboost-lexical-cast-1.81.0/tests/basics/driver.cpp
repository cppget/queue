#include <boost/lexical_cast.hpp>

int
main ()
{
  return 0;
}
