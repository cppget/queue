#include <boost/foreach.hpp>

int
main ()
{
  return 0;
}
