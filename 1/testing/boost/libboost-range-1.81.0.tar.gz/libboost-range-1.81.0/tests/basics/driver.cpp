#include <boost/range.hpp>

int
main ()
{
  return 0;
}
