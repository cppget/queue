#include <boost/bimap.hpp>

int
main ()
{
  return 0;
}
