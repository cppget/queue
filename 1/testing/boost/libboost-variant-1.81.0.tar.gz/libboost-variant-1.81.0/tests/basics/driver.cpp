#include <boost/variant.hpp>

int
main ()
{
  return 0;
}
