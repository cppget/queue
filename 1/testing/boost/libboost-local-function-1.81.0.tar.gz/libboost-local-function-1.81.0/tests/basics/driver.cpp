#include <boost/local_function.hpp>

int
main ()
{
  return 0;
}
