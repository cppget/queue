#include <boost/functional.hpp>

int
main ()
{
  return 0;
}
