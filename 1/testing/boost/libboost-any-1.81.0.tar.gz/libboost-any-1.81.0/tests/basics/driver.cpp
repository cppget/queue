#include <boost/any.hpp>

int
main ()
{
  return 0;
}
