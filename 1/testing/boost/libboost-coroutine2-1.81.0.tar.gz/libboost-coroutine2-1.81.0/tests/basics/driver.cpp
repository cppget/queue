#include <boost/coroutine2/all.hpp>
#include <boost/coroutine2/coroutine.hpp>
#include <boost/coroutine2/fixedsize_stack.hpp>
#include <boost/coroutine2/pooled_fixedsize_stack.hpp>
#include <boost/coroutine2/protected_fixedsize_stack.hpp>
#include <boost/coroutine2/segmented_stack.hpp>

int
main ()
{
  return 0;
}
