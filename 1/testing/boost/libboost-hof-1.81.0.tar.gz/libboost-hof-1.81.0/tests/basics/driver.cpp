#include <boost/hof.hpp>

int
main ()
{
  return 0;
}
