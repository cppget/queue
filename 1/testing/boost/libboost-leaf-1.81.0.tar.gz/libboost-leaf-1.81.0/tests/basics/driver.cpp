#include <boost/leaf.hpp>

int
main ()
{
  return 0;
}
