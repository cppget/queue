#include <boost/assert.hpp>

int
main ()
{
  return 0;
}
