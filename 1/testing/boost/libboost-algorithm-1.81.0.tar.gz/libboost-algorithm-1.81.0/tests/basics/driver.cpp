#include <boost/algorithm/algorithm.hpp>

int
main ()
{
  return 0;
}
