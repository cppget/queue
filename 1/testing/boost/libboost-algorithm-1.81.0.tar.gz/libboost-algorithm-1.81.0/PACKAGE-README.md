# libboost-algorithm

The `build2` package of `libboost-algorithm` supports the following
configuration variables:


### `config.libboost_algorithm.regex`

Enable regex support. Default is `false`. Note that enabling this support will
cause the package to depend on `libboost-regex`.
