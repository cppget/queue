#include <boost/circular_buffer.hpp>

int
main ()
{
  return 0;
}
