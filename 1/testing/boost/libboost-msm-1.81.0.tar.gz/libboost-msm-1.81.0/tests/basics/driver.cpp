#include <boost/msm/active_state_switching_policies.hpp>
#include <boost/msm/common.hpp>
#include <boost/msm/event_traits.hpp>
#include <boost/msm/msm_grammar.hpp>
#include <boost/msm/proto_config.hpp>
#include <boost/msm/row_tags.hpp>

int
main ()
{
  return 0;
}
