#include <boost/static_string/static_string.hpp>

int
main ()
{
  return 0;
}
