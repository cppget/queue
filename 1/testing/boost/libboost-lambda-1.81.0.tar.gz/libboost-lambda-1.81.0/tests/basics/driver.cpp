#include <boost/lambda/lambda.hpp>

int
main ()
{
  return 0;
}
