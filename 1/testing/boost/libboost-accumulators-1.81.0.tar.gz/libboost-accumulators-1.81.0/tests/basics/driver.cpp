#include <boost/accumulators/accumulators.hpp>

int
main ()
{
  return 0;
}
