#include <boost/qvm.hpp>

int
main ()
{
  return 0;
}
