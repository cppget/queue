#include <boost/hana.hpp>

int
main ()
{
  return 0;
}
