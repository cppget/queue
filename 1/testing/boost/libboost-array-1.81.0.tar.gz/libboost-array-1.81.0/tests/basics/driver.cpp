#include <boost/array.hpp>

int
main ()
{
  return 0;
}
