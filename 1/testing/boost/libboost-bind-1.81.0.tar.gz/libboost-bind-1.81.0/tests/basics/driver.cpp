#include <boost/bind/bind.hpp>

int
main ()
{
  return 0;
}
