#include <boost/preprocessor.hpp>

int
main ()
{
  return 0;
}
