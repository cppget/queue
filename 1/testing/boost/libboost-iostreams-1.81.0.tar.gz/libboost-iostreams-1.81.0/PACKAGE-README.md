# libboost-iostreams

The `build2` package of `libboost-iostreams` supports the following
configuration variables:


### `config.libboost_iostreams.regex`

Enable regex support. Default is `false`. Note that enabling this support will
cause the package to depend on `libboost-regex`.
