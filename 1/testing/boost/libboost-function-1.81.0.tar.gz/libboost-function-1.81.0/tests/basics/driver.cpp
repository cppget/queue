#include <boost/function.hpp>

int
main ()
{
  return 0;
}
