#include <boost/polygon/polygon.hpp>

int
main ()
{
  return 0;
}
