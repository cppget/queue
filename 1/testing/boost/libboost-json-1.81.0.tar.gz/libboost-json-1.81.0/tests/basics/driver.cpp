#include <boost/json.hpp>

int
main ()
{
  boost::json::array a;
  a = { 1, 2, 3 };
  return 0;
}
