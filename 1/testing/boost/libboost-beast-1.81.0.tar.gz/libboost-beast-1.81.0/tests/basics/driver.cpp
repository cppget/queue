#include <boost/beast.hpp>

int
main ()
{
  return 0;
}
