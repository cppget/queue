#include <boost/numeric/interval.hpp>

int
main ()
{
  return 0;
}
