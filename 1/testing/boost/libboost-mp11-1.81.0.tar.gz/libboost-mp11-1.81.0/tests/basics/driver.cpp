#include <boost/mp11.hpp>

int
main ()
{
  return 0;
}
