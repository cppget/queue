#include <boost/function_types/components.hpp>
#include <boost/function_types/function_arity.hpp>
#include <boost/function_types/function_pointer.hpp>
#include <boost/function_types/function_reference.hpp>
#include <boost/function_types/function_type.hpp>
#include <boost/function_types/is_callable_builtin.hpp>
#include <boost/function_types/is_function.hpp>
#include <boost/function_types/is_function_pointer.hpp>
#include <boost/function_types/is_function_reference.hpp>
#include <boost/function_types/is_member_function_pointer.hpp>
#include <boost/function_types/is_member_object_pointer.hpp>
#include <boost/function_types/is_member_pointer.hpp>
#include <boost/function_types/is_nonmember_callable_builtin.hpp>
#include <boost/function_types/member_function_pointer.hpp>
#include <boost/function_types/member_object_pointer.hpp>
#include <boost/function_types/parameter_types.hpp>
#include <boost/function_types/property_tags.hpp>
#include <boost/function_types/result_type.hpp>

int
main ()
{
  return 0;
}
