#include <boost/static_assert.hpp>

int
main ()
{
  return 0;
}
