#include <boost/typeof/typeof.hpp>

int
main ()
{
  return 0;
}
