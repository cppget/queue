#include <boost/ptr_container/ptr_container.hpp>

int
main ()
{
  return 0;
}
