#include <boost/type_index.hpp>

int
main ()
{
  return 0;
}
