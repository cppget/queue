#include <boost/outcome.hpp>

int
main ()
{
  return 0;
}
