#include <boost/variant2.hpp>

int
main ()
{
  return 0;
}
