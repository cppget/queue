#include <libhornsignal/version.hxx>
#include <libhornsignal/hornsignal.hxx>

#include <cassert>
#include <chrono>
#include <iostream>
#include <stdexcept>
#include <string>

using namespace hornsignal;
using ms = std::chrono::milliseconds;

static int failures = 0;

static void
expect (bool cond, const char* what)
{
  if (!cond)
  {
    std::cerr << "FAIL: " << what << '\n';
    ++failures;
  }
}

static pattern
must_parse (std::string_view text)
{
  auto r = parse (text);
  expect (r.ok && r.value.has_value (), "parse should succeed");
  if (!r.ok || !r.value)
    return {};
  return *r.value;
}

int
main ()
{
  expect (std::string (LIBHORNSIGNAL_VERSION_STR) == "1.0.0",
          "package version is 1.0.0");

  // Catalog has all eight GCOR 5.8.2 signals, in rule order.
  const auto& cat = catalog ();
  expect (cat.size () == 8, "catalog size is 8");
  for (int i = 0; i < 8; ++i)
    expect (cat[static_cast<std::size_t> (i)].id == i + 1, "catalog id order");

  expect (cat[0].kind == pattern_kind::succession, "signal 1 is succession");
  expect (cat[2].name == "Proceed", "signal 3 name");
  expect (cat[2].notation == "- -", "signal 3 notation is two long");
  expect (cat[3].name == "Acknowledgment", "signal 4 name");
  expect (cat[3].notation == "o o", "signal 4 notation is two short");
  expect (cat[6].name == "Grade crossing", "signal 7 name");
  expect (cat[6].notation == "- - o -", "signal 7 notation");

  // Spaced GCOR notation.
  {
    auto p = must_parse ("- - o -");
    expect (p.kind == pattern_kind::counted, "grade kind");
    expect (p.blasts.size () == 4, "grade has 4 blasts");
    expect (p.blasts[0] == blast::long_blast &&
            p.blasts[1] == blast::long_blast &&
            p.blasts[2] == blast::short_blast &&
            p.blasts[3] == blast::long_blast,
            "grade blast sequence");
    auto sig = lookup (p);
    expect (sig && sig->id == 7 && sig->name == "Grade crossing",
            "lookup grade crossing");
    expect (to_notation (p) == "- - o -", "round-trip grade notation");
  }

  // Compact notation, proceed and acknowledge (the easy mix-up).
  {
    auto proceed = must_parse ("--");
    auto ack = must_parse ("oo");
    expect (lookup (proceed) && lookup (proceed)->id == 3, "compact proceed");
    expect (lookup (ack) && lookup (ack)->id == 4, "compact acknowledge");
    expect (to_notation (proceed) == "- -", "proceed notation");
    expect (to_notation (ack) == "o o", "ack notation");
  }

  // Word forms and typographic en-dash (UTF-8 U+2013).
  {
    auto p1 = must_parse ("long long short long");
    expect (lookup (p1) && lookup (p1)->id == 7, "word-form grade crossing");
    const std::string en = "\xE2\x80\x93 \xE2\x80\x93 o \xE2\x80\x93";
    auto p2 = must_parse (en);
    expect (lookup (p2) && lookup (p2)->id == 7, "en-dash grade crossing");
  }

  // Remaining standard signals, including aliases.
  expect (identify ("brakes applied").signal &&
          identify ("brakes applied").signal->id == 2,
          "alias brakes applied");
  expect (identify ("-").signal && identify ("-").signal->id == 2,
          "one long");
  expect (identify ("proceed").signal && identify ("proceed").signal->id == 3,
          "name proceed");
  expect (identify ("acknowledge").signal &&
          identify ("acknowledge").signal->id == 4,
          "alias acknowledge");
  expect (identify ("o o o").signal && identify ("o o o").signal->id == 5,
          "backing");
  expect (identify ("four short").signal &&
          identify ("four short").signal->id == 6,
          "alias four short");
  expect (identify ("- o").signal && identify ("- o").signal->id == 8,
          "men or equipment");

  // Succession: five or more shorts, and the emergency name.
  {
    auto s5 = must_parse ("o o o o o");
    expect (s5.kind == pattern_kind::succession, "five shorts is succession");
    expect (s5.blasts.empty (), "succession stores no fixed count");
    expect (lookup (s5) && lookup (s5)->id == 1, "succession is emergency");
    expect (to_notation (s5) == "o o o o o …", "succession notation");
    auto s8 = must_parse ("oooooooo");
    expect (s8.kind == pattern_kind::succession, "eight compact shorts");
    expect (identify ("emergency").signal &&
            identify ("emergency").signal->id == 1,
            "name emergency");
  }

  // Four shorts is request-signal, not succession.
  {
    auto p = must_parse ("o o o o");
    expect (p.kind == pattern_kind::counted && p.blasts.size () == 4,
            "four shorts stay counted");
    expect (lookup (p) && lookup (p)->id == 6, "four shorts is request");
  }

  // Well-formed but non-standard pattern.
  {
    auto r = identify ("o");
    expect (r.ok && r.value && r.value->blasts.size () == 1, "single short ok");
    expect (!r.signal, "single short is not a GCOR 5.8.2 signal");
  }

  // Invalid input.
  expect (!parse ("").ok, "empty fails");
  expect (!parse ("   ").ok, "whitespace fails");
  expect (!identify ("").ok, "empty identify fails");
  expect (!parse ("- - x -").ok, "unknown character fails");
  expect (!parse ("toot toot").ok, "unknown words fail");
  expect (!lookup_by_name ("not a signal"), "unknown name");
  expect (!valid (pattern {}), "default empty pattern is invalid");

  // Duration helper: long=3s, short=1s, pause=1s (library defaults).
  // Grade crossing - - o - : 3+1 + 3+1 + 1+1 + 3 = 13s.
  {
    auto grade = must_parse ("- - o -");
    expect (duration (grade) == ms {13000}, "default grade duration 13s");
    timing custom {ms {200}, ms {800}, ms {100}};
    // 800+100 + 800+100 + 200+100 + 800 = 2900
    expect (duration (grade, custom) == ms {2900}, "custom grade duration");
    auto proceed = must_parse ("- -");
    expect (duration (proceed) == ms {7000}, "proceed 3+1+3");
    auto ack = must_parse ("o o");
    expect (duration (ack) == ms {3000}, "ack 1+1+1");
    auto one = must_parse ("-");
    expect (duration (one) == ms {3000}, "single long has no pause");
    auto emerg = must_parse ("o o o o o");
    // 8 shorts by default: 8*1000 + 7*1000 = 15000
    expect (duration (emerg) == ms {15000}, "succession default 8 shorts");
    expect (duration (emerg, {}, 5) == ms {9000}, "succession of 5");
  }

  try
  {
    duration (pattern {});
    expect (false, "empty pattern duration should throw");
  }
  catch (const std::invalid_argument&)
  {
  }

  try
  {
    auto emerg = must_parse ("oooooo");
    duration (emerg, {}, 0);
    expect (false, "zero succession_count should throw");
  }
  catch (const std::invalid_argument&)
  {
  }

  if (failures != 0)
  {
    std::cerr << failures << " check(s) failed\n";
    return 1;
  }

  std::cout << "libhornsignal tests passed\n";
  return 0;
}
