#include <libhornsignal/hornsignal.hxx>

#include <algorithm>
#include <cstdint>
#include <cctype>
#include <stdexcept>
#include <utility>

namespace hornsignal
{
  namespace
  {
    bool
    is_dash (char c) noexcept
    {
      // ASCII hyphen-minus is the canonical dash. Typographic dashes
      // are normalized to this character before tokenization.
      return c == '-';
    }

    // Replace common typographic dashes with ASCII '-'. The input is
    // UTF-8; we only rewrite well-known 2- and 3-byte dash code points.
    //
    std::string
    normalize_dashes (std::string_view in)
    {
      std::string out;
      out.reserve (in.size ());
      const auto n = in.size ();
      for (std::size_t i = 0; i < n; )
      {
        const unsigned char c = static_cast<unsigned char> (in[i]);
        // U+2010 HYPHEN, U+2011 NON-BREAKING HYPHEN,
        // U+2012 FIGURE DASH, U+2013 EN DASH, U+2014 EM DASH,
        // U+2015 HORIZONTAL BAR: all e2 80 90..95
        if (c == 0xe2 && i + 2 < n &&
            static_cast<unsigned char> (in[i + 1]) == 0x80 &&
            static_cast<unsigned char> (in[i + 2]) >= 0x90 &&
            static_cast<unsigned char> (in[i + 2]) <= 0x95)
        {
          out.push_back ('-');
          i += 3;
          continue;
        }
        // U+2212 MINUS SIGN: e2 88 92
        if (c == 0xe2 && i + 2 < n &&
            static_cast<unsigned char> (in[i + 1]) == 0x88 &&
            static_cast<unsigned char> (in[i + 2]) == 0x92)
        {
          out.push_back ('-');
          i += 3;
          continue;
        }
        // U+2012.. already covered. U+FE58 SMALL EM DASH: ef b9 98
        if (c == 0xef && i + 2 < n &&
            static_cast<unsigned char> (in[i + 1]) == 0xb9 &&
            static_cast<unsigned char> (in[i + 2]) == 0x98)
        {
          out.push_back ('-');
          i += 3;
          continue;
        }
        out.push_back (in[i]);
        ++i;
      }
      return out;
    }

    std::string
    to_lower_ascii (std::string s)
    {
      for (char& c : s)
      {
        if (static_cast<unsigned char> (c) < 128)
          c = static_cast<char> (std::tolower (static_cast<unsigned char> (c)));
      }
      return s;
    }

    // Collapse runs of space, and treat -, _, / as spaces for name keys.
    //
    std::string
    normalize_key (std::string_view raw)
    {
      std::string s = to_lower_ascii (normalize_dashes (raw));
      std::string out;
      out.reserve (s.size ());
      bool prev_space = false;
      for (char c : s)
      {
        if (c == '-' || c == '_' || c == '/' ||
            c == '\t' || c == '\n' || c == '\r' || c == ' ')
        {
          if (!out.empty () && !prev_space)
          {
            out.push_back (' ');
            prev_space = true;
          }
          continue;
        }
        out.push_back (c);
        prev_space = false;
      }
      if (!out.empty () && out.back () == ' ')
        out.pop_back ();
      return out;
    }

    std::vector<std::string_view>
    split_tokens (std::string_view s)
    {
      std::vector<std::string_view> tokens;
      std::size_t i = 0;
      const auto n = s.size ();
      auto is_sep = [] (char c)
      {
        return c == ' ' || c == '\t' || c == '\n' || c == '\r' ||
               c == ',' || c == ';' || c == '|';
      };
      while (i < n)
      {
        while (i < n && is_sep (s[i]))
          ++i;
        if (i >= n)
          break;
        const std::size_t start = i;
        while (i < n && !is_sep (s[i]))
          ++i;
        tokens.emplace_back (s.data () + start, i - start);
      }
      return tokens;
    }

    bool
    is_long_word (std::string_view w) noexcept
    {
      return w == "long" || w == "l" || w == "dash";
    }

    bool
    is_short_word (std::string_view w) noexcept
    {
      return w == "short" || w == "s" || w == "o" || w == "dot";
    }

    pattern
    maybe_succession (std::vector<blast> blasts)
    {
      pattern p;
      if (blasts.size () >= 5 &&
          std::all_of (blasts.begin (), blasts.end (),
                       [] (blast b) { return b == blast::short_blast; }))
      {
        p.kind = pattern_kind::succession;
        return p;
      }
      p.kind = pattern_kind::counted;
      p.blasts = std::move (blasts);
      return p;
    }

    bool
    pattern_equal (const pattern& a, const pattern& b) noexcept
    {
      if (a.kind != b.kind)
        return false;
      if (a.kind == pattern_kind::succession)
        return true;
      return a.blasts == b.blasts;
    }

    pattern
    pattern_from_signal (const named_signal& s)
    {
      pattern p;
      p.kind = s.kind;
      p.blasts = s.blasts;
      return p;
    }

    // Catalog is initialized once. string_view members point at these
    // literals, which have static storage duration.
    //
    const std::vector<named_signal>&
    built_catalog ()
    {
      static const std::vector<named_signal> k = {
        named_signal {
          1,
          "Emergency warning",
          "o o o o o …",
          "Use when persons or livestock are on the track at other than "
          "road crossings at grade. In addition, use to warn railroad "
          "employees when an emergency exists, such as a derailment. "
          "When crews on other trains hear this signal, they must stop "
          "until it is safe to proceed.",
          "The number of short sounds is not fixed; it is a succession, "
          "not a counted pattern.",
          pattern_kind::succession,
          {}
        },
        named_signal {
          2,
          "Brakes applied",
          "-",
          "When stopped: air brakes are applied, pressure equalized.",
          "",
          pattern_kind::counted,
          {blast::long_blast}
        },
        named_signal {
          3,
          "Proceed",
          "- -",
          "Release brakes. Proceed.",
          "Under GCOR 5.8.2 this is two long sounds, not two short. "
          "Two short sounds are the acknowledgment signal (signal 4).",
          pattern_kind::counted,
          {blast::long_blast, blast::long_blast}
        },
        named_signal {
          4,
          "Acknowledgment",
          "o o",
          "Acknowledgment of any signal not otherwise provided for.",
          "",
          pattern_kind::counted,
          {blast::short_blast, blast::short_blast}
        },
        named_signal {
          5,
          "Backing",
          "o o o",
          "When stopped: back up. Acknowledgment of a hand signal to back up.",
          "",
          pattern_kind::counted,
          {blast::short_blast, blast::short_blast, blast::short_blast}
        },
        named_signal {
          6,
          "Request signal",
          "o o o o",
          "Request for a signal to be given or repeated if not understood.",
          "",
          pattern_kind::counted,
          {blast::short_blast, blast::short_blast,
           blast::short_blast, blast::short_blast}
        },
        named_signal {
          7,
          "Grade crossing",
          "- - o -",
          "When approaching public crossings at grade with the engine in "
          "front. Prolong or repeat the signal until the engine completely "
          "occupies the crossing(s).",
          "GCOR 5.8.2(7) timing: at more than 45 mph, start at or about "
          "the crossing sign but not more than 1/4 mile before the crossing; "
          "at 45 mph or less, start at least 15 seconds but not more than "
          "20 seconds before entering the crossing (and not more than 1/4 "
          "mile before it). FRA 49 CFR Part 222 likewise requires this "
          "two-long, one-short, one-long pattern, sounded 15-20 seconds "
          "before a public grade crossing and not more than 1/4 mile in "
          "advance (with a 1/4-mile cap when speed would otherwise make "
          "the warning shorter).",
          pattern_kind::counted,
          {blast::long_blast, blast::long_blast,
           blast::short_blast, blast::long_blast}
        },
        named_signal {
          8,
          "Approaching men or equipment",
          "- o",
          "Approaching men or equipment on or near the track, regardless "
          "of any whistle prohibitions. After this initial warning, sound "
          "whistle signal (4) (two short) intermittently until the head "
          "end of the train has passed the men or equipment.",
          "",
          pattern_kind::counted,
          {blast::long_blast, blast::short_blast}
        }
      };
      return k;
    }

    const char* const name_aliases[][12] = {
      // id 1
      {"emergency", "emergency warning", "succession",
       "succession of short sounds", "persons or livestock", "livestock",
       nullptr},
      // id 2
      {"brakes applied", "air brakes applied", "stopped brakes",
       "pressure equalized", "one long", nullptr},
      // id 3
      {"proceed", "release brakes", "release brakes proceed",
       "two long", "2 long", nullptr},
      // id 4
      {"acknowledgment", "acknowledgement", "acknowledge",
       "two short", "2 short", nullptr},
      // id 5
      {"backing", "back up", "backup", "back-up",
       "three short", "3 short", nullptr},
      // id 6
      {"request signal", "request for signal", "repeat signal",
       "four short", "4 short", nullptr},
      // id 7
      {"grade crossing", "public crossing", "crossing",
       "highway crossing", "public grade crossing",
       "long long short long", nullptr},
      // id 8
      {"men or equipment", "approaching men or equipment",
       "roadway workers", "workers on track", "equipment on track",
       "long short", nullptr}
    };
  }

  parse_result
  parse (std::string_view text)
  {
    parse_result r;
    r.query = std::string (text);

    // Trim.
    std::size_t begin = 0;
    std::size_t end = text.size ();
    while (begin < end &&
           (text[begin] == ' ' || text[begin] == '\t' ||
            text[begin] == '\n' || text[begin] == '\r'))
      ++begin;
    while (end > begin &&
           (text[end - 1] == ' ' || text[end - 1] == '\t' ||
            text[end - 1] == '\n' || text[end - 1] == '\r'))
      --end;

    if (begin == end)
    {
      r.error = "Empty notation";
      return r;
    }

    const std::string normalized =
      normalize_dashes (text.substr (begin, end - begin));
    const auto tokens = split_tokens (normalized);

    if (!tokens.empty ())
    {
      bool all_words = true;
      for (auto t : tokens)
      {
        const std::string lower = to_lower_ascii (std::string (t));
        if (!is_long_word (lower) && !is_short_word (lower))
        {
          all_words = false;
          break;
        }
      }
      if (all_words)
      {
        std::vector<blast> blasts;
        blasts.reserve (tokens.size ());
        for (auto t : tokens)
        {
          const std::string lower = to_lower_ascii (std::string (t));
          blasts.push_back (is_long_word (lower) ? blast::long_blast
                                                 : blast::short_blast);
        }
        r.ok = true;
        r.value = maybe_succession (std::move (blasts));
        return r;
      }
    }

    // Compact or mixed GCOR notation: keep only o/O and dash.
    std::string compact;
    compact.reserve (normalized.size ());
    for (char c : normalized)
    {
      if (c == ' ' || c == '\t' || c == '\n' || c == '\r' ||
          c == ',' || c == ';' || c == '|')
        continue;
      compact.push_back (c);
    }

    if (compact.empty ())
    {
      r.error = "Empty notation";
      return r;
    }

    for (char c : compact)
    {
      if (c != 'o' && c != 'O' && !is_dash (c))
      {
        r.error = "Unrecognized notation";
        return r;
      }
    }

    std::vector<blast> blasts;
    blasts.reserve (compact.size ());
    for (char c : compact)
      blasts.push_back (is_dash (c) ? blast::long_blast : blast::short_blast);

    r.ok = true;
    r.value = maybe_succession (std::move (blasts));
    return r;
  }

  bool
  valid (const pattern& p) noexcept
  {
    if (p.kind == pattern_kind::succession)
      return true;
    return p.kind == pattern_kind::counted && !p.blasts.empty ();
  }

  std::string
  to_notation (const pattern& p)
  {
    if (p.kind == pattern_kind::succession)
      return "o o o o o …";

    std::string s;
    s.reserve (p.blasts.size () * 2);
    for (std::size_t i = 0; i < p.blasts.size (); ++i)
    {
      if (i != 0)
        s.push_back (' ');
      s.push_back (p.blasts[i] == blast::long_blast ? '-' : 'o');
    }
    return s;
  }

  std::optional<named_signal>
  lookup (const pattern& p)
  {
    if (!valid (p))
      return std::nullopt;
    for (const auto& s : built_catalog ())
    {
      if (pattern_equal (p, pattern_from_signal (s)))
        return s;
    }
    return std::nullopt;
  }

  std::optional<named_signal>
  lookup_by_name (std::string_view name)
  {
    const std::string key = normalize_key (name);
    if (key.empty ())
      return std::nullopt;

    const auto& cat = built_catalog ();
    for (const auto& s : cat)
    {
      if (normalize_key (s.name) == key)
        return s;
    }
    for (const auto& s : cat)
    {
      const int idx = s.id - 1;
      if (idx < 0 || idx >= 8)
        continue;
      for (const char* const* a = name_aliases[idx]; *a != nullptr; ++a)
      {
        if (normalize_key (*a) == key)
          return s;
      }
    }
    return std::nullopt;
  }

  parse_result
  identify (std::string_view query)
  {
    parse_result r;
    r.query = std::string (query);

    std::size_t begin = 0;
    std::size_t end = query.size ();
    while (begin < end &&
           (query[begin] == ' ' || query[begin] == '\t' ||
            query[begin] == '\n' || query[begin] == '\r'))
      ++begin;
    while (end > begin &&
           (query[end - 1] == ' ' || query[end - 1] == '\t' ||
            query[end - 1] == '\n' || query[end - 1] == '\r'))
      --end;

    if (begin == end)
    {
      r.error = "Empty query";
      return r;
    }

    if (auto by_name = lookup_by_name (query.substr (begin, end - begin)))
    {
      r.ok = true;
      r.signal = *by_name;
      r.value = pattern_from_signal (*by_name);
      return r;
    }

    auto parsed = parse (query);
    if (!parsed.ok)
    {
      r.error = parsed.error.empty ()
                  ? "Unrecognized name or notation"
                  : parsed.error;
      return r;
    }

    r.ok = true;
    r.value = parsed.value;
    r.signal = lookup (*parsed.value);
    return r;
  }

  const std::vector<named_signal>&
  catalog ()
  {
    return built_catalog ();
  }

  std::chrono::milliseconds
  duration (const pattern& p,
            const timing& t,
            std::size_t succession_count)
  {
    if (t.short_blast.count () < 0 ||
        t.long_blast.count () < 0 ||
        t.pause.count () < 0)
    {
      throw std::invalid_argument (
        "horn signal timing values must not be negative");
    }

    std::size_t count = 0;
    auto blast_ms = std::chrono::milliseconds {0};

    if (p.kind == pattern_kind::succession)
    {
      if (succession_count == 0)
        throw std::invalid_argument (
          "succession_count must be greater than zero");
      count = succession_count;
      blast_ms = t.short_blast * static_cast<std::int64_t> (count);
    }
    else
    {
      if (p.blasts.empty ())
        throw std::invalid_argument ("empty horn signal pattern");
      count = p.blasts.size ();
      for (auto b : p.blasts)
        blast_ms += (b == blast::long_blast ? t.long_blast : t.short_blast);
    }

    const auto pauses = count == 0
                          ? std::chrono::milliseconds {0}
                          : t.pause * static_cast<std::int64_t> (count - 1);
    return blast_ms + pauses;
  }
}
