#ifndef LIBHORNSIGNAL_HORNSIGNAL_HXX
#define LIBHORNSIGNAL_HORNSIGNAL_HXX

#include <libhornsignal/export.hxx>

#include <chrono>
#include <cstddef>
#include <optional>
#include <string>
#include <string_view>
#include <vector>

// Parse, validate, and identify North American railroad horn / whistle
// signals as defined in GCOR Rule 5.8.2 (Sounding Whistle). Notation
// follows the GCOR chart: "o" is a short sound and "-" is a longer sound.
//
// The catalog is consistent with the GCOR 5.8.2 table used by the
// horn-signal MCP server and the Directus display extension in this
// project family. Grade-crossing timing notes also reference FRA
// 49 CFR Part 222.

namespace hornsignal
{
  // A single horn blast.
  //
  enum class blast : unsigned char
  {
    short_blast,
    long_blast
  };

  // GCOR 5.8.2 signal 1 (emergency warning) is a succession of short
  // sounds whose count is not fixed. Every other standard signal is a
  // counted pattern of long and short blasts.
  //
  enum class pattern_kind : unsigned char
  {
    counted,
    succession
  };

  struct LIBHORNSIGNAL_SYMEXPORT pattern
  {
    pattern_kind kind = pattern_kind::counted;
    std::vector<blast> blasts {}; // empty when kind == succession
  };

  // One entry from the GCOR Rule 5.8.2 catalog (signals 1-8).
  //
  struct LIBHORNSIGNAL_SYMEXPORT named_signal
  {
    int id = 0;                    // GCOR 5.8.2 signal number, 1-8
    std::string_view name {};
    std::string_view notation {};  // canonical, e.g. "- - o -"
    std::string_view indication {};
    std::string_view notes {};     // may be empty
    pattern_kind kind = pattern_kind::counted;
    std::vector<blast> blasts {};  // empty when kind == succession
  };

  // Result of parsing a notation string or looking up a name.
  //
  struct LIBHORNSIGNAL_SYMEXPORT parse_result
  {
    bool ok = false;
    std::string query {};
    std::optional<pattern> value {};
    std::optional<named_signal> signal {};
    std::string error {};
  };

  // Default blast and pause lengths used by duration(). These are
  // planning values, not a regulatory prescription: GCOR 5.8.2 and
  // FRA 49 CFR Part 222 say when a crossing warning must start, not
  // how many milliseconds each blast must last. Callers who need a
  // specific operating rule should pass their own timing.
  //
  struct LIBHORNSIGNAL_SYMEXPORT timing
  {
    std::chrono::milliseconds short_blast {1000};
    std::chrono::milliseconds long_blast  {3000};
    std::chrono::milliseconds pause       {1000};
  };

  // Parse GCOR-style notation into a sequence of blasts.
  //
  // Accepted forms:
  //   - spaced GCOR chart notation:  "- - o -", "o o", "-"
  //   - compact notation:            "--o-"
  //   - typographic dashes:          em, en, minus, and similar
  //   - word forms:                  "long long short long"
  //                                  (also l/dash and s/o/dot)
  //
  // Five or more consecutive short blasts are treated as a succession
  // (GCOR signal 1). Empty input or any other character is an error.
  //
  LIBHORNSIGNAL_SYMEXPORT parse_result
  parse (std::string_view text);

  // True if the pattern is a non-empty counted sequence or a succession.
  //
  LIBHORNSIGNAL_SYMEXPORT bool
  valid (const pattern& p) noexcept;

  // Canonical GCOR-style notation for a pattern, e.g. "- - o -" or
  // "o o o o o …" for a succession.
  //
  LIBHORNSIGNAL_SYMEXPORT std::string
  to_notation (const pattern& p);

  // Look up a counted pattern or succession in the GCOR 5.8.2 catalog.
  // Returns nullopt if the pattern is well-formed but not a standard
  // signal (for example, a single short blast).
  //
  LIBHORNSIGNAL_SYMEXPORT std::optional<named_signal>
  lookup (const pattern& p);

  // Look up a signal by official name or a common alias, case-insensitively
  // ("grade crossing", "proceed", "acknowledge", "two long", ...).
  //
  LIBHORNSIGNAL_SYMEXPORT std::optional<named_signal>
  lookup_by_name (std::string_view name);

  // Parse a query that may be either a name/alias or a notation string,
  // then attach the matching catalog entry when there is one.
  //
  LIBHORNSIGNAL_SYMEXPORT parse_result
  identify (std::string_view query);

  // The eight GCOR 5.8.2 catalog entries, in rule order.
  //
  LIBHORNSIGNAL_SYMEXPORT const std::vector<named_signal>&
  catalog ();

  // Total sounding time for a pattern: the sum of each blast plus a
  // pause between consecutive blasts (no trailing pause).
  //
  // For a succession, succession_count short blasts are used (default
  // 8). Throws std::invalid_argument if the pattern is empty or if
  // any timing field is negative.
  //
  LIBHORNSIGNAL_SYMEXPORT std::chrono::milliseconds
  duration (const pattern& p,
            const timing& t = {},
            std::size_t succession_count = 8);
}

#endif // LIBHORNSIGNAL_HORNSIGNAL_HXX
