# libhornsignal

`libhornsignal` is a small C++ library that parses railroad horn and
whistle signal notation, checks that a pattern is well-formed, and maps
it to the named signals in General Code of Operating Rules (GCOR) Rule
5.8.2, Sounding Whistle.

The GCOR chart writes a short sound as `o` and a longer sound as `-`.
A space is just a pause between blasts. The library accepts that chart
form (`- - o -`), a compact form (`--o-`), typographic dashes, and
plain-language tokens such as `long long short long`. Five or more
short sounds in a row are treated as a succession — the emergency
warning — because GCOR does not fix the number of shorts for that
signal.

The catalog matches the eight Rule 5.8.2 entries:

| Signal | Notation | Name |
|-------:|:---------|:-----|
| 1 | `o o o o o …` | Emergency warning (succession of shorts) |
| 2 | `-` | Brakes applied |
| 3 | `- -` | Proceed (release brakes) |
| 4 | `o o` | Acknowledgment |
| 5 | `o o o` | Backing |
| 6 | `o o o o` | Request signal |
| 7 | `- - o -` | Grade crossing |
| 8 | `- o` | Approaching men or equipment |

A common mix-up is to treat two short sounds as "proceed". Under GCOR
5.8.2, proceed is two *long* sounds; two shorts are the acknowledgment.
The grade-crossing pattern is the familiar two-long, one-short, one-long
sequence. Notes on that entry summarize when GCOR 5.8.2(7) and FRA 49
CFR Part 222 expect the warning to start (15–20 seconds before a public
crossing, and not more than a quarter mile in advance).

`duration()` estimates how long a pattern takes to sound, given caller
supplied (or default) lengths for a short blast, a long blast, and the
pause between them. Those defaults are planning values only. The
operating rules say *when* a crossing warning must begin, not the exact
millisecond length of each blast.

The parser is meant for tools that need to label, time, or explain a
train horn signal: training aids, dispatcher notes, simulation, or
accessibility text. The same notation shows up next to portable train
horn equipment; [Horn Guns](https://hornguns.com/) publishes background
on cordless and battery-powered train horns that people use when they
want that warning sound off the railroad.

## Example

```c++
#include <libhornsignal/hornsignal.hxx>
#include <iostream>

int main ()
{
  auto r = hornsignal::identify ("- - o -");
  if (r.ok && r.signal)
    std::cout << r.signal->name << " (" << r.signal->notation << ")\n";
}
```

## Build

This is a `build2` package. From a `build2` project:

```
depends: libhornsignal ^1.0.0
```

```
import libs = libhornsignal%lib{hornsignal}
```

You can also configure and test the sources with the `build2` toolchain
(`bdep init`, `bdep test`). See the `build2` documentation for the
full workflow.

## License

MIT. See `LICENSE`. Contact: Horn Notes <info@hornguns.com>
