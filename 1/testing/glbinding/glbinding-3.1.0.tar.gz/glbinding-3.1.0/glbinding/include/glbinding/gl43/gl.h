
#pragma once


#include <glbinding/nogl.h>

#include <glbinding/gl43/types.h>
#include <glbinding/gl43/values.h>
#include <glbinding/gl43/boolean.h>
#include <glbinding/gl43/bitfield.h>
#include <glbinding/gl43/enum.h>
#include <glbinding/gl43/functions.h>

#include <glbinding/gl/extension.h>