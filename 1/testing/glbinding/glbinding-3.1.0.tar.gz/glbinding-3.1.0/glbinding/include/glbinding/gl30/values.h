
#pragma once


#include <glbinding/nogl.h>

#include <glbinding/gl/values.h>


namespace gl30
{


// import values to namespace


} // namespace gl30