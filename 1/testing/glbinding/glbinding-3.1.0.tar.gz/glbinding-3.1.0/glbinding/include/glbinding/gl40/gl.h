
#pragma once


#include <glbinding/nogl.h>

#include <glbinding/gl40/types.h>
#include <glbinding/gl40/values.h>
#include <glbinding/gl40/boolean.h>
#include <glbinding/gl40/bitfield.h>
#include <glbinding/gl40/enum.h>
#include <glbinding/gl40/functions.h>

#include <glbinding/gl/extension.h>