
#pragma once


#include <glbinding/nogl.h>

#include <glbinding/gl32/types.h>
#include <glbinding/gl32/values.h>
#include <glbinding/gl32/boolean.h>
#include <glbinding/gl32/bitfield.h>
#include <glbinding/gl32/enum.h>
#include <glbinding/gl32/functions.h>

#include <glbinding/gl/extension.h>