
#pragma once


#include <glbinding/nogl.h>

#include <glbinding/gl20/types.h>
#include <glbinding/gl20/values.h>
#include <glbinding/gl20/boolean.h>
#include <glbinding/gl20/bitfield.h>
#include <glbinding/gl20/enum.h>
#include <glbinding/gl20/functions.h>

#include <glbinding/gl/extension.h>