
#include <glbinding/AbstractValue.h>


namespace glbinding
{


AbstractValue::AbstractValue()
{
}

AbstractValue::~AbstractValue()
{
}


} // namespace glbinding