
#pragma once


namespace glbinding
{


const unsigned int GL_REVISION = 20210221; ///< The revision of the gl.xml at the time of code generation.


} // namespace glbinding