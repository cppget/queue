/*
 *  IXGetFreePort.h
 *  Author: Benjamin Sergeant
 *  Copyright (c) 2019 Machine Zone. All rights reserved.
 */

#pragma once

namespace ix
{
    int getFreePort();
} // namespace ix
