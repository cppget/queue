# Essence

This is a library of code that I want to use, but not rewrite into every project.

## Disclaimer
This is not meant to be a "cross-platform" library; it's made for me, by  
me. Many parts of this library are Linux and/or GLIBC specific, because  
I don't force myself to use poorly written or discriminatory software  
like Musl-libc, MacOS/Darwin or Windows. Nor do I subject myself to the  
purposely permissively licensed software like the various BSD's.

The library is split into components, some larger than others.

- `types`: Type aliases for the sake of my sanity
- `encoding`: UTF-8 text validation and codepoint counting
- `concepts`: A few useful concept constraints
- `environment`: Functions for working with and manipulating environment variables
- `exceptions`: Standard exceptions with `std::format` arguments.
- `color`: ANSI escape-sequence string class
- `error`: Simple error type for use with `std::expected`
- `i18n`: Convenice wrappers for **GNU** Gettext
- `io`: Output printing functions
- `process`: Convenient but fine-grained process creation
- `str`: String manipulation functions
- `term`: Wrapper around `termios.h` functionality
- `xdg`: Freedesktop.org related code
  - `basedir`: Streamlined XDG-Basedir specification paths
- `uni`: Unix and Unix adjacent
  - `dirent`: `scandir()` convenice abstraction
  - `group`: `grp.h` group struct wrapper
  - `passwd`: `pwd.h` passwd struct wrapper
  - `stat`: `stat.h` stat struct wrapper
  - `strerror`: Automatically cleaned up, thread-safe `strerror`
  - `unistd`: Wrappers for the many general functions from `unistd.h`
  - `signal`: Abstraction around the sigaction struct and function

## Licensing
This project is available for use under the terms of
the [GNU Lesser General Public License](LICENSES/LGPL-3.0-or-later.txt) Version 3.0 or later **WITH**
the [LGPL-3.0-linking-exception](LICENSES/LGPL-3.0-linking-exception.txt).
