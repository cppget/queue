#include "essence.hpp"
#include <vector>
#include <string>
#undef NDEBUG
#include <cassert>

int main()
{
    using namespace essence;
    {
        std::vector<std::string> path
        {
            "/usr/local/bin",
            "/usr/bin",
            "/usr/local/sbin",
            "/usr/sbin"
        };
        auto result = str::split("/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin", ':');
        assert(result == path);
    }
}
