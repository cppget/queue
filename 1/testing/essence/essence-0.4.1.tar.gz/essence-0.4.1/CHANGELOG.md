# CHANGELOG

All notable changes to this project will be documented in this file.

The format is based on [Keep A Changelog](https://keepachangelog.com/en/1.1.0),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).


## [Unreleased]

### Changed
- REAMDE,CHANGELOG: changed to markdown

### Removed
- meson: Converted to build2


## [0.4.1]

### Fixed
- uni/signal: added maybe_unused to static function decls
- version quoting in-file and meson.build redundancy


## [0.4.0]

### Changed
- str: factor transformation function out into another namespace
- xdg/basedir: remove std::istream friend operator

### Added
- xdg/basedir: streamlined XDG basedir paths
- environment: overloads for env::get functions with fallback values


## [0.3.1]

### Changed
- process: run method split into spawn/wait

### Added
- process: unix pipeline class for piping processes together
- process: kill and running methods added to process
- io: file-to-strings input functions
- str: added trim/trim_left/trim_right and mirror copying variants


## [0.2.0]

### Added
- environment: added unordered map variants
- uni/dirent: wrapper for dirent.h's scandir
- uni/group: wrapper for unix group struct, thread safe
- uni/passwd: wrapper for unix passwd struct, thread safe
- uni/signal: unfinished unix signal class implementation
- uni/strerror: thread-safe strerror_r wrapper
- uni/stat: wrapper for stat/lstat
- process: unix process creation
- color: ansi escape sequence message class
- types: type aliases for the sake of my sanity
- tests/: A few simple test-cases added

### Changed
- unistd: moved to uni/unistd.hpp


## [0.1.0]

### Added
- i18n: gettext translation functions
- io: simple printing IO functions
