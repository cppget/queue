#pragma once

#ifndef _ESSENCE_XDG_HPP
#define _ESSENCE_XDG_HPP

// IWYU pragma: begin_exports
#include "xdg/basedir.hpp"
// IWYU pragma: end_exports

#endif
