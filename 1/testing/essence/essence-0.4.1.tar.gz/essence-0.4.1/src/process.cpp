#include "process.hpp"
#include "types.hpp"
#include "io.hpp"
#include "uni/strerror.hpp"

#include <filesystem>
#include <utility>
#include <sys/wait.h>
#include <signal.h>

namespace fs = std::filesystem;

namespace essence
{

auto process::mapenviron(const std::unordered_map<std::string, std::string> &envmap, std::vector<std::string> &envvec, std::vector<char*> &envptrs) -> void
{
    envvec.clear();
    envptrs.clear();

    envvec.reserve(envmap.size());
    envptrs.reserve(envmap.size() + 1); // nullptr terminator
    for (const auto &[key, value]: envmap)
    {
        envvec.push_back(key + "=" + value);
        envptrs.push_back(envvec.back().data());
    }
    envptrs.push_back(nullptr);
}

auto process::executable() const -> const fs::path&
{
    return m_executable;
}

auto process::arguments() const -> const std::vector<std::string>&
{
    return m_arguments;
}

auto process::environment() const -> const std::unordered_map<std::string, std::string>&
{
    return m_environment;
}

auto process::ioconf() const -> const ioconfig&
{
    return m_io;
}

auto process::ioconf() -> ioconfig&
{
    return m_io;
}

auto process::status() const -> int
{
    return m_status;
}

auto process::executable(std::filesystem::path path) -> process&
{
    m_executable = std::move(path);
    return *this;
}

auto process::arguments(std::vector<std::string> args) -> process&
{
    m_arguments = std::move(args);
    return *this;
}

auto process::environment(std::unordered_map<std::string, std::string> envs) -> process&
{
    m_environment = std::move(envs);
    return *this;
}


auto process::ioconf(struct ioconfig conf) -> process&
{
    m_io = std::move(conf);
    return *this;
}

auto process::status(int s) -> process&
{
    m_status = s;
    return *this;
}

auto process::run() -> process&
{
    return spawn().wait();
}

auto process::spawn() -> process&
{

    auto argv = std::vector<const char*>();
    argv.reserve(m_arguments.size() + 2);
    argv.push_back(m_executable.c_str());

    for (const auto &a: m_arguments)
        argv.push_back(a.c_str());

    argv.push_back(nullptr);

    std::vector<std::string> env_vec{};
    std::vector<char*> env_ptrs{};

    mapenviron(m_environment, env_vec, env_ptrs);

    pid_t p = fork();
    if (p == 0)
    {
        if (::dup2(m_io.in.fd, STDIN_FILENO) == -1)
            io::eprintn(uni::strerror());
        if (::dup2(m_io.out.fd, STDOUT_FILENO) == -1)
            io::eprintn(uni::strerror());
        if (::dup2(m_io.err.fd, STDERR_FILENO) == -1)
            io::eprintn(uni::strerror());

        if (m_io.in.fd > STDERR_FILENO) ::close(m_io.in.fd);
        if (m_io.out.fd > STDERR_FILENO) ::close(m_io.out.fd);
        if (m_io.err.fd > STDERR_FILENO) ::close(m_io.err.fd);

        if (not (executable().string().starts_with("/") or executable().string().starts_with("./") or fs::exists(executable())))
        {
            execvpe(executable().c_str(), const_cast<char* const*>(argv.data()), const_cast<char* const*>(env_ptrs.data()));
        }
        else
        {
            execve(executable().c_str(), const_cast<char* const*>(argv.data()), const_cast<char* const*>(env_ptrs.data()));
        }
        io::eprintn("execve failed");
        _exit(127);
    }

    m_pid = p;
    return *this;
}

auto process::wait() -> process&
{
    if (pid() == -1) return *this;
    int s;
    ::waitpid(pid(), &s, 0);
    m_status = (WIFEXITED(s) ? WEXITSTATUS(s) : -1);
    return *this;
}

auto process::pid() const -> pid_t
{
    return m_pid;
}

auto process::running() -> bool
{
    if (m_pid == -1) return false;
    int s;
    pid_t result = ::waitpid(m_pid, &s, WNOHANG);
    
    if (result == 0)
    {
        return true;
    }
    else if (result == m_pid)
    {
        // exited, needs reaping
        m_status = WEXITSTATUS(s);
        m_pid = -1;
        return false;
    }
    return false;
}

auto process::kill(int sig) -> void
{
    if (running())
        ::kill(pid(), sig);
    return;
}

auto pipeline::spawn() -> pipeline&
{
    m_pipes.resize(m_procs.size() - 1);
    for (auto &fd: m_pipes)
        ::pipe(fd.data());

    for (usize n = 0; n < m_procs.size(); n++)
    {
        if (n > 0)
            m_procs[n].ioconf().in = ioport(m_pipes[n - 1][0]);
        if (n < m_pipes.size())
            m_procs[n].ioconf().out = ioport(m_pipes[n][1]);
    }

    for (usize i = 0; i < m_procs.size(); i++)
    {
        m_procs[i].spawn();

        if (i < m_pipes.size())
            ::close(m_pipes[i][1]);
        if (i > 0)
            ::close(m_pipes[i - 1][0]);
    }

    return *this;
}

auto pipeline::pipe(process proc) -> pipeline&
{
    m_procs.push_back(std::move(proc));
    return *this;
}

auto pipeline::wait() -> pipeline&
{
    for (auto &p: m_procs)
        p.wait();
    return *this;
}

auto pipeline::run() -> pipeline&
{
    return spawn().wait();
}

auto pipeline::status() const -> int
{
    return m_procs.back().status();
}

auto pipeline::statuses() const -> std::vector<int>
{
    auto s = std::vector<int>{};
    s.reserve(m_procs.size());
    for (const auto &p: m_procs)
        s.push_back(p.status());
    return s;
}

auto operator|(process lhs, process rhs) -> pipeline
{
    pipeline p{};
    return p.pipe(std::move(lhs))
            .pipe(std::move(rhs));
}

auto operator|(pipeline lhs, process rhs) -> pipeline
{
    return lhs.pipe(std::move(rhs));
}

}; // ns: essence
