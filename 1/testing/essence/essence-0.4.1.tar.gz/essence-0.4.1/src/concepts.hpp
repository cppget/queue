#pragma once
#ifndef _ESSENCE_CONCEPTS_HPP
#define _ESSENCE_CONCEPTS_HPP

#include <type_traits>
#include <concepts>

namespace essence
{

/// @concept anyof
template<typename T, typename... Args>
concept anyof = (std::is_same_v<Args, std::remove_cvref_t<T>> or ...);

/// @concept matches
template<typename T, typename... Args>
requires (std::equality_comparable_with<T, Args> && ...)
inline bool matches(const T& value, const Args&... args)
{
    return ((value == args) or ...);
}

}

#endif
