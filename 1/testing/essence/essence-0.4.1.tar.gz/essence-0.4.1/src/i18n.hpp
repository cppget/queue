#pragma once
#ifndef _ESSENCE_I18N_HPP
#define _ESSENCE_I18N_HPP

#include "export.hpp"

#include <string>
#include <format>
#include <libintl.h>


/// @file essence/i18n.hpp

/// @namespace i18n
/// @brief Functions for translation using GNU gettext
namespace essence::i18n
{

/// @defgroup i18n Functions for translation using GNU gettext
/// @{

/** @brief Pass a formatted string throw GNU Gettext
 *  @param msgid The string to pass
 *  @param args The format arguments
 *  @return The resulting string
 **/
template<typename... Args>
inline std::string _(const char *msgid, Args&&... args)
{
    return std::vformat(::gettext(msgid), std::make_format_args(args...));
}

/** @brief Pass a string throw GNU Gettext
 *  @param msgid The string to pass
 *  @return The resulting string
 **/
ESSENCE_API std::string _(const char *msgid);

/** @brief Pass a formatted string through GNU (n) Gettext
 *  @param singular The singular form of the string
 *  @param plural The plural form of the string
 *  @param n The number denoting whether the result should be plural/singular
 *  @param args The format arguments
 *  @return The resulting string
 **/
template<typename... Args>
inline std::string _n(const char *singular, const char *plural, unsigned long int n, Args&&... args)
{
    return std::vformat(::ngettext(singular, plural, n), std::make_format_args(n, args...));
}

/** @brief Pass a string through GNU (n) Gettext
 *  @param singular The singular form of the string
 *  @param plural The plural form of the string
 *  @param n The number denoting whether the result should be plural/singular
 *  @return The resulting string
 **/
ESSENCE_API std::string _n(const char *singular, const char *plural, unsigned long int n);

/// @}
}
#endif
