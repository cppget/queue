#include "essence/error.hpp"

#include <cstdio>
#include <cstdlib>
#include <string_view>

namespace essence
{

auto error::message() const noexcept -> std::string_view
{
    return m_message;
}

auto error::message(std::string_view msg) noexcept -> error&
{
    m_message.assign(msg);
    return *this;
}

auto error::die() const noexcept -> void
{
    std::fputs(m_message.c_str(), stderr);
    std::fputc('\n', stderr);
    std::exit(1);
}

};
