#include <string>
#include <ranges>
#include <algorithm>
#include <memory>

#include "str.hpp"

namespace essence::str
{

auto trim_left(std::string &s) noexcept -> void
{
    s.erase(0, s.find_first_not_of(whitespace));
    return;
}

auto trim_right(std::string &s) noexcept -> void
{
    s.erase(s.find_last_not_of(whitespace) + 1);
    return;
}

auto trim(std::string &s) noexcept -> void
{
    trim_left(s);
    trim_right(s);
    return;
}

auto trim_left_copy(const std::string &s) noexcept -> std::string
{
    std::string r{s};
    r.erase(0, r.find_first_not_of(whitespace));
    return r;
}

auto trim_right_copy(const std::string &s) noexcept -> std::string
{
    std::string r{s};
    r.erase(r.find_last_not_of(whitespace) + 1);
    return r;
}

auto trim_copy(const std::string &s) noexcept -> std::string
{
    std::string r{s};
    trim_left(r);
    trim_right(r);
    return r;
}

auto split(const std::string& s, char delim = ' ') -> std::vector<std::string>
{
    return s
    | std::ranges::views::split(delim)
    | std::ranges::views::transform(xform::split)
    | std::ranges::to<std::vector>();
}

auto split(const char *s, char delim = ' ') -> std::vector<std::string>
{
    return split(std::string(s), delim);
}

auto split(const std::string& s, std::string delim = " ") -> std::vector<std::string>
{
    if (delim.empty()) delim.assign(" ");
    auto begin = s.begin();
    std::vector<std::string> result;

    while (begin != s.cend())
    {
        auto const end = std::search(
            begin,
            s.cend(),
            delim.cbegin(),
            delim.cend()
        );
        result.emplace_back(std::addressof(*begin), std::distance(begin, end));
        begin = (end != s.cend()) ? std::next(end, delim.size()) : end;
    }
    return result;
}

auto replaceall(std::string s, const std::string& from, const std::string& to) -> std::string
{
    std::size_t pos(0);

    while ((pos = s.find(from, pos)) != std::string::npos)
    {
        s.replace(pos, from.length(), to);
        pos += to.length();
    }
    return s;
}

} // END namespace essence::str
