#include "../error.hpp"
#include "dirent.hpp"
#include <dirent.h>

namespace essence::uni
{

auto dir::scan() -> dir&
{
    struct ::dirent **names;

    int n = ::scandir(m_directory.c_str(), &names, 0, ::alphasort);
    if (n < 0)
    {
        std::free(names);
        error("failed to scan directory '{}'", m_directory).die();
    }

    m_entries.reserve(n);
    for (int x = 0; x < n; x++)
    {
        m_entries.push_back(names[x]->d_name);
        std::free(names[x]);
    }

    std::free(names);
    return *this;
}


}; // ns: essence::uni
