#include "../types.hpp"
#include "unistd.hpp"
#include "stat.hpp"

#include <date/date.h>
#include <date/tz.h>

#include <utility>
#include <print>
#include <chrono>
#include <cstring>

namespace fs = std::filesystem;

namespace essence::uni
{

auto detect_filetype(mode_t m) noexcept -> filetype
{
    switch (m & S_IFMT)
    {
        case S_IFREG: [[likely]]
            return filetype::regular;
        
        case S_IFDIR: [[likely]]
            return filetype::directory;
        
        case S_IFLNK: [[likely]]
            return filetype::symlink;
        
        case S_IFSOCK: [[unlikely]]
            return filetype::socket;
        
        case S_IFCHR: [[unlikely]]
            return filetype::character;
        
        case S_IFBLK: [[unlikely]]
            return filetype::block;
        
        case S_IFIFO: [[unlikely]]
            return filetype::fifo;
        
        default: [[unlikely]]
            return filetype::unknown;
    }
    std::unreachable();
}

auto filetype_string(filetype t) -> std::string
{
    switch (t)
    {
        using ft = filetype;
        case ft::regular:
            return "regular";
        case ft::symlink:
            return "symbolic link";
        case ft::directory:
            return "directory";
        case ft::socket:
            return "socket";
        case ft::character:
            return "character special";
        case ft::block:
            return "block special";
        case ft::fifo:
            return "fifo (named pipe)";
        case ft::unknown:
            return "unknown";
    }
    std::unreachable();
}

permissions::permissions(mode_t m)
    : m_mode(m),
      setuid(m & S_ISUID),
      setgid(m & S_ISGID),
      sticky(m & S_ISVTX)
{
    owner.read  = (m & S_IRUSR) ? true : false;
    owner.write = (m & S_IWUSR) ? true : false; 
    owner.exec  = (m & S_IXUSR) ? true : false;
    group.read  = (m & S_IRGRP) ? true : false;
    group.write = (m & S_IWGRP) ? true : false;
    group.exec  = (m & S_IXGRP) ? true : false;
    other.read  = (m & S_IROTH) ? true : false;
    other.write = (m & S_IWOTH) ? true : false;
    other.exec  = (m & S_IXOTH) ? true : false;
}

auto permissions::octal() const noexcept -> std::string
{
    return std::format("{:04o}", (m_mode & 07777));
}

auto filetime::from_time_t(const struct timespec &ts) -> std::chrono::time_point<std::chrono::file_clock>
{
    auto sys = std::chrono::system_clock::from_time_t(ts.tv_sec)
             + std::chrono::nanoseconds(ts.tv_nsec);
    return date::clock_cast<std::chrono::file_clock>(sys);
}

filetime::filetime(const struct stat &st)
{
    access = from_time_t(st.st_atim);
    modify = from_time_t(st.st_mtim);
    change = from_time_t(st.st_ctim);
}

auto resolve_symlink(const fs::path &path) noexcept -> std::expected<fs::path, error>
{
    long int pmax = ::pathconf(path.c_str(), _PC_PATH_MAX);
    char *buf = (char*)std::malloc(pmax + 1);
    if (buf == nullptr)
        return std::unexpected<error>(std::strerror(errno));
    
    isize result = ::readlink(path.c_str(), buf, pmax);
    if (result == -1)
    {
        std::free(buf);
        return std::unexpected<error>(std::strerror(errno));
    }
    std::string lnk(buf, result);
    std::free(buf);
    return lnk;
}

auto username_from_uid(userid id) noexcept -> std::expected<std::string, error>
{
    struct passwd pw;
    struct passwd *result;
    
    long int bufsize = sysconf(_SC_GETPW_R_SIZE_MAX);
    if (bufsize == -1) bufsize = 16384;
    char *buf = (char*)std::malloc(bufsize);
    if (buf == nullptr)
        return std::unexpected<error>("failed to allocate memory for getpwuid_r().");
    
    errno = 0;
    int rc = getpwuid_r(id, &pw, buf, bufsize, &result);
    if (result == nullptr)
    {
        if (rc == 0)
        {
            std::free(buf);
            return std::unexpected(error("user id {} was not found.", id));
        }
        else
        {
            errno = rc;
            std::free(buf);
            return std::unexpected<error>(strerror(errno));
        }
    }
    std::string name(buf);
    std::free(buf);
    return name;
}

auto group_from_gid(groupid id) noexcept -> std::expected<std::string, error>
{
    struct group gr;
    struct group *result;
    long int bufsize = sysconf(_SC_GETGR_R_SIZE_MAX);
    if (bufsize == -1) bufsize = 16384;
    char *buf = (char*)std::malloc(bufsize);
    if (buf == nullptr)
        return std::unexpected<error>("failed to allocate memory for getgrgid_r().");
    errno = 0;
    int rc = getgrgid_r(id, &gr, buf, bufsize, &result);
    if (result == nullptr)
    {
        if (rc == 0)
        {
            std::free(buf);
            return std::unexpected(error("group id {} was not found.", id));
        }
        else
        {
            errno = rc;
            std::free(buf);
            return std::unexpected<error>(strerror(errno));
        }
    }
    std::string name(buf);
    std::free(buf);
    return name;
}

owners::owners(userid u_id, groupid g_id)
    : gid(g_id), uid(u_id)
{
    auto user_result = username_from_uid(uid);
    if (not user_result)
        std::println(stderr, "{}", user_result.error().message());
    else
        user = user_result.value();
    
    auto group_result = group_from_gid(gid);
    if (not group_result)
        std::println(stderr, "{}", group_result.error().message());
    else
        group = group_result.value();
}

status::status(fs::path ppath, bool follow)
{
    m_path = std::move(ppath);
    struct ::stat st;
    int rc = 0;
    if (follow)
        rc = ::stat(m_path.c_str(), &st);
    else
        rc = ::lstat(m_path.c_str(), &st);

    if (rc == -1)
        std::perror("stat");

    m_uid = st.st_uid;
    m_gid = st.st_gid;
    m_times = filetime(st);
    m_permissions = uni::permissions{st.st_mode};
    m_type = detect_filetype(st.st_mode);
    m_blocks = st.st_blocks;
    m_blocksize = st.st_blksize;
    m_device = st.st_dev;
    m_device_special = st.st_rdev;

    if (st.st_size < 0)
        m_size = 0;
    else
        m_size = static_cast<usize>(st.st_size);

    if (m_type == filetype::symlink)
    {
        auto result = resolve_symlink(m_path);
        if (not result) result.error().die();
        m_target = result.value();
    }

    m_owners = uni::owners(st.st_uid, st.st_gid);
}

auto status::perms() const -> const permissions&
{
    return m_permissions;
}

auto status::times() const -> const filetime&
{
    return m_times;
}

auto status::uid() const -> userid
{
    return m_uid;
}

auto status::gid() const -> groupid
{
    return m_gid;
}

auto status::target() const -> const std::optional<fs::path>&
{
    return m_target;
}

auto status::special_device() const -> dev_t
{
    return m_device_special;
}

auto status::device() const -> dev_t
{
    return m_device;
}

auto status::special_device_minor() const -> uint
{
    return ::minor(m_device_special);
}

auto status::special_device_major() const -> uint
{
    return ::major(m_device_special);
}

auto status::size() const -> usize
{
    return m_size;
}

auto status::blocks() const -> blkcnt
{
    return m_blocks;
}

auto status::blocksize() const -> blksize
{
    return m_blocksize;
}

auto status::basename() const -> std::string
{
    return m_path.filename().string();
}

auto status::stem() const -> std::string
{
    return m_path.stem().string();
}

auto status::typestr() const -> std::string
{
    return filetype_string(m_type);
}

auto status::owners() const -> const uni::owners&
{
    return m_owners;
}


};
