#pragma once
#ifndef _ESSENCE_UNI_SIGNAL_HPP
#define _ESSENCE_UNI_SIGNAL_HPP

#include "../types.hpp"
#include "../export.hpp"

#include <functional>
#include <unordered_map>
#include <string_view>

#include <signal.h>

namespace essence::uni
{

enum class ESSENCE_API signals : u16
{
    hangup    = SIGHUP,
    interrupt = SIGINT,
    quit      = SIGQUIT,
    illegal   = SIGILL,
    trap      = SIGTRAP,
    abrt      = SIGABRT,
    bus       = SIGBUS,
    fpe       = SIGFPE,
    kill      = SIGKILL,
    usr_one   = SIGUSR1,
    segv      = SIGSEGV,
    usr_two   = SIGUSR2,
    pipe      = SIGPIPE,
    alrm      = SIGALRM,
    term      = SIGTERM,
    stkflt    = SIGSTKFLT,
    chld      = SIGCHLD,
    cont      = SIGCONT,
    stop      = SIGSTOP,
    tstp      = SIGTSTP,
    ttin      = SIGTTIN,
    ttou      = SIGTTOU,
    urg       = SIGURG,
    xcpu      = SIGXCPU,
    xfsz      = SIGXFSZ,
    vtalrm    = SIGVTALRM,
    prof      = SIGPROF,
    winch     = SIGWINCH,
    io        = SIGIO,
    poll      = SIGPOLL,
    pwr       = SIGPWR,
    sys       = SIGSYS,
    unknown   = 65535
}; // enum: signals

ESSENCE_API std::string_view signal_str(enum signals s) noexcept;

namespace signal
{

[[maybe_unused]] static std::unordered_map<enum signals, std::function<void(int)>> handlers;

[[maybe_unused]] static void dispatch(int sig);

[[maybe_unused]] static void dispatch(enum signals sig);

class ESSENCE_API signal
{
private:
    struct sigaction m_sa{};
    std::function<void(int)> m_handler{nullptr};
    enum signals m_sig;

public:
    signal() = default;

    signal(enum signals s);
    signal(enum signals s, std::function<void(int)> fn);

    ~signal() = default;


    const struct sigaction &sa() const noexcept;
    struct sigaction &sa() noexcept;

    const std::function<void(int)>& handler() const noexcept;
    std::function<void(int)>& handler() noexcept;

    const enum signals sig() const noexcept;
    enum signals sig() noexcept;

    signal& sa(struct sigaction &newsa) noexcept;
    signal& sig(enum signals newsig) noexcept;
    signal& handler(std::function<void(int)> newhandler) noexcept;

    void setup(int flags = 0) noexcept;
};

}; // ns: essence::uni::signal

}; // ns: essence::uni

#endif
