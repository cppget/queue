#include "group.hpp"
#include "unistd.hpp"
#include <cstring>

namespace essence::uni
{

auto group::populatefromgroupstruct(const struct ::group *gr) -> void
{
    m_name.clear();
    m_pass.clear();
    m_members.clear();
    m_gid = gr->gr_gid;
    m_name = gr->gr_name;
    m_pass = gr->gr_passwd;
    uint n = 0;
    while (gr->gr_mem[n] != nullptr)
    {
        m_members.push_back(gr->gr_mem[n]);
        ++n;
    }
}

auto group::init(const std::string& name) -> std::expected<bool, error>
{
    struct ::group gr;
    struct ::group *result;

    long int bufsize = ::sysconf(_SC_GETGR_R_SIZE_MAX);
    if (bufsize == -1) bufsize = 16384;

    char *buf = (char*)std::malloc(bufsize);
    if (buf == nullptr)
        return std::unexpected(error{std::strerror(errno), errno});

    int rc = getgrnam_r(name.c_str(), &gr, buf, bufsize, &result);

    if (result == nullptr)
    {
        free(buf);
        if (rc == 0)
            return std::unexpected(error{"group '{}' does not exist.", name});
        else
            return std::unexpected(error{std::strerror(errno), errno});
    }

    populatefromgroupstruct(result);

    std::free(buf);
    return true;
}

auto group::init(gid_t id) -> std::expected<bool, error>
{
    struct ::group gr;
    struct ::group *result;

    long int bufsize = ::sysconf(_SC_GETGR_R_SIZE_MAX);
    if (bufsize == -1) bufsize = 16384;

    char *buf = (char*)std::malloc(bufsize);
    if (buf == nullptr)
        return std::unexpected(error{std::strerror(errno), errno});

    int rc = getgrgid_r(id, &gr, buf, bufsize, &result);

    if (result == nullptr)
    {
        std::free(buf);
        if (rc == 0)
            return std::unexpected(error{"group with id {} does not exist.", id});
        else
            return std::unexpected(error{std::strerror(errno), errno});
    }

    populatefromgroupstruct(result);

    free(buf);
    return true;
}

auto group::init() -> std::expected<bool, error>
{
    gid_t id = uni::getgid();
    struct ::group gr;
    struct ::group *result;
    
    long int bufsize = ::sysconf(_SC_GETGR_R_SIZE_MAX);
    if (bufsize == -1) bufsize = 16384;

    char *buf = (char*)std::malloc(bufsize);
    if (buf == nullptr)
        return std::unexpected(error{std::strerror(errno), errno});

    int rc = getgrgid_r(id, &gr, buf, bufsize, &result);

    if (result == nullptr)
    {
        std::free(buf);
        if (rc == 0)
            return std::unexpected(error{"group with id {} does not exist.", id});
        else
            return std::unexpected(error{std::strerror(errno), errno});
    }

    populatefromgroupstruct(result);

    std::free(buf);
    return true;
}

auto group::id() const noexcept -> gid_t
{
    return m_gid;
}

auto group::name() const noexcept -> std::string_view
{
    return m_name;
}

auto group::password() const noexcept -> std::string_view
{
    return m_pass;
}

auto group::members() const noexcept -> const std::vector<std::string>&
{
    return m_members;
}

auto group::str() const noexcept -> std::string
{
    std::string result = std::to_string(m_gid)
         + ':'
         + m_name
         + ':'
         + m_pass
         + '\n';
    for (usize i = 0; const auto& m: m_members)
    {
        if (i == (m_members.size() - 1))
            result.append("- " + m + '\n');
        else
            result.append("- " + m);
    }
    return result;
}

}; // ns: sis
