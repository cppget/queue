#pragma once
#ifndef _ESSENCE_UNI_STRERROR_HPP
#define _ESSENCE_UNI_STRERROR_HPP

#include <string>

#include "../export.hpp"

namespace essence::uni
{

ESSENCE_API std::string strerror(int no);
ESSENCE_API std::string strerror();

};

#endif
