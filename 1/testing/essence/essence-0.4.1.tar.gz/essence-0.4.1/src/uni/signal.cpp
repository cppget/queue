#include "signal.hpp"

#include <utility>

namespace essence::uni
{

auto signal_str(enum signals s) noexcept -> std::string_view
{
    switch (s)
    {
        using sn = signals;
        
        // 1 - HUP 
        case sn::hangup:
            return "Hangup";
        
        // 2 - INT
        case sn::interrupt:
            return "Interrupt";

        // 3 - QUIT
        case sn::quit:
            return "Quit";

        // 4 - ILL
        case sn::illegal:
            return "Illegal instruction";

        // 5 - TRAP
        case sn::trap:
            return "Trace/breakpoint trap";

        // 6 - ABRT/IOT
        case sn::abrt:
            return "Aborted";

        // 7 - BUS
        case sn::bus:
            return "Bus error";

        // 8 - FPE
        case sn::fpe:
            return "Floating point exception";

        // 9 - KILL
        case sn::kill:
            return "Killed";

        // 10 - USR1
        case sn::usr_one:
            return "User defined signal 1";

        // 11 - SEGV
        case sn::segv:
            return "Segmentation fault";

        // 12 - USR2
        case sn::usr_two:
            return "User defined signal 2";

        // 13 - PIPE
        case sn::pipe:
            return "Broken pipe";

        // 14 - ALRM
        case sn::alrm:
            return "Alarm clock";

        // 15 - TERM
        case sn::term:
            return "Terminated";

        // 16 -  STKFLT
        case sn::stkflt:
            return "Stack fault";

        // 17 - 
        case sn::chld:
            return "Child Exited";

        // 18 - CONT
        case sn::cont:
            return "Continued";

        // 19 - STOP
        case sn::stop:
            return "Stopped (signal)";

        // 20 - TSTP
        case sn::tstp:
            return "Stopped";

        // 21 - TTIN
        case sn::ttin:
            return "Stopped (tty input)";

        // 22 - TTOU
        case sn::ttou:
            return "Stopped (tty output)";

        // 23 - URG
        case sn::urg:
            return "Urgent I/O condition";

        // 24 - XCPU
        case sn::xcpu:
            return "CPU time limit expired";

        // 25 - XFSZ 
        case sn::xfsz:
            return "File size limit exceeded";

        // 26 - VTALRM
        case sn::vtalrm:
            return "Virtual timer expired";

        // 27 - PROF
        case sn::prof:
            return "Profiling timer expired";

        // 28 - WINCH
        case sn::winch:
            return "Window changed";

        // 29 - IO/POLL
        case sn::poll:
            return "I/O possible";

        // 30 - PWR
        case sn::pwr:
            return "Power failure";

        // 31 - SYS
        case sn::sys:
            return "Bad system call";

        case sn::unknown: [[unlikely]]
            return "Unknown signal";
        
        default: [[unlikely]]
            std::unreachable();
    }
}


namespace signal
{

[[maybe_unused]]
static auto dispatch(int sig) -> void
{
    for (const auto &[k, v]: handlers)
        if (static_cast<int>(k) == sig)
            handlers.at(k)(sig);
}

[[maybe_unused]]
static auto dispatch(enum signals sig) -> void
{
    if (handlers.find(sig) != handlers.end())
        handlers.at(sig)(static_cast<int>(sig));
}

signal::signal(enum signals s)
    : m_sig(s)
{}

signal::signal(enum signals s, std::function<void(int)> fn)
    : m_handler(std::move(fn)),
      m_sig(s)
{}

auto signal::handler() const noexcept -> const std::function<void(int)>&
{
    return m_handler;
}

auto signal::handler() noexcept -> std::function<void(int)>&
{
    return m_handler;
}

auto signal::sig() const noexcept -> const signals
{
    return m_sig;
}

auto signal::sig() noexcept -> signals
{
    return m_sig;
}

auto signal::sa() const noexcept -> const struct sigaction&
{
    return m_sa;
}

auto signal::sa() noexcept -> struct sigaction&
{
    return m_sa;
}

auto signal::sa(struct sigaction &newsa) noexcept -> signal&
{
    m_sa = std::move(newsa);
    return *this;
}

auto signal::handler(std::function<void(int)> newhandler) noexcept -> signal&
{
    m_handler = std::move(newhandler);
    return *this;
}

auto signal::sig(enum signals newsig) noexcept -> signal&
{
    m_sig = newsig;
    return *this;
}

auto signal::setup(int flags) noexcept -> void
{
    m_sa.sa_handler = dispatch;
    ::sigemptyset(&m_sa.sa_mask);
    m_sa.sa_flags = flags;
    handlers.insert_or_assign(m_sig, m_handler);
    ::sigaction(static_cast<int>(m_sig), &m_sa, nullptr);
}


};

}; // ns: sis
