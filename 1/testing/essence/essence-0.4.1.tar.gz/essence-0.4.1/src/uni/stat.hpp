#pragma once
#ifndef _ESSENCE_STAT_HPP
#define _ESSENCE_STAT_HPP

#include "../export.hpp"
#include "../error.hpp"
#include "../types.hpp"
#include "unistd.hpp"

#include <unistd.h>
#include <pwd.h>
#include <grp.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/sysmacros.h>

#include <expected>
#include <string>
#include <filesystem>
#include <chrono>
#include <optional>

namespace essence::uni
{

enum class ESSENCE_API filetype
{
    regular = S_IFREG,
    symlink = S_IFLNK,
    directory = S_IFDIR,
    socket = S_IFSOCK,
    character = S_IFCHR,
    block = S_IFBLK,
    fifo = S_IFIFO,
    unknown
};

ESSENCE_API filetype detect_filetype(mode_t m) noexcept;
ESSENCE_API std::string filetype_string(filetype t);

struct ESSENCE_API permission
{
    bool read, write, exec = false;
    permission() : read(false), write(false), exec(false) {}
    permission(bool r, bool w, bool x) : read(r), write(w), exec(x) {}
    permission& operator=(const permission&) = default;
    permission& operator=(permission&&) = default;
    constexpr bool operator==(const permission&) const = default;
    constexpr bool operator!=(const permission&) const = default;
}; // struct: permission

class ESSENCE_API permissions
{
private:
    mode_t m_mode{0};
public:
    permission owner{};
    permission group{};
    permission other{};
    bool setuid, setgid, sticky = false;
    permissions() = default;
    permissions(mode_t m);
    ~permissions() = default;
    constexpr bool operator==(const permissions&) const = default;
    constexpr bool operator!=(const permissions&) const = default;
    std::string octal() const noexcept;
}; // class: permissions

struct ESSENCE_API filetime
{
    std::chrono::time_point<std::chrono::file_clock> access, modify, change = {};

    constexpr bool operator==(const filetime&) const = default;
    constexpr bool operator!=(const filetime&) const = default;

    std::chrono::time_point<std::chrono::file_clock>
    from_time_t(const struct timespec& ts);

    filetime(const struct stat& st);
    filetime() = default;
    ~filetime() = default;
}; // struct: filetime

ESSENCE_API std::expected<std::filesystem::path, error> resolve_symlink(const std::filesystem::path& path) noexcept;
ESSENCE_API std::expected<std::string, error> username_from_uid(uid_t id) noexcept;
ESSENCE_API std::expected<std::string, error> group_from_gid(gid_t id) noexcept;

struct ESSENCE_API owners
{
    groupid gid = 0;
    userid uid = 0;
    std::string group = "?";
    std::string user = "?";
    
    owners() = default;
    owners(userid u_id, groupid g_id);
    
    ~owners() = default;
    
    constexpr bool operator==(const owners&) const = default;
    constexpr bool operator!=(const owners&) const = default;
}; // struct: owners

class ESSENCE_API status
{
private:
    std::filesystem::path m_path = {};
    std::optional<std::filesystem::path> m_target = std::nullopt;
    struct uni::owners m_owners = uni::owners{};
    userid m_uid = {0};
    groupid m_gid = {0};
    permissions m_permissions = permissions{};
    filetime m_times = filetime{};
    filetype m_type = filetype::unknown;
    blksize m_blocksize = {0};
    blkcnt m_blocks = {0};
    dev_t m_device = {0};
    dev_t m_device_special = {0};
    usize m_size = {0};

public:

    status(std::filesystem::path ppath, bool follow = false);

    ~status() = default;

    constexpr bool operator==(const status&) const = default;
    constexpr bool operator!=(const status&) const = default;

    const permissions& perms() const;
    const filetime& times() const;
    userid uid() const;
    groupid gid() const;
    const std::optional<std::filesystem::path>& target() const;
    uint special_device_major() const;
    uint special_device_minor() const;
    dev_t special_device() const;
    dev_t device() const;
    usize size() const;
    blkcnt blocks() const;
    blksize blocksize() const;
    std::string basename() const;
    std::string stem() const;
    std::string typestr() const;
    const struct uni::owners& owners() const;
}; // class: status

}; // ns: essence::uni
#endif
