#pragma once

#ifndef _ESSENCE_UNI_UNISTD_HPP
#define _ESSENCE_UNI_UNISTD_HPP

#include "../error.hpp"
#include "../types.hpp"
#include "../export.hpp"

#include <unistd.h>
#include <string>
#include <expected>
#include <vector>
#include <initializer_list>

namespace essence::uni
{

using groupid = gid_t;
using userid = uid_t;
using procid = pid_t;

enum class ESSENCE_API ok : uint
{
    none    = 0,
    exists  = F_OK,
    read    = R_OK,
    write   = W_OK,
    exec    = X_OK,
    rw      = R_OK|W_OK,
    rwx     = R_OK|W_OK|X_OK,
    all     = F_OK|R_OK|W_OK|X_OK
}; // enum: access_flag

ESSENCE_API bool access(const std::string &path, uint flags) noexcept;
ESSENCE_API bool access(const std::string &path, ok flags) noexcept;
ESSENCE_API bool access(const std::string &path, std::initializer_list<ok> flags) noexcept;

ESSENCE_API uint alarm(uint);

ESSENCE_API std::expected<std::string, error> getcwd();

ESSENCE_API std::expected<bool, error> chdir(const char *path);
ESSENCE_API std::expected<bool, error> chdir(const std::string &path);
ESSENCE_API std::expected<bool, error> chown(const char *path, userid id, groupid group);
ESSENCE_API std::expected<bool, error> chown(const std::string &path, userid id, groupid group);

ESSENCE_API uid_t getuid();
ESSENCE_API uid_t geteuid();
ESSENCE_API gid_t getgid();
ESSENCE_API gid_t getegid();

ESSENCE_API std::expected<std::vector<groupid>, error> getgroups();
ESSENCE_API long gethostid();
ESSENCE_API std::expected<std::string, error> gethostname();
ESSENCE_API std::expected<std::string, error> getlogin();
ESSENCE_API std::expected<procid, error> getpgid(procid p);
ESSENCE_API pid_t getpgrp();
ESSENCE_API pid_t getpid();
ESSENCE_API pid_t getppid();

ESSENCE_API bool isatty(int fd = STDOUT_FILENO);

ESSENCE_API void sync();

ESSENCE_API std::expected<std::string, error> ttyname(int fd = STDOUT_FILENO);

ESSENCE_API std::expected<pid_t, error> tcgetpgrp(int fd = STDOUT_FILENO);
ESSENCE_API std::expected<bool, error> tcsetpgrp(procid newid, int fd = STDOUT_FILENO);

ESSENCE_API std::expected<bool, error> unlink(const char *path);
ESSENCE_API std::expected<bool, error> unlink(const std::string &path);

ESSENCE_API std::expected<bool, error> symlink(const char *from, const char *to);
ESSENCE_API std::expected<bool, error> symlink(const std::string &from, const std::string &to);

ESSENCE_API std::expected<std::string, error> readlink(const char *path);
ESSENCE_API std::expected<std::string, error> readlink(const std::string &path);

}; // ns: essence::uni
#endif
