#include "unistd.hpp"
#include "passwd.hpp"

#include <filesystem>
#include <limits.h>

#include <pwd.h>

namespace fs = std::filesystem;

namespace essence::uni
{

auto password::populatefrompasswd(const struct ::passwd &pw) -> void
{
        m_name      = pw.pw_name;
        m_pass      = pw.pw_passwd;
        m_uid       = pw.pw_uid;
        m_gid       = pw.pw_gid;
        m_gecos     = pw.pw_gecos;
        m_directory = pw.pw_dir;
        m_shell     = pw.pw_shell;
}

auto password::init(const std::string &name) -> void
{
        struct passwd pw;
        struct passwd *result;
        long bufsize = ::sysconf(_SC_GETPW_R_SIZE_MAX);
        if (bufsize == -1) bufsize = 16384;
        char *buf = (char*)std::malloc(bufsize);
        int rc = ::getpwnam_r(name.c_str(), &pw, buf, bufsize, &result);
        if ((rc != 0) or (result == nullptr))
        {
            std::free(buf);
            error("unable to get passwd for {}", name).die();
        }
        populatefrompasswd(pw);
        std::free(buf);
}

auto password::init(uid_t id) -> void
{

    struct ::passwd pw;
    struct ::passwd *result;
    long bufsize = ::sysconf(_SC_GETPW_R_SIZE_MAX);
    if (bufsize == -1) bufsize = 16384;
    char *buf = (char*)std::malloc(bufsize);
    if (buf == nullptr)
        error("failed to allocate memory for getpwuid_r").die();
    int rc = ::getpwuid_r(id, &pw, buf, bufsize, &result);
    if ((rc != 0) or (result == nullptr))
    {
        std::free(buf);
        error("unable to get passwd for {}", id).die();
    }
    populatefrompasswd(pw);
    std::free(buf);
}

auto password::init() -> void
{
    init(uni::getuid());
}

auto password::operator==(const password &other) const -> bool
{
    // pass field omitted, not useful for comparison:
    // usually represented as an 'x', with the real password
    // living in shadow.
    return (
            (m_name == other.m_name)
        and (m_uid == other.m_uid)
        and (m_gid == other.m_gid)
        and (m_gecos == other.m_gecos)
        and (m_directory == other.m_directory)
        and (m_shell == other.m_shell)
    );
}

auto password::name() const -> std::string_view
{
    return m_name;
}
auto password::pass() const -> std::string_view
{
    return m_pass;
}

auto password::uid() const -> userid
{
    return m_uid;
}

auto password::gid() const -> groupid
{
    return m_gid;
}

auto password::gecos() const -> std::string_view
{
    return m_gecos;
}
auto password::comment() const -> std::string_view
{
    return m_gecos;
}

auto password::directory() const -> fs::path
{
    return m_directory;
}

auto password::shell() const -> std::string_view
{
    return m_shell;
}

auto password::str() const -> std::string
{
    return m_name
         + ':'
         + m_pass
         + ':'
         + std::to_string(m_uid)
         + ':'
         + std::to_string(m_gid)
         + ':'
         + m_gecos
         + ':'
         + m_directory
         + ':'
         + m_shell;
}

}; // ns: essence::uni
