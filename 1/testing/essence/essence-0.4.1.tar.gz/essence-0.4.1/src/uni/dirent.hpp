#pragma once
#ifndef _ESSENCE_UNIX_DIRENT_HPP
#define _ESSENCE_UNIX_DIRENT_HPP

#include "../export.hpp"

#include <dirent.h>
#include <sys/types.h>
#include <vector>
#include <string>

namespace essence::uni
{

class ESSENCE_API dir
{
private:
    std::string m_directory = ".";
    std::vector<std::string> m_entries = {};

public:
    dir(std::string pdir) : m_directory(std::move(pdir)) {}
    dir() = default;
    ~dir() = default;

    dir& scan();

    const std::vector<std::string> &entries() const noexcept
    {
        return m_entries;
    }

    const std::string &directory() const noexcept
    {
        return m_directory;
    }
};

}; // ns: essence::uni

#endif
