#pragma once
#ifndef _ESSENCE_UNI_PASSWD_HH
#define _ESSENCE_UNI_PASSWD_HH

#include "../export.hpp"
#include "unistd.hpp"

#include <unistd.h>
#include <pwd.h>

#include <filesystem>

namespace fs = std::filesystem;

namespace essence::uni
{


/// @brief Wrapper around the unix passwd struct
class ESSENCE_API password
{
private:
    /// @name Members
    /// @{
    std::string m_pass;       //!< The password, usually represented as an 'x'
    std::string m_name;       //!< The login name of the user
    userid m_uid;             //!< The UID of the user
    groupid m_gid;            //!< The GID of the user
    std::string m_gecos;      //!< The 'Full Name' or 'Comment' field
    std::string m_directory;  //!< The users' home directory
    std::string m_shell;      //!< The users' default shell
    /// @}
   
    void populatefrompasswd(const struct ::passwd &pw);
    void init(const std::string &name);
    void init(userid id);
    void init();

public:
    
    /// @name Constructors
    /// @{
    
    /// @brief Constructor accepting a UID argument
    password(userid id) {
        init(id);
    }

    /// @brief Constructor accepting a login name (string) argument
    password(const std::string &pname) {
        init(pname);
    }

    /// @brief Constructor accepting no arguments
    ///        Calls geteuid() to determine the user
    password() {
        init();
    }
    
    password(const password&) = default;
    
    password(password&&) = default;
    
    ~password() = default;
    
    password&
    operator=(const password&) = default;

    password&
    operator=(password&&) = default;
    
    /// @}


    /// @name Methods
    /// @{
    bool operator==(const password &other) const;

    /// @brief Get the users' login name.
    std::string_view name() const;

    /// @brief Get the users' password.
    /// @return Probably just an 'x', shadow handles the real password
    std::string_view pass() const;

    /// @brief Get the users' UID
    userid uid() const;
    
    /// @brief Get the users' GID
    groupid gid() const;
    
    /// @brief Get the users' 'Full Name' or 'Comment'
    std::string_view gecos() const;
    
    /// @brief Get the users' 'Full Name' or 'Comment'
    std::string_view comment() const;
    
    /// @brief Get the users' home directory
    /// @return The users' home as an std::filesystem::path
    fs::path directory() const;

    /// @brief Get the users' default shell
    std::string_view shell() const;

    /// @brief Get a string representation of the passwd entry
    /// @return The entry in a similar format to what would be listed in /etc/passwd
    std::string str() const;
    /// @}

}; // class: password
}; // ns: essence::uni

#endif
