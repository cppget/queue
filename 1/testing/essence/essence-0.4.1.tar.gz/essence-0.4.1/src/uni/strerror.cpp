#include "strerror.hpp"

#include <string>
#include <cerrno>
#include <cstring>
#include <cstdlib>

namespace essence::uni
{

auto strerror(int no) -> std::string
{
#if (_POSIX_C_SOURCE >= 200112L or _XOPEN_SOURCE >= 600) and not _GNU_SOURCE
    char *buffer = (char*)::malloc(512);
    int rc = ::strerror_r(no, buffer, 512);
    std::string msg(buffer);
    ::free(buffer);
    return msg;
#else
    char *buffer = (char*)malloc(512);
    char *result = ::strerror_r(no, buffer, 512);
    std::string msg(result);
    ::free(buffer);
    return msg;
#endif
}

auto strerror() -> std::string
{
#if (_POSIX_C_SOURCE >= 200112L or _XOPEN_SOURCE >= 600) and not _GNU_SOURCE
    char *buffer = (char*)::malloc(512);
    int rc = ::strerror_r(no, buffer, 512);
    std::string msg(buffer);
    ::free(buffer);
    return msg;
#else
    char *buffer = (char*)malloc(512);
    char *result = ::strerror_r(errno, buffer, 512);
    std::string msg(result);
    ::free(buffer);
    return msg;
#endif
}

};
