#include "unistd.hpp"
#include "../error.hpp"
#include "../types.hpp"

#include <string.h>
#include <limits.h>

namespace essence::uni
{

auto access(const std::string &path, uint flags) noexcept -> bool
{
    if (::access(path.c_str(), flags) == 0)
        return true;
    else
        return false;
}

auto access(const std::string &path, ok flag) noexcept -> bool
{
    if (::access(path.c_str(), static_cast<uint>(flag)) == 0)
        return true;
    else
        return false;
}

auto access(const std::string &path, std::initializer_list<ok> flags) noexcept -> bool
{
    uint combined = 0;
    for (ok o: flags)
        combined |= static_cast<uint>(o);
    if (::access(path.c_str(), combined) == 0)
        return true;
    else
        return false;
}

auto alarm(uint seconds) -> uint
{
    return ::alarm(seconds);
}

auto getcwd() -> std::expected<std::string, error> 
{
    usize buffer_size = ::pathconf(".", _PC_PATH_MAX);
    char *buffer = (char*)malloc(buffer_size);
    if (buffer == nullptr)
        return std::unexpected<error>("failed to allocate memory for getcwd()");
    if (::getcwd(buffer, buffer_size) == nullptr)
        return std::unexpected<error>(strerror(errno));
    std::string wd(buffer);
    std::free(buffer);
    return wd;
}


auto chdir(const char *path) -> std::expected<bool, error>
{
    auto rc = ::chdir(path);
    if (rc != 0)
        return std::unexpected<error>(strerror(errno));
    return true;
}

auto chdir(const std::string &path) -> std::expected<bool, error>
{
    return uni::chdir(path.c_str());
}

auto chown(const char *path, userid u_id, groupid g_id) -> std::expected<bool, error>
{
    auto rc = ::chown(path, u_id, g_id);
    if (rc != 0)
        return std::unexpected<error>(strerror(errno));
    return true;
}

auto chown(const std::string &path, userid u_id, groupid g_id) -> std::expected<bool, error>
{
    return uni::chown(path.c_str(), u_id, g_id);
}

auto getuid() -> userid
{
    return ::getuid();
}

auto geteuid() -> userid
{
    return ::geteuid();
}

auto getgid() -> userid
{
    return ::getgid();
}

auto getegid() -> userid
{
    return ::getegid();
}

auto getgroups() -> std::expected<std::vector<groupid>, error>
{
    usize ngm = ::sysconf(_SC_NGROUPS_MAX) + 1;
    groupid *groups = (groupid*)std::malloc(ngm * sizeof(groupid));
    if (groups == nullptr)
        return std::unexpected<error>("failed to allocate memory for getgroups()");
    
    int count = ::getgroups(ngm, groups);

    if (count == -1)
    {
        std::free(groups);
        return std::unexpected<error>(strerror(errno));
    }

    std::vector<groupid> gs;
    gs.resize(count);
    for (int n = 0; n < count; ++n)
        gs.at(n) = groups[n];
    std::free(groups);
    return gs;
}


auto gethostid() -> long
{
    return ::gethostid();
}

auto gethostname() -> std::expected<std::string, error>
{
    char *buf = (char*)std::malloc(HOST_NAME_MAX + 1);
    if (buf == nullptr)
        return std::unexpected<error>("Failed to allocate memory for gethostname()");
    auto rc = ::gethostname(buf, HOST_NAME_MAX);
    if (rc == -1)
    {
        std::free(buf);
        return std::unexpected<error>("Failed to retrieve the hostname");
    }
    std::string hn(buf);
    std::free(buf);
    return hn;
}

auto getlogin() -> std::expected<std::string, error>
{
    usize namemax = ::sysconf(_SC_LOGIN_NAME_MAX);
    char *buf = (char*)std::malloc(namemax + 1);
    if (buf == nullptr)
        return std::unexpected<error>("Failed to allocate memory for getlogin()");
    int rc = ::getlogin_r(buf, namemax);
    if (rc != 0)
    {
        std::free(buf);
        return std::unexpected<error>("Failed to retrieve login name");
    }
    std::string name(buf);
    std::free(buf);
    return name;
}

auto getpgid(procid p) -> std::expected<procid, error>
{
    procid r = ::getpgid(p);
    if (r == static_cast<procid>(-1))
        return std::unexpected<error>(strerror(errno));
    return r;
}

auto getpgrp() -> procid
{
    return ::getpgrp();
}

auto getpid() -> procid
{
    return ::getpid();
}

auto getppid() -> procid
{
    return ::getppid();
}

auto isatty(int fd) -> bool
{
    if (::isatty(fd) == 0) return false;
    return true;
}

auto sync() -> void
{
    return ::sync();
}

auto ttyname(int fd) -> std::expected<std::string, error>
{
    auto ttymax = ::sysconf(_SC_TTY_NAME_MAX);
    char *buf = (char*)std::malloc(ttymax + 1);
    if (buf == nullptr)
        return std::unexpected<error>("failed to allocate memory for ttyname()");
    int rc = ::ttyname_r(fd, buf, ttymax);
    if (rc != 0)
    {
        std::free(buf);
        return std::unexpected<error>(strerror(rc));
    }
    std::string name(buf);
    std::free(buf);
    return name;
}

auto tcgetpgrp(int fd) -> std::expected<procid, error>
{
    int rc = ::tcgetpgrp(fd);
    if (rc == -1)
        return std::unexpected<error>(strerror(errno));
    return static_cast<procid>(rc);
}

auto tcsetpgrp(procid newid, int fd) -> std::expected<bool, error>
{
    int rc = ::tcsetpgrp(fd, newid);
    if (rc == -1)
        return std::unexpected<error>(strerror(errno));
    return true;
}

auto unlink(const char *path) -> std::expected<bool, error>
{
    int rc = ::unlink(path);
    if (rc == -1)
        return std::unexpected<error>(strerror(errno));
    return true;
}

auto unlink(const std::string &path) -> std::expected<bool, error>
{
    return uni::unlink(path.c_str());
}

auto symlink(const char *from, const char *to) -> std::expected<bool, error>
{
    int rc = ::symlink(from, to);
    if (rc == -1)
        return std::unexpected<error>(strerror(errno));
    return true;
}

auto symlink(const std::string &from, const std::string &to) -> std::expected<bool, error>
{
    return uni::symlink(from.c_str(), to.c_str());
}

auto readlink(const char *path) -> std::expected<std::string, error>
{
    long int pmax = ::pathconf(path, _PC_PATH_MAX);
    char *buf = (char*)std::malloc(pmax + 1);
    if (buf == nullptr)
        return std::unexpected<error>(strerror(errno));
    isize rc = ::readlink(path, buf, pmax);
    if (rc == -1)
    {
        std::free(buf);
        return std::unexpected<error>(strerror(errno));
    }
    std::string lnk(buf, rc);
    std::free(buf);
    return lnk;
}

auto readlink(const std::string &path) -> std::expected<std::string, error>
{
    return uni::readlink(path.c_str());
}


}; // ns: sis::unistd
