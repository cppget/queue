#pragma once
#ifndef _ESSENCE_UNI_GROUP_HPP
#define _ESSENCE_UNI_GROUP_HPP

#include "../export.hpp"
#include "../error.hpp"

#include "unistd.hpp"

#include <string>
#include <string_view>
#include <vector>
#include <expected>

#include <unistd.h>
#include <grp.h>

namespace essence::uni
{

class ESSENCE_API group
{

private:
    groupid m_gid;
    std::string m_name;
    std::string m_pass;
    std::vector<std::string> m_members;

    void populatefromgroupstruct(const struct ::group *gr);
    std::expected<bool, error> init(const std::string &name);
    std::expected<bool, error> init(groupid id);
    std::expected<bool, error> init();

public:
    group(const std::string &name)
    {
        auto x = init(name);
        if (not x) x.error().die();
    }

    group(groupid id)
    {
        auto x = init(id);
        if (not x) x.error().die();
    }
    
    group()
    {
        auto x = init();
        if (not x) x.error().die();
    }


    ~group() = default;

    group(const uni::group&) = default;
    group(uni::group&&) = default;
    
    uni::group& operator=(const uni::group&) = default;
    uni::group& operator=(uni::group&&) = default;

    groupid id() const noexcept;
    std::string_view name() const noexcept;
    std::string_view password() const noexcept;
    const std::vector<std::string> &members() const noexcept;

    std::string str() const noexcept;

}; // class: group
}; // ns: essence::uni

#endif
