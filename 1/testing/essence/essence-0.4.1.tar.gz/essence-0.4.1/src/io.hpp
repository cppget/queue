#pragma once

#ifndef _ESSENCE_IO_HPP
#define _ESSENCE_IO_HPP

#include "export.hpp"

#include <string_view>
#include <string>
#include <vector>
#include <print>

/** @namespace io
 *  @brief Low-level IO writing functions
 **/
namespace essence::io
{

/// @defgroup io
/// @brief Low-level IO and printing functions
/// @{

/** @brief Write a single character to stdout
 *  @param c The character to write
 **/ 
ESSENCE_API void write(char c, FILE *port = stdout);

/** @brief Write a string to stdout
 *  @param s The string to write
 **/ 
ESSENCE_API void write(std::string_view s, FILE *port = stdout);

/** @brief Write a string to stdout
 *  @param s The string to write
 **/ 
ESSENCE_API void write(const char *s, FILE *port = stdout);

/** @brief Write a string to stdout
 *  @param s The string to write
 **/ 
ESSENCE_API void write(const std::string &s, FILE *port = stdout);

/** @brief Flush an output file descriptor
 *  @param port The file to flush
 **/ 
ESSENCE_API void flush(FILE *port = stdout);


/** @brief Print a format string to stdout
 *  @param msg The string to print
 *  @param args The format arguments to apply
 **/
template<typename... Args>
inline void print(std::string_view msg, Args&&... args)
{
    std::vprint_unicode(stdout, msg, std::make_format_args(args...));
}

/** @brief Print a format string to stdout with a newline
 *  @param msg The string to print
 *  @param args The format arguments to apply
 **/
template<typename... Args>
inline void printn(std::string_view msg, Args&&... args)
{
    std::vprint_unicode(stdout, msg, std::make_format_args(args...));
    std::fputc('\n', stdout);
}

/** @brief print a string to stdout
 *  @param msg the string to print
 **/
ESSENCE_API void print(std::string_view msg);

/** @brief print a string to stdout with a newline
 *  @param msg the string to print
 **/
ESSENCE_API void printn(std::string_view msg);

/** @brief Print a format string to stderr
 *  @param msg The string to print
 *  @param args The format arguments to apply
 **/
template<typename... Args>
inline void eprint(std::string_view msg, Args&&... args)
{
    std::vprint_unicode(stderr, msg, std::make_format_args(args...));
}

/** @brief Print a format string to stderr with a newline
 *  @param msg The string to print
 *  @param args The format arguments to apply
 **/
template<typename... Args>
inline void eprintn(std::string_view msg, Args&&... args)
{
    std::vprint_unicode(stderr, msg, std::make_format_args(args...));
    std::fputc('\n', stderr);
}

/** @brief Print a string to stderr
 *  @param msg The string to print
 **/
ESSENCE_API void eprint(std::string_view msg);

/** @brief Print a string to stderr with a newline
 *  @param msg The string to print
 **/
ESSENCE_API void eprintn(std::string_view msg);

/// @}

namespace file
{

/** @brief Read a file into lines
 *  @param path The file path as a string
 *  @return A vector of the lines as strings
 **/
ESSENCE_API std::vector<std::string> lines(const std::string &path) noexcept;

/** @brief Read a file into lines
 *  @param path The file path as a string
 *  @param out Mutable reference to a vector of strings to place the lines in
 **/
ESSENCE_API void lines(const std::string &path, std::vector<std::string> &out) noexcept;

};

} // END namespace essence::io


#endif
