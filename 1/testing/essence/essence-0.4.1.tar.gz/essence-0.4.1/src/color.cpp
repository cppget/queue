#include "color.hpp"

#include <format>

namespace essence::ansi
{

auto strip(std::string &in) -> void
{
    in.assign(std::regex_replace(in, ansi::escape, ""));
}

auto fg::rgb(u8 red, u8 green, u8 blue) -> std::string
{
    return std::format("\033[38;2;{};{};{}m", red, green, blue);
}

auto bg::rgb(u8 red, u8 green, u8 blue) -> std::string
{
    return std::format("\033[48;2;{};{};{}m", red, green, blue);
}

auto message::append(const char *s) -> message&
{
    m_text.append(s);
    return *this;
}

auto message::append(std::string_view s) -> message&
{
    m_text.append(s);
    return *this;
}

auto message::append(const std::string &s) -> message&
{
    m_text.append(s);
    return *this;
}

auto message::append(char c) -> message&
{
    m_text.push_back(c);
    return *this;
}

auto message::append(std::initializer_list<std::string_view> strs) -> message&
{
    for (auto &s: strs) m_text.append(s);
    return *this;
}

auto message::append(std::initializer_list<char> chars) -> message&
{
    for (auto &c: chars) m_text.push_back(c);
    return *this;
}

auto message::operator+=(const std::string &s) -> message&
{
    return append(s);
}

auto message::operator+=(const char *s) -> message&
{
    return append(s);
}

auto message::operator+=(std::string_view s) -> message&
{
    return append(s);
}

auto message::operator+=(char c) -> message&
{
    return append(c);
}

auto message::operator+=(message &other) -> message&
{
    return append(other.str());
}

auto message::newline() -> message&
{
    return append('\n');
}

auto message::nl() -> message&
{
    return this->newline();
}

auto message::clear() -> message&
{
    m_text.clear();
    return *this;
}

auto message::reset() -> message&
{
    m_text.append(ansi::none);
    return *this;
}

auto message::text(std::string txt) -> message&
{
    m_text = std::move(txt);
    return *this;
}

auto message::clean() -> message&
{
    strip(m_text);
    return *this;
}

auto message::str() -> std::string
{
    return m_text + ansi::none;
}

auto operator+(const message &lhs, const std::string &rhs) -> message
{
    return message(lhs.m_text + rhs);
}

auto operator+(const message &lhs, std::string_view rhs) -> message
{
    return message(lhs.m_text + rhs);
}

auto operator+(const message &lhs, const char *rhs) -> message
{
    return message(lhs.m_text + rhs);
}

auto operator+(const message &lhs, char rhs) -> message
{
    return message(lhs.m_text + rhs);
}

auto operator+(message &lhs, message &rhs) -> message
{
    return message(lhs.str() + rhs.str());
}

auto operator<<(std::ostream &os, message &self) -> std::ostream&
{
    os << self.str();
    return os;
}

}; // ns: ansi
