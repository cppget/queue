#pragma once
#ifndef _ESSENCE_ENCODING_HPP
#define _ESSENCE_ENCODING_HPP

#include "types.hpp"
#include "export.hpp"

#include <string_view>


/** @namespace encoding
 *  @brief UTF-8 validation and utility functions
 **/
namespace essence::encoding
{

/// @defgroup encoding
/// @brief UTF-8 validation and utility functions
/// @{
    
/** @brief Validate a string is UTF-8
 *  @param s The string to validate
 *  @return true if the string is valid UTF-8, false otherwise
 **/
ESSENCE_API bool validate(std::string_view s);

/** @brief Count the visual glyphs of a string
 *  @param s The string to count
 *  @return The amount of glyphs
 **/
ESSENCE_API usize count(std::string_view s);

/// @}

}
#endif
