#pragma once
#ifndef _ESSENCE_PROCESS_HPP
#define _ESSENCE_PROCESS_HPP

#include "export.hpp"
#include "environment.hpp"

#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>

#include <vector>
#include <string>
#include <filesystem>
#include <unordered_map>

namespace essence
{

struct ESSENCE_API ioport
{
    static ioport null() { return ioport{ ::open("/dev/null", O_RDWR) }; }
    static ioport input() { return ioport{ STDIN_FILENO }; }
    static ioport output() { return ioport{ STDOUT_FILENO }; }
    static ioport error() { return ioport{ STDERR_FILENO }; }
    int fd;
    explicit ioport(int pfd) : fd(pfd) {}
};

struct ESSENCE_API ioconfig
{
    ioport in = ioport::input();
    ioport out = ioport::output();
    ioport err = ioport::error();
};

class ESSENCE_API process
{
private:
    void mapenviron(const std::unordered_map<std::string, std::string> &envmap, std::vector<std::string> &envvec, std::vector<char*> &envptrs);

    std::filesystem::path m_executable = {};
    std::vector<std::string> m_arguments = {};
    std::unordered_map<std::string, std::string> m_environment = {};
    ioconfig m_io = {};
    int m_status = 0;
    pid_t m_pid = -1;

public:
    process() : m_environment(env::umap()) {}
    process(std::filesystem::path path)
        : m_executable(std::move(path)),
          m_environment(env::umap())
    {}
    
    process(std::filesystem::path path, std::initializer_list<std::string> args)
        : m_executable(std::move(path)),
          m_arguments(static_cast<std::vector<std::string>>(args)),
          m_environment(env::umap())
    {}

    const std::filesystem::path& executable() const;
    const std::vector<std::string>& arguments() const;
    const std::unordered_map<std::string, std::string>& environment() const;
    const ioconfig& ioconf() const;
    ioconfig& ioconf();
    int status() const;
    pid_t pid() const;

    process& executable(std::filesystem::path path);
    process& arguments(std::vector<std::string> args);
    process& environment(std::unordered_map<std::string, std::string> envs);
    process& ioconf(struct ioconfig conf);
    process& status(int s);
    process& pid(pid_t p);

    process& spawn();
    process& wait();

    bool running();

    void kill(int sig = 15);

    process& run();
};

class ESSENCE_API pipeline
{
private:
    std::vector<process> m_procs{};
    std::vector<std::array<int, 2>> m_pipes{};

public:
    pipeline() = default;

    pipeline& pipe(process proc);
    pipeline& spawn();
    pipeline& wait();
    pipeline& run();

    int status() const;
    std::vector<int> statuses() const;
};

ESSENCE_API pipeline operator|(process lhs, process rhs);
ESSENCE_API pipeline operator|(pipeline lhs, process rhs);

}; // ns: essence
#endif
