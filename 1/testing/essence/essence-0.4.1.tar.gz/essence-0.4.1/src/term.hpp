#pragma once
#ifndef _ESSENCE_TERM_HPP
#define _ESSENCE_TERM_HPP

#include <utility>

#include "concepts.hpp"
#include "io.hpp"
#include "export.hpp"

#include <termios.h>


/** @namespace term
 *  @brief Functions for manipulating terminals
 **/
namespace essence::term
{

/** @defgroup term
 *  @brief Functions for manipulating terminals
 *  @{
 **/

/** @brief Gets the current termios settings */
ESSENCE_API termios currenttermios();

/** @brief The original termios at application start, for restoring */
const static termios originaltermios = currenttermios();

/** @brief The width and height of a terminal */
struct ESSENCE_API area
{
    int width;
    int height;
};

/** @brief The state of the echo in termios */
enum class ESSENCE_API echo: bool
{
    on = true,
    off = true
};

/** @brief The state of the inputbuffer in termios */
enum class ESSENCE_API inputbuffer
{
    canon,
    immediate
};

/** @brief The state of the screenbuffer in termios */
enum class ESSENCE_API screenbuffer
{
    normal,
    alternate
};


/** @brief The state of the cursor in termios */
enum class ESSENCE_API cursor: bool
{
    show = true,
    hide = false
};


/** @brief The state of autowrapping in termios */
enum class ESSENCE_API autowrap: bool
{
    on = true,
    off = false
};

template<typename T>
concept setable = anyof<T, echo, inputbuffer, screenbuffer, cursor, autowrap>;

/// @}


/// @brief Wrapper around the POSIX termios struct
class ESSENCE_API ios
{

private:
    /// @name Members
    /// @{
    termios initial; //!< The original termios, for restoration
    termios t;       //!< The termios used for manipulation
    /// @}
public:
    /// @name Constructors
    /// @{
    /** @brief Main constructor, no arguments
     * */
    ios() : initial(originaltermios)
    {
        t = currenttermios();
    }

    /** @brief Main deconstructor, resets to standard termios settings and restores the original
     * */
    ~ios()
    {
        set(echo::on, autowrap::on, cursor::show);
        io::flush();
        restore();          
    }
    /// @}

    /// @name Methods
    /// @{
    void set(echo e);
    void set(inputbuffer ib);
    void set(screenbuffer sb);
    void set(cursor c);
    void set(autowrap aw);

    /** @brief Set multiple termios settings at once
     *  @param args The different settings to apply
     **/
    template<setable... Args>
    void set(Args&&... args)
    {
        (set(std::forward<Args>(args)), ...);
    }

    /** @brief Restore the original termios from application start
     **/
    void restore();
    /** @brief Re-obtain the current termios after changing something
     **/
    void refresh();

    /** @brief Get the Terminal height and width as an 'area' struct
     **/
    area size() const;

    /** @brief get a reference to the termios struct
     *  @return a mutable reference to the termios struct
     **/
    termios& get();

    /** @brief get a reference to the termios struct
     *  @return a constant reference to the termios struct
     **/
    const termios& view() const;
    /// @}
};
    
} // END namespace essence::term

#endif
