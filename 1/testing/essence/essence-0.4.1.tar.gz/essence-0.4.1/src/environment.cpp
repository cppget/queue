#include "environment.hpp"

#include <cstdlib>

extern char **environ;

namespace essence::env
{

auto get(const char *key) -> std::string
{
    const char *value = getenv(key);
    return (value == nullptr) ? "" : value;
}

auto get(const char *key, const char *fallback) -> std::string
{
    const char *value = getenv(key);
    return (value == nullptr) ? fallback : value;
}

auto get(std::string_view key) -> std::string
{
    const char *value = getenv(key.data());
    return (value == nullptr) ? "" : value;
}

auto get(std::string_view key, std::string_view fallback) -> std::string
{
    const char *value = getenv(key.data());
    return (value == nullptr) ? fallback.data() : value;
}

auto get(const std::string& key) -> std::string
{
    const char *value = getenv(key.c_str());
    return (value == nullptr) ? "" : value;
}

auto get(const std::string &key, const std::string &fallback) -> std::string
{
    const char *value = getenv(key.c_str());
    return (value == nullptr) ? fallback : value;
}

auto vec(const char **envs) -> std::vector<std::string>
{
    std::vector<std::string> vv;
    std::size_t n = 0;
    while (envs[n] != nullptr)
    {
        vv.emplace_back(envs[n]);
        ++n;
    }
    return vv;
}

auto vec(char **envs) -> std::vector<std::string>
{
    std::vector<std::string> vv;
    std::size_t n = 0;
    while (envs[n] != nullptr)
    {
        vv.emplace_back(envs[n]);
        ++n;
    }
    return vv;
}

auto vec() -> std::vector<std::string>
{
    std::vector<std::string> vv;
    std::size_t n = 0;
    while (environ[n] != nullptr)
    {
        vv.emplace_back(environ[n]);
        ++n;
    }
    return vv;
}

auto map(const char **envs) -> std::map<std::string, std::string>
{
    std::map<std::string, std::string> mm;
    std::size_t n = 0;
    std::string line;
    while (envs[n] != nullptr)
    {
        line.assign(envs[n]);
        if (auto pos = line.find('='); pos != std::string::npos)
        {
            mm.insert_or_assign(line.substr(0, pos), line.substr(pos + 1));
        }
        else
        {
            ++n;
            continue;
        }
        ++n;
    }
    return mm;
}

auto map(char **envs) -> std::map<std::string, std::string>
{
    std::map<std::string, std::string> mm;
    std::size_t n(0);
    std::string line;
    while (envs[n] != nullptr)
    {
        line.assign(envs[n]);
        if (auto pos = line.find('='); pos != std::string::npos)
        {
            mm.insert_or_assign(line.substr(0, pos), line.substr(pos + 1));
        }
        else
        {
            ++n;
            continue;
        }
        ++n;
    }
    return mm;
}

auto map() -> std::map<std::string, std::string>
{
    std::map<std::string, std::string> mm;
    std::size_t n(0);
    std::string line;
    while (environ[n] != nullptr)
    {
        line.assign(environ[n]);
        if (auto pos = line.find('='); pos != std::string::npos)
        {
            mm.insert_or_assign(line.substr(0, pos), line.substr(pos + 1));
        }
        else
        {
            ++n;
            continue;
        }
        ++n;
    }
    return mm;
}

auto umap() -> std::unordered_map<std::string, std::string>
{
    std::unordered_map<std::string, std::string> mm;
    std::size_t n(0);
    std::string line;
    while (environ[n] != nullptr)
    {
        line.assign(environ[n]);
        if (auto pos = line.find('='); pos != std::string::npos)
        {
            mm.insert_or_assign(line.substr(0, pos), line.substr(pos + 1));
        }
        else
        {
            ++n;
            continue;
        }
        ++n;
    }
    return mm;
}

auto umap(char **envs) -> std::unordered_map<std::string, std::string>
{
    std::unordered_map<std::string, std::string> mm;
    std::size_t n(0);
    std::string line;
    while (envs[n] != nullptr)
    {
        line.assign(envs[n]);
        if (auto pos = line.find('='); pos != std::string::npos)
        {
            mm.insert_or_assign(line.substr(0, pos), line.substr(pos + 1));
        }
        else
        {
            ++n;
            continue;
        }
        ++n;
    }
    return mm;
}

auto umap(const char **envs) -> std::unordered_map<std::string, std::string>
{
    std::unordered_map<std::string, std::string> mm;
    std::size_t n(0);
    std::string line;
    while (envs[n] != nullptr)
    {
        line.assign(envs[n]);
        if (auto pos = line.find('='); pos != std::string::npos)
        {
            mm.insert_or_assign(line.substr(0, pos), line.substr(pos + 1));
        }
        else
        {
            ++n;
            continue;
        }
        ++n;
    }
    return mm;
}


}
