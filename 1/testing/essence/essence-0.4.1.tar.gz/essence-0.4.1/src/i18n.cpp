#if not defined(USING_ESSENCE_MODULE)
#include "essence/i18n.hpp"
#endif

namespace essence::i18n
{
    
auto _(const char *msgid) -> std::string
{
    return ::gettext(msgid);
}

auto _n(const char *singular, const char *plural, unsigned long int n) -> std::string
{
    return ::ngettext(singular, plural, n);
}

}