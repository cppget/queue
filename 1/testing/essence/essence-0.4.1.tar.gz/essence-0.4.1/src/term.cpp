#include <unistd.h>
#include <sys/ioctl.h>
#include <termios.h>

#include <stdexcept>

#include "term.hpp"
#include "io.hpp"

namespace essence::term
{

termios currenttermios()
{
    auto current = termios{};
    tcgetattr(STDIN_FILENO, &current);
    return current;
}

auto ios::restore() -> void
{
    tcsetattr(STDIN_FILENO, TCSAFLUSH, &initial);
}

auto ios::refresh() -> void
{
    tcgetattr(STDIN_FILENO, &t);
}

auto ios::size() const -> area
{
    winsize ws;
    int rc = ioctl(STDIN_FILENO, TIOCGWINSZ, &ws);
    if (rc == -1)
        throw std::runtime_error("ioctl() was unable to read window size");
    return {.width = ws.ws_col, .height = ws.ws_row};
}

auto ios::set(echo e) -> void
{
    auto const flag = (e == echo::on) ? ECHO : ~(ECHO);
    refresh();
    t.c_lflag &= flag;
    tcsetattr(STDIN_FILENO, TCSAFLUSH, &t);
}

auto ios::set(inputbuffer ib) -> void
{
    auto const flag = (ib == inputbuffer::canon) ? ICANON : ~(ICANON);
    refresh();
    t.c_lflag &= flag;
    if (ib == inputbuffer::immediate)
        t.c_cc[VMIN] = 1;
    tcsetattr(STDIN_FILENO, TCSAFLUSH, &t);
}

auto ios::set(screenbuffer sb) -> void
{
    if (sb == screenbuffer::normal)
        io::write("\033[" "?1049l");
    else if (sb == screenbuffer::alternate)
        io::write("\033[" "?1049h");
}

auto ios::set(cursor c) -> void
{
    if (c == cursor::show)
        io::write("\033[" "?25h");
    else if (c == cursor::hide)
        io::write("\033[" "?25l");
}

auto ios::set(autowrap aw) -> void
{
    if (aw == autowrap::on)
        io::write("\033[" "?7h");
    else if (aw == autowrap::off)
        io::write("\033[" "?7l");
}


auto ios::get() -> termios&
{
    return t;
}

auto ios::view() const -> const termios&
{
    return t;
}

} // END namespace essence::term
