#pragma once

#ifndef _ESSENCE_MACROS_HPP
#define _ESSENCE_MACROS_HPP

#define ESSENTIAL using namespace essence
#define USINGFS namespace fs = std::filesystem

#endif
