#pragma once
#ifndef _ESSENCE_COLOR_HPP
#define _ESSENCE_COLOR_HPP

#include "types.hpp"
#include "export.hpp"

#include <initializer_list>
#include <iostream>
#include <ostream>
#include <regex>
#include <concepts>

namespace essence::ansi
{

using namespace std::string_view_literals;

static const std::regex escape(R"(\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~]|\][^\x07\x1B]*(?:\x07|\x1B\\)))");
ESSENCE_API void strip(std::string& in);

template<typename t>
concept StringLike = std::convertible_to<t, std::string_view> or std::same_as<t, char>;

static constexpr std::string_view none      = "\033[0m";
static constexpr std::string_view bold      = "\033[1m";
static constexpr std::string_view dim       = "\033[2m";
static constexpr std::string_view italic    = "\033[3m";
static constexpr std::string_view underline = "\033[4m";
static constexpr std::string_view blink     = "\033[5m";
static constexpr std::string_view hidden    = "\033[8m";
static constexpr std::string_view strike    = "\033[9m";

namespace reset
{
	static constexpr std::string_view bold      = "\033[22m";
	static constexpr std::string_view dim       = "\033[22m";
	static constexpr std::string_view italic    = "\033[23m";
	static constexpr std::string_view underline = "\033[24m";
	static constexpr std::string_view blink     = "\033[25m";
	static constexpr std::string_view hidden    = "\033[28m";
	static constexpr std::string_view strike    = "\033[29m";
}; // ns: ansi::reset

namespace fg
{
	
    static constexpr std::string_view black   = "\033[30m";
	static constexpr std::string_view red     = "\033[31m";
	static constexpr std::string_view green   = "\033[32m";
	static constexpr std::string_view yellow  = "\033[33m";
	static constexpr std::string_view blue    = "\033[34m";
	static constexpr std::string_view magenta = "\033[35m";
	static constexpr std::string_view cyan    = "\033[36m";
	static constexpr std::string_view white   = "\033[37m";
	static constexpr std::string_view reset   = "\033[39m";

    ESSENCE_API std::string rgb(u8 red, u8 green, u8 blue);
    
    namespace bright
    {
        static constexpr std::string_view black   = "\033[90m";
        static constexpr std::string_view red     = "\033[91m";
        static constexpr std::string_view green   = "\033[92m";
        static constexpr std::string_view yellow  = "\033[93m";
        static constexpr std::string_view blue    = "\033[94m";
        static constexpr std::string_view magenta = "\033[95m";
        static constexpr std::string_view cyan    = "\033[96m";
        static constexpr std::string_view white   = "\033[97m";

    }; // ns: ansi::fg::bright

}; // ns: ansi::fg

namespace bg
{
	static constexpr std::string_view black   = "\033[40m";
	static constexpr std::string_view red     = "\033[41m";
	static constexpr std::string_view green   = "\033[42m";
	static constexpr std::string_view yellow  = "\033[43m";
	static constexpr std::string_view blue    = "\033[44m";
	static constexpr std::string_view magenta = "\033[45m";
	static constexpr std::string_view cyan    = "\033[46m";
	static constexpr std::string_view white   = "\033[47m";
	static constexpr std::string_view reset   = "\033[49m";
    
    ESSENCE_API std::string rgb(u8 red, u8 green, u8 blue);
    
    namespace bright
    {
        static constexpr std::string_view black   = "\033[100m";
        static constexpr std::string_view red     = "\033[101m";
        static constexpr std::string_view green   = "\033[102m";
        static constexpr std::string_view yellow  = "\033[103m";
        static constexpr std::string_view blue    = "\033[104m";
        static constexpr std::string_view magenta = "\033[105m";
        static constexpr std::string_view cyan    = "\033[106m";
        static constexpr std::string_view white   = "\033[107m";
    }; // ns: ansi::bg::bright

}; // ns: ansi::bg


class ESSENCE_API message
{
private:
    std::string m_text;
public:
    message(std::string ptext) : m_text(std::move(ptext)) {};

    message() = default;
    ~message() = default;

    constexpr bool operator==(const message&) const = default;
    constexpr bool operator!=(const message&) const = default;

    message& append(const char *s);
    message& append(std::string_view s);
    message& append(const std::string &s);
    message& append(char c);
    message& append(std::initializer_list<std::string_view> strs);
    message& append(std::initializer_list<char> chars);

    template <StringLike... strs>
    requires (sizeof...(strs) >= 2)
    message& append(strs&&... args) {
        (append(std::forward<strs>(args)), ...);
        return *this;
    }

    message& operator+=(const std::string& s);
    message& operator+=(const char *s);
    message& operator+=(std::string_view s);
    message& operator+=(char c);
    message& operator+=(message &other);

    friend message operator+(const message &lhs, const std::string &rhs);
    friend message operator+(const message &lhs, const char *rhs);
    friend message operator+(const message &lhs, std::string_view rhs);
    friend message operator+(const message &lhs, char rhs);
    friend message operator+(message &lhs, message &rhs);

    message& newline();
    message& nl();
    message& clear();
    message& reset();
    message& text(std::string txt);
    message& clean();
    std::string str();
    friend std::ostream &operator<<(std::ostream &os, message &self);

}; // class: message
}; // ns: essence::ansi

#endif
