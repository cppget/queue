#pragma once
#ifndef _ESSENCE_ENVIRONMENT_HPP
#define _ESSENCE_ENVIRONMENT_HPP

#include "export.hpp"

#include <string>
#include <unordered_map>
#include <map>
#include <vector>

/** @namespace env
 *  @brief Environment variable related utilities
 **/
namespace essence::env
{

/// @defgroup env
/// @{
    
/** @brief Retrieve an environment variable by name
 *  @param key The variable name
 *  @return The found variable value or an empty string
 **/
ESSENCE_API std::string get(const char *key);

/** @brief Retrieve an environment variable by name
 *  @param key The variable name
 *  @param fallback Optional default value when key is not set
 *  @return The found variable value or the fallback value
 **/
ESSENCE_API std::string get(const char *key, const char *fallback);

/** @brief Retrieve an environment variable by name
 *  @param key The variable name
 *  @return The found variable value or an empty string
 **/
ESSENCE_API std::string get(std::string_view key);

/** @brief Retrieve an environment variable by name
 *  @param key The variable name
 *  @param fallback Optional default value when key is not set
 *  @return The found variable value or the fallback value
 **/
ESSENCE_API std::string get(std::string_view key, std::string_view fallback);

/** @brief Retrieve an environment variable by name
 *  @param key The variable name
 *  @return The found variable value or an empty string
 **/
ESSENCE_API std::string get(const std::string &key);

/** @brief Retrieve an environment variable by name
 *  @param key The variable name
 *  @param fallback Optional default value when key is not set
 *  @return The found variable value or the fallback value
 **/
ESSENCE_API std::string get(const std::string &key, const std::string &fallback);

/** @brief Convert the null-terminated environ/envp pointer into a vector
 *  @param envs The null-terminated environ pointer
 *  @return A vector of each entry as strings
 **/
ESSENCE_API std::vector<std::string> vec(const char **envs);
ESSENCE_API std::vector<std::string> vec(char **envs);
ESSENCE_API std::vector<std::string> vec();

/** @brief Convert the null-terminated environ/envp pointer into a map
 *  @param envs The null-terminated environ pointer
 *  @return A map of each entry as string pairs
 **/
ESSENCE_API std::map<std::string, std::string> map(const char **envs);
ESSENCE_API std::map<std::string, std::string> map(char **envs);
ESSENCE_API std::map<std::string, std::string> map();

ESSENCE_API std::unordered_map<std::string, std::string> umap(const char **envs);
ESSENCE_API std::unordered_map<std::string, std::string> umap(char **envs);
ESSENCE_API std::unordered_map<std::string, std::string> umap();

/// @}

} // END namespace essence::env

#endif
