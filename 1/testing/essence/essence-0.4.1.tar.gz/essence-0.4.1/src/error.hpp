#pragma once
#ifndef _ESSENCE_ERROR_HPP
#define _ESSENCE_ERROR_HPP

#include "export.hpp"

#include <string>
#include <format>
#include <string_view>

namespace essence
{

class ESSENCE_API error
{
private:
    std::string m_message = "undocumented error";

public:
    error(std::string_view msg) : m_message(msg) {}

    template<typename... fmt>
    error(std::string_view msg, fmt&&... args)
        : m_message{std::vformat(msg.data(), std::make_format_args(args...))}
    {}

    error() = default;
    ~error() = default;

    constexpr bool operator==(const error&) const = default;
    constexpr bool operator!=(const error&) const = default;

    std::string_view message() const noexcept;
    error& message(std::string_view msg) noexcept;
    
    template<typename... fmt>
    error& message(std::string_view msg, fmt&&... args) noexcept
    {
        m_message.assign(
            std::vformat(msg.data(), std::make_format_args(args...))
        );
        return *this;
    }

    void die() const noexcept;

};

};

#endif
