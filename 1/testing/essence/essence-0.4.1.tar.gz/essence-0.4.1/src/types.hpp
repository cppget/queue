#pragma once
#ifndef _ESSENCE_TYPES_HPP
#define _ESSENCE_TYPES_HPP

#include <cstdint>
#include <cstddef>
#include <sys/types.h>

#ifdef __SIZOF_INT128__
#define int128_t __int128
#define uint128_t unsigned __int128
using i128 = int128_t;
using u128 = uint128_t;
#endif

namespace essence
{

using u8 = uint8_t;
using i8 = int8_t;
using u16 = uint16_t;
using i16 = int16_t;
using u32 = uint32_t;
using i32 = int32_t;
using u64 = uint64_t;
using i64 = int64_t;
using null = std::nullptr_t;
using usize = size_t;
using isize = ptrdiff_t;
using f32 = float;
using f64 = double;
using uint = unsigned int;
using ulong = unsigned long int;
using ullong = unsigned long long int;
using llong = long long int;
using uchar = unsigned char;
using ushort = unsigned short int;
using umax = uintmax_t;
using imax = intmax_t;
using off = off_t;

constexpr static const char nul = '\0';

using blkcnt = blkcnt_t;
using blksize = blksize_t;

};

#endif
