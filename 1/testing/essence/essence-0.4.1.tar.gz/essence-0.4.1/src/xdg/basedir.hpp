#pragma once

#ifndef _ESSENCE_XDG_BASEDIR_HPP
#define _ESSENCE_XDG_BASEDIR_HPP

#include "../export.hpp"

#include <filesystem>
#include <string>
#include <vector>
#include <ostream>

namespace essence::xdg::get
{

ESSENCE_API std::filesystem::path home();
ESSENCE_API std::filesystem::path config();
ESSENCE_API std::filesystem::path cache();
ESSENCE_API std::filesystem::path data();
ESSENCE_API std::filesystem::path state();
ESSENCE_API std::filesystem::path runtime();

ESSENCE_API std::vector<std::filesystem::path> configs();
ESSENCE_API std::vector<std::filesystem::path> datas();

};


namespace essence::xdg
{

class ESSENCE_API directory
{
private:
    std::filesystem::path m_path;

public:
    directory(std::filesystem::path p);
    directory(const std::string &p);
    directory(std::string_view p);
    directory(const char *p);
    directory();

    ~directory() = default;

    constexpr bool operator==(const directory&) const = default;
    constexpr bool operator!=(const directory&) const = default;

    std::filesystem::path path() const noexcept;

    directory& path(std::filesystem::path p);
    directory& path(std::string_view p);
    directory& path(const std::string &p);
    directory& path(const char *p);

    bool exists() const noexcept;
    void create() noexcept;
    
    directory subdir(std::string_view name) const noexcept;
    std::string name() const noexcept;
    std::string string() const noexcept;
    const char *c_str() const noexcept;

    std::filesystem::recursive_directory_iterator reciter();
    std::filesystem::directory_iterator iter();
    std::filesystem::file_status status();

    friend std::ostream& operator<<(std::ostream &os, const directory &self);
};


struct ESSENCE_API dir
{
    static const directory home;
    static const directory config;
    static const directory cache;
    static const directory data;
    static const directory state;
    static const directory runtime;
};

ESSENCE_API inline const directory dir::home{get::home()};
ESSENCE_API inline const directory dir::cache{get::cache()};
ESSENCE_API inline const directory dir::config{get::config()};
ESSENCE_API inline const directory dir::data{get::data()};
ESSENCE_API inline const directory dir::state{get::state()};
ESSENCE_API inline const directory dir::runtime{get::runtime()};

struct ESSENCE_API dirs
{
    static const std::vector<directory> config;
    static const std::vector<directory> data;
};

ESSENCE_API inline const std::vector<directory> dirs::config = [] () -> std::vector<directory>
{
    std::vector<directory> result;
    auto aux = get::configs();
    result.reserve(aux.size());
    for (const std::filesystem::path &p: aux)
        result.push_back(p);
    return result;
}();

ESSENCE_API inline const std::vector<directory> dirs::data = [] () -> std::vector<directory>
{
    std::vector<directory> result;
    auto aux = get::datas();
    result.reserve(aux.size());
    for (const std::filesystem::path &p: aux)
        result.push_back(p);
    return result;
}();

};

#endif
