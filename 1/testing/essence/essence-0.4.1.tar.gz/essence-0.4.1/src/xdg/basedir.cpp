#include <unistd.h>
#include <string.h>
#include <pwd.h>
#include <stdlib.h>
#include <utility>
#include <filesystem>
#include <vector>
#include <print>
#include <string>

#include "basedir.hpp"
#include "../types.hpp"
#include "../exceptions.hpp"
#include "../str.hpp"
    
namespace essence::xdg::get
{

auto home() -> std::filesystem::path
{
    namespace fs = std::filesystem;
    const char *ev = getenv("HOME");
    if (ev != nullptr and strlen(ev) > 0)
        return fs::path(ev);
    
    usize pwrmax = sysconf(_SC_GETPW_R_SIZE_MAX);
    if (pwrmax == -1) pwrmax = 16384;

    char *buffer = (char*)malloc(pwrmax);
    if (buffer == nullptr)
        throw rterror("failed to allocate memory for getpwuid()");

    struct passwd pw;
    struct passwd *aux;
    uid_t id = geteuid();

    int rc = getpwuid_r(id, &pw, buffer, pwrmax, &aux);
    if ((rc != 0) or (aux == nullptr))
    {
        free(buffer);
        throw rterror("failed to get passwd entry for uid {}", id);
    }

    const char *homedir = pw.pw_dir;
    auto result = fs::path(homedir);
    free(buffer);
    return result;
}

auto config() -> std::filesystem::path
{
    namespace fs = std::filesystem;
    const char *ev = getenv("XDG_CONFIG_HOME");
    if (ev != nullptr and strlen(ev) > 0)
        return fs::path(ev);
    return fs::path(home() / ".config");
}

auto cache() -> std::filesystem::path
{
    namespace fs = std::filesystem;
    const char *ev = getenv("XDG_CACHE_HOME");
    if (ev != nullptr and strlen(ev) > 0)
        return fs::path(ev);
    return fs::path(home() / ".cache");
}

auto data() -> std::filesystem::path
{
    namespace fs = std::filesystem;
    const char *ev = getenv("XDG_DATA_HOME");
    if (ev != nullptr and strlen(ev) > 0)
        return fs::path(ev);
    return fs::path(home() / ".local" / "share");
}

auto state() -> std::filesystem::path
{
    namespace fs = std::filesystem;
    const char *ev = getenv("XDG_STATE_HOME");
    if (ev != nullptr and strlen(ev) > 0)
        return fs::path(ev);
    return fs::path(home() / ".local" / "state");
}

auto runtime() -> std::filesystem::path
{
    namespace fs = std::filesystem;
    const char *ev = getenv("XDG_RUNTIME_DIR");
    if (ev != nullptr and strlen(ev) > 0)
        return fs::path(ev);
    uid_t id = geteuid();
    fs::path runuser("/run/user");
    return fs::path(runuser / std::to_string(id));
}

auto configs() -> std::vector<std::filesystem::path>
{
    namespace fs = std::filesystem;
    const char *ev = getenv("XDG_CONFIG_DIRS");
    if (ev != nullptr and strlen(ev) > 0)
    {
        std::vector<fs::path> result{};
        auto parts = str::split(ev, ':');
        for (const std::string &part: parts)
            result.push_back(part);
        return result;
    }
    else
    {
        return std::vector<fs::path>
        {
            "/etc/local/xdg",
            "/etc/xdg"
        };
    }
}

auto datas() -> std::vector<std::filesystem::path>
{
    namespace fs = std::filesystem;
    const char *ev = getenv("XDG_DATAS_DIRS");
    if (ev != nullptr and strlen(ev) > 0)
    {
        std::vector<fs::path> result{};
        auto parts = str::split(ev, ':');
        for (const std::string &part: parts)
            result.push_back(part);
        return result;
    }
    else
    {
        return std::vector<fs::path>
        {
            "/usr/local/share",
            "/usr/share"
        };
    }
}

};

namespace essence::xdg
{

directory::directory(std::filesystem::path p)
{
    namespace fs = std::filesystem;
    this->m_path = std::move(p);
    if (fs::exists(m_path) and (not fs::is_directory(m_path)))
        throw invalidarg("path '{}' exists and is not a directory.", m_path.string());
}

directory::directory(const std::string &p)
{
    namespace fs = std::filesystem;
    this->m_path.assign(p);
    if (fs::exists(m_path) and (not fs::is_directory(m_path)))
        throw invalidarg("path '{}' exists and is not a directory.", m_path.string());
}

directory::directory(std::string_view p)
{
    namespace fs = std::filesystem;
    this->m_path.assign(p);
    if (fs::exists(m_path) and (not fs::is_directory(m_path)))
        throw invalidarg("path '{}' exists and is not a directory.", m_path.string());
}

directory::directory(const char *p)
{
    namespace fs = std::filesystem;
    this->m_path.assign(p);
    if (fs::exists(m_path) and (not fs::is_directory(m_path)))
        throw invalidarg("path '{}' exists and is not a directory.", m_path.string());
}

directory::directory()
{
    namespace fs = std::filesystem;
    this->m_path.assign(get::home());
    if (fs::exists(m_path) and (not fs::is_directory(m_path)))
        throw invalidarg("path '{}' exists and is not a directory.", m_path.string());
}

auto directory::path() const noexcept -> std::filesystem::path
{
    return m_path;
}

auto directory::path(std::filesystem::path p) -> directory&
{
    namespace fs = std::filesystem;
    m_path.assign(std::move(p));
    if (fs::exists(m_path) and (not fs::is_directory(m_path)))
        throw invalidarg("path '{}' exists and is not a directory.", m_path.string());
    return *this;
}

auto directory::path(std::string_view p) -> directory&
{
    namespace fs = std::filesystem;
    m_path.assign(p);
    if (fs::exists(m_path) and (not fs::is_directory(m_path)))
        throw invalidarg("path '{}' exists and is not a directory.", m_path.string());
    return *this;
}

auto directory::path(const std::string &p) -> directory&
{
    namespace fs = std::filesystem;
    m_path.assign(p);
    if (fs::exists(m_path) and (not fs::is_directory(m_path)))
        throw invalidarg("path '{}' exists and is not a directory.", m_path.string());
    return *this;
}

auto directory::path(const char *p) -> directory&
{
    namespace fs = std::filesystem;
    m_path.assign(p);
    if (fs::exists(m_path) and (not fs::is_directory(m_path)))
        throw invalidarg("path '{}' exists and is not a directory.", m_path.string());
    return *this;
}


auto directory::exists() const noexcept -> bool
{
    return std::filesystem::exists(m_path);
}

auto directory::create() noexcept -> void
{
    try
    {
        std::filesystem::create_directories(m_path);
    }
    catch (const std::filesystem::filesystem_error &e)
    {
        std::println(stderr, "failed to create directory '{}': {}", m_path.string(), e.what());
    }
}

auto directory::subdir(std::string_view name) const noexcept -> directory
{
    return directory(m_path / name);
}

auto directory::string() const noexcept -> std::string
{
    return m_path.string();
}

auto directory::c_str() const noexcept -> const char*
{
    return m_path.c_str();
}

auto directory::name() const noexcept -> std::string
{
    return m_path.filename().string();
}

auto directory::reciter() -> std::filesystem::recursive_directory_iterator
{
    return std::filesystem::recursive_directory_iterator(m_path);
}

auto directory::iter() -> std::filesystem::directory_iterator
{
    return std::filesystem::directory_iterator(m_path);
}

auto directory::status() -> std::filesystem::file_status
{
    return std::filesystem::status(m_path);
}

auto operator<<(std::ostream &os, const directory &self) -> std::ostream&
{
    os << self.string();
    return os;
}

};
