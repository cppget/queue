#pragma once

#ifndef _ESSENCE_HPP
#define _ESSENCE_HPP

/* IWYU pragma: begin_exports */
#include "version.hpp"
#include "export.hpp"
#include "error.hpp"
#include "types.hpp"
#include "macros.hpp"
#include "concepts.hpp"
#include "exceptions.hpp"
#include "encoding.hpp"
#include "environment.hpp"
#include "io.hpp"
#include "i18n.hpp"
#include "str.hpp"
#include "term.hpp"
#include "color.hpp"
#include "process.hpp"
#include "xdg.hpp"
#include "uni.hpp"
/* IWYU pragma: end_exports */

#endif
