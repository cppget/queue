#pragma once
#ifndef _ESSENCE_STR_HPP
#define _ESSENCE_STR_HPP

#include "export.hpp"

#include <string>
#include <vector>

namespace essence::str::xform
{

inline auto split = [] (auto &&part)
{
    return std::string
    {
        part.begin(),
        part.end()
    };
};

};


/** @namespace str
 *  @brief String manipulation functions
 **/
namespace essence::str
{

constexpr static const std::string whitespace{" \n\r\t\f\v"};

/** @defgroup str
 *  @brief String manipulation functions
 *  @{
 **/

/** @brief Trim leading whitespace from a string
 *  @param s Mutable reference to the input string
 **/
ESSENCE_API void trim_left(std::string &s) noexcept;

/** @brief Trim trailing whitespace from a string
 *  @param s Mutable reference to the input string
 **/
ESSENCE_API void trim_right(std::string &s) noexcept;

/** @brief Trim trailing/leading whitespace from a string
 *  @param s Mutable reference to the input string
 **/
ESSENCE_API void trim(std::string &s) noexcept;


/** @brief Trim leading whitespace from a string
 *  @param s Constant reference to the input string
 *  @return A new trimmed string
 **/
ESSENCE_API std::string trim_left_copy(const std::string &s) noexcept;

/** @brief Trim trailing whitespace from a string
 *  @param s Constant reference to the input string
 *  @return A new trimmed string
 **/
ESSENCE_API std::string trim_right_copy(const std::string &s) noexcept;

/** @brief Trim trailing/leading whitespace from a string
 *  @param s Constant reference to the input string
 *  @return A new trimmed string
 **/
ESSENCE_API std::string trim_copy(const std::string &s) noexcept;


/** @brief split a string based on a delimiter
 *  @param s The string to split
 *  @param delim The character to split on
 *  @return The split vector of substrings
 **/
ESSENCE_API std::vector<std::string> split(const std::string& s, char delim);

/** @brief split a string based on a delimiter
 *  @param s The string to split
 *  @param delim The string sequence to split on
 *  @return The split vector of substrings
 **/
ESSENCE_API std::vector<std::string> split(const std::string& s, std::string delim);

/** @brief split a string based on a delimiter
 *  @param s The string to split
 *  @param delim The character to split on
 *  @return The split vector of substrings
 **/
ESSENCE_API std::vector<std::string> split(const char *s, char delim);


/** @brief Substitute occurrences of a substring to another substring
 *  @param s The string to operate on
 *  @param from The substring to replace
 *  @param to The substring to replace 'from' with
 *  @return The transformed input string
 **/
ESSENCE_API std::string replaceall(std::string s, const std::string& from, const std::string& to);

/// @}
    
} // END namespace essence::str

#endif
