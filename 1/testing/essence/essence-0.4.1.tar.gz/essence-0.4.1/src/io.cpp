#include <cstdio>
#include <vector>
#include <string>
#include <string_view>
#include <fstream>
#include <filesystem>
#include "essence/io.hpp"

namespace essence::io
{

auto write(char c, FILE *port) -> void
{
    std::fputc(c, port);
}

auto write(std::string_view s, FILE *port) -> void
{
    for (auto c: s) io::write(c, port);
}

auto write(const char *str, FILE *port) -> void
{
    std::fputs(str, port);
}

auto write(const std::string &str, FILE *port) -> void
{
    io::write(str.c_str(), port);
}

auto flush(FILE* port) -> void
{
    std::fflush(port);
}

auto print(std::string_view msg) -> void
{
    std::fputs(msg.data(), stdout);
}

auto printn(std::string_view msg) -> void
{
    std::fputs(msg.data(), stdout);
    io::write('\n', stdout);
}

auto eprint(std::string_view msg) -> void
{
    std::fputs(msg.data(), stderr);
}

auto eprintn(std::string_view msg) -> void
{
    std::fputs(msg.data(), stderr);
    io::write('\n', stderr);
}

namespace file
{

auto lines(const std::string &path) noexcept -> std::vector<std::string>
{
    namespace fs = std::filesystem;
    if (not fs::exists(path))
        return {};
    std::ifstream handle(path);
    if (not handle)
        return {};
    std::string line{};
    std::vector<std::string> all{};

    while (std::getline(handle, line))
        all.push_back(line);

    return all;
}

auto lines(const std::string &path, std::vector<std::string> &out) noexcept -> void
{
    namespace fs = std::filesystem;
    if (not fs::exists(path))
        return;
    std::ifstream handle(path);
    if (not handle)
        return;
    std::string line{};
    while (std::getline(handle, line))
        out.push_back(line);

    return;
}

};

} // END namespace essence::io
