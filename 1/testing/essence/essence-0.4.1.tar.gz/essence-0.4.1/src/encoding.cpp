#include <string_view>
#include "encoding.hpp"

namespace essence::encoding
{

auto validate(std::string_view s) -> bool
{
    const auto* p = reinterpret_cast<const u8*>(s.data());
    const auto* end = p + s.size();

    while (p < end)
    {
        const u8 b = *p++;

        if (b < 0x80)
            continue;

        u32 cp, cpmin;
        int remaining;

        if ((b & 0xE0) == 0xC0)
        {
            cp = (b & 0x1F);
            cpmin = 0x80;
            remaining = 1;
        }

        else if ((b & 0xF0) == 0xE0)
        {
            cp = (b & 0x0F);
            cpmin = 0x800;
            remaining = 2;
        }

        else if ((b & 0xF8) == 0xF0)
        {
            cp = (b & 0x07);
            cpmin = 0x10000;
            remaining = 3;
        }

        else
        {
            return false;
        }

        while (remaining--)
        {
            if (p >= end) return false;
            const u8 cb = *p++;

            if ((cb & 0xC0) != 0x80)
                return false;

            cp = (cp << 6)|(cb & 0x3F);
        }

        if (cp < cpmin)
            return false;

        if ((cp >= 0xD800) and (cp <= 0xDFFF))
            return false;

        if (cp > 0x10FFFF)
            return false;
    }
    return true;
}

auto count(std::string_view s) -> usize
{
    const auto* p = reinterpret_cast<const u8*>(s.data());
    const auto* end = (p + s.size());

    usize n = 0;
    while (p < end)
        n += (*p++ & 0xC0) != 0x80;
    return n;
}

}
