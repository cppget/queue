#pragma once

#ifndef _ESSENCE_EXCEPTIONS_HPP
#define _ESSENCE_EXCEPTIONS_HPP

#include <format>
#include <stdexcept>

namespace essence
{

/// @brief Wrapper around std::runtime_error directly accepting a format string
class rterror : public std::runtime_error
{
public:
    template<typename... Args>
    explicit rterror(std::format_string<Args...> message, Args&&... args)
        : std::runtime_error(std::format(message, std::forward<Args>(args)...))
    {}

    explicit rterror(std::string message)
        : std::runtime_error(message)
    {}
};

/// @brief Wrapper around std::invalid_argument directly accepting a format string
class invalidarg : public std::invalid_argument
{
public:
    template<typename... Args>
    explicit invalidarg(std::format_string<Args...> message, Args&&... args)
        : std::invalid_argument(std::format(message, std::forward<Args>(args)...))
    {}
    
    explicit invalidarg(std::string message)
        : std::invalid_argument(message)
    {}
};

/// @brief Wrapper around std::logic_error directly accepting a format string
class logicerr : public std::logic_error
{
public:
    template<typename... Args>
    explicit logicerr(std::format_string<Args...> message, Args&&... args)
        : std::logic_error(std::format(message, std::forward<Args>(args)...))
    {}

    explicit logicerr(std::string message)
        : std::logic_error(message)
    {}
};

}; // ns: essence


#endif
