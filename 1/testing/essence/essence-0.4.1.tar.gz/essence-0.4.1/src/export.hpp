#pragma once

#if defined(ESSENCE_STATIC)

    #define ESSENCE_API __attribute__((visibility("default")))

#elif defined(ESSENCE_STATIC_BUILD)

    #define ESSENCE_API __attribute__((visibility("default")))

#elif defined(ESSENCE_SHARED)

    #ifdef _WIN32
        #define ESSENCE_API __declspec(dllimport)
    #else
        #define ESSENCE_API __attribute__((visibility("default")))
    #endif

#elif defined(ESSENCE_SHARED_BUILD)

    #ifdef _WIN32
        #define ESSENCE_API __declspec(dllexport)
    #else
        #define ESSENCE_API __attribute__((visibility("default")))
    #endif

#else

    #define ESSENCE_API __attribute__((visibility("default")))

#endif
