// Tests compatibility with iosfwd
#include <iosfwd>
#include "../src/pugixml.hpp"
