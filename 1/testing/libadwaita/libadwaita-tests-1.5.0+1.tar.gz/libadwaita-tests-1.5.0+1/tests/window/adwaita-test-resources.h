#ifndef __RESOURCE_test_H__
#define __RESOURCE_test_H__

#include <gio/gio.h>

G_GNUC_INTERNAL GResource *test_get_resource (void);
#endif
