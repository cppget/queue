#include <adwaita.h>

#undef NDEBUG
#include <assert.h>

int
main ()
{
  adw_init ();
  return 0;
}
