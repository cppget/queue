/* SPDX-FileCopyrightText: 2017 Mattias Jansson
 * SPDX-License-Identifier: Unlicense OR MIT
 */

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

struct thread_arg {
	void (*fn)(void*);
	void* arg;
};
typedef struct thread_arg thread_arg;

extern uintptr_t
thread_run(thread_arg* arg);

extern void
thread_exit(uintptr_t value);

extern uintptr_t
thread_join(uintptr_t handle);

extern void
thread_sleep(int milliseconds);

extern void
thread_yield(void);

#ifdef __cplusplus
}
#endif
