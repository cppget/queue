# libminhook - minimalistic x86/x64 API hooking library for Windows

This is a `build2` package for the [`MinHook`](https://github.com/tsudakageyu/minhook)
C library. It is a minimalistic API hooking library for Windows that supports
both x86 and x64: it overwrites the first few instructions of a target function
with a jump to a detour and provides a trampoline to call the original.

MinHook is Windows-only (it uses the Win32 API and rewrites machine code) and,
accordingly, this package only builds for Windows targets (MSVC and MinGW).


## Usage

To start using `libminhook` in your project, add the following `depends`
value to your `manifest`, adjusting the version constraint as appropriate:

```
depends: libminhook ^1.3.4
```

Then import the library in your `buildfile`:

```
import libs = libminhook%lib{minhook}
```

And include the single public header in your source code:

```c
#include <MinHook.h>
```

A minimal example that hooks a function:

```c
#include <MinHook.h>

typedef int (WINAPI *ADD)(int, int);
ADD original = NULL;

int WINAPI detour (int a, int b) { return original (a, b) + 1; }

void install (void* target)
{
  MH_Initialize ();
  MH_CreateHook (target, &detour, (void**) &original);
  MH_EnableHook (target);
  /* ... */
  MH_Uninitialize ();
}
```


## Importable targets

This package provides the following importable targets:

```
lib{minhook}
```

`lib{minhook}` is the MinHook library. On Windows the shared member exports the
public `MH_*` functions via the upstream module-definition file.
