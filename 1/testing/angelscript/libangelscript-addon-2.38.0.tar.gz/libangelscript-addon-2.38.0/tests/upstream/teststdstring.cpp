bool TestStdString() { return true; }
