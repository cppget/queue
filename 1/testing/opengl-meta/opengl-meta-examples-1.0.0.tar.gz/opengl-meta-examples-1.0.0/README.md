# OpenGL Examples

[![build2](https://github.com/build2-packaging/vulkan-meta/actions/workflows/build2.yml/badge.svg)](https://github.com/build2-packaging/vulkan-meta/actions/workflows/build2.yml)

This project defines examples using the `libopengl-meta` packages.

The packaging code is licensed under the MIT License.
