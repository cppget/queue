A "Hello, World!" is an introductory computer program.

<br>
<br>


## References

- [libcrypto: build2 packages for OpenSSL toolkit](https://git.build2.org/cgit/packaging/openssl/openssl/tree/libcrypto/)
- [The build2 toolchain introduction](https://build2.org/build2-toolchain/doc/build2-toolchain-intro.xhtml)
- [Build2 linux binary packages](https://masterspline.gitlab.io/build2-linux-packages/deb_packages/)
