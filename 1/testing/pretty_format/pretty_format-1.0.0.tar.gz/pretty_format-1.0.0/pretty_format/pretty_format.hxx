/**
 * @file pretty_format.hxx
 * @brief Custom formatters for STL containers with pretty-print support
 * @author Your Name
 * @date 2025
 * @version 1.1
 *
 * This library extends std::format to automatically print all standard STL
 * containers with customizable formatting.
 *
 * @section features Features
 * - Support for all STL containers (vector, map, set, etc.)
 * - Customizable separators
 * - "Pretty" mode with automatic indentation
 * - User-configurable indentation string (e.g., spaces vs. tabs)
 * - Nested containers at arbitrary depth
 * - Container adapters (stack, queue, priority_queue)
 * - Compile-time validation with C++20 concepts
 *
 * @section usage Basic Usage
 * @code
 * std::vector<int> v = {1, 2, 3};
 * std::cout << std::format("{}", v);        // [1, 2, 3]
 * std::cout << std::format("{:;}", v);      // [1;2;3]
 * std::cout << std::format("{:pretty}", v); // Indented formatting
 *
 * // Custom indentation
 * pretty_format::set_indent_string("    "); // 4 spaces
 * std::cout << std::format("{:pretty}", v);
 * @endcode
 *
 * @section format_spec Format Specification
 * Format syntax: `{:[separator][:pretty]}`
 *
 * Examples:
 * - `{}` - Default separator ", ", no pretty mode
 * - `{:pretty}` - Default separator ", ", pretty mode enabled
 * - `{:;}` - Custom separator ";", no pretty mode
 * - `{: | :pretty}` - Custom separator " | ", pretty mode enabled
 *
 * @section requirements Requirements
 * - C++23 compiler with std::format support
 * - std::ranges support
 *
 * @section limitations IMPORTANT Limitations
 *
 * 1. **Thread-local state**: indent_string is thread-local and persists
 *    across format calls within the same thread. Use reset_indent_string()
 *    to restore defaults.
 *
 * 2. **Container Adapters**: stack/queue/priority_queue are copied
 *    during formatting. O(n) space and time overhead.
 *
 * 3. **Element formattability**: Element types must have std::formatter
 *    specializations. This is validated at instantiation time, not at
 *    compile-time due to circular dependency constraints.
 *    See https://wg21.link/P2286 for discussion.
 *
 * 4. **Invalid format specs**: Format specifications with multiple colons
 *    (e.g., {:a:b:c}) fall back silently to default formatting. This is
 *    intentional for robustness.
 *
 */

#ifndef PRETTY_FORMAT_HXX
#define PRETTY_FORMAT_HXX

#include <array>
#include <deque>
#include <format>
#include <iostream>
#include <list>
#include <map>
#include <print>
#include <queue>
#include <ranges>
#include <set>
#include <span>
#include <stack>
#include <string>
#include <string_view>
#include <tuple>
#include <type_traits>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

/**
 * @namespace pretty_format
 * @brief Automatic std::format support for STL containers with pretty-printing
 *
 * This namespace provides std::formatter specializations for all standard
 * containers. Users include the header and use std::format() directly.
 * The namespace also contains configuration functions for customizing output.
 */
namespace pretty_format {

/**
 * @namespace pretty_format::impl
 * @brief Implementation details - DO NOT use directly
 *
 * This namespace contains the internal implementation of formatters.
 * The API is subject to change without notice between versions.
 * Users should only use the std::formatter specializations.
 */
namespace impl {

// ============================================================================
// CONCEPTS - Type constraints for clear error messages
// ============================================================================

/**
 * @brief Concept for containers whose elements are formattable
 * @tparam Container Type to verify
 *
 * A type satisfies this concept if it satisfies std::ranges::range.
 *
 * @note We cannot use std::formattable<range_value_t<Container>, char>
 * due to circular dependency issues with recursive formatters.
 * The constraint is enforced implicitly at instantiation time.
 */
template <typename Container>
concept range_like = std::ranges::range<Container>;

/**
 * @brief Concept for pair types
 * @tparam T Type to verify (must be std::pair)
 *
 * @note Similar limitation as range_like - we check structure
 * but not formattability to avoid circular dependencies.
 */
template <typename T>
concept formattable_pair = requires(T t) {
  typename T::first_type;
  typename T::second_type;
};

/**
 * @brief Concept for tuple types
 * @tparam Tuple Tuple type to verify
 *
 * Validates that the type has tuple-like structure.
 *
 * @note Element formattability is checked implicitly at format time.
 */
template <typename Tuple>
concept formattable_tuple = requires { std::tuple_size<Tuple>::value; };

// ============================================================================
// THREAD-LOCAL STATE
// ============================================================================

/// Current indentation level (thread-safe via thread_local)
inline thread_local int current_indent = 0;

/// Whether pretty mode is currently active
inline thread_local bool pretty_mode = false;

/// String used for each indentation level (default: two spaces)
inline thread_local std::string indent_string = "  ";

} // namespace impl

// ============================================================================
// PUBLIC API
// ============================================================================

/**
 * @brief Sets the string used for one level of indentation
 * @param new_indent The string to use for indentation (e.g., "    ", "\t")
 * @note This setting is thread-local and persists across format calls.
 *
 * @code
 * pretty_format::set_indent_string("\t");  // Use tabs
 * std::format("{:pretty}", vec);
 * @endcode
 */
inline void set_indent_string(std::string_view new_indent) {
  impl::indent_string = new_indent;
}

/**
 * @brief Resets indentation to default (two spaces)
 * @note Useful in test suites or after temporary configuration changes.
 *
 * @code
 * pretty_format::set_indent_string("\t\t");
 * // ... use custom indent ...
 * pretty_format::reset_indent_string();  // Back to "  "
 * @endcode
 */
inline std::string_view get_indent_string() { return impl::indent_string; }

/**
 * @brief Resets indentation to default (two spaces)
 * @note Useful in test suites or after temporary configuration changes.
 */
inline void reset_indent_string() { impl::indent_string = "  "; }

namespace impl {

// ============================================================================
// RAII GUARDS
// ============================================================================

/**
 * @brief RAII guard to manage indentation in nested blocks
 *
 * Automatically increments the indentation level at construction
 * and decrements it at destruction. Ensures correct indentation
 * even in case of exceptions.
 *
 * @note Uses RAII pattern for exception safety
 *
 * @code
 * {
 * indent_guard guard;  // Increment indentation
 * // ... indented code ...
 * }  // Automatically decrement
 * @endcode
 */
struct indent_guard {
  /// Constructor: increments indentation
  indent_guard() { current_indent++; }

  /// Destructor: decrements indentation
  ~indent_guard() { current_indent--; }
};

/**
 * @brief RAII guard to temporarily enable/disable pretty mode
 *
 * Saves the current pretty mode state, sets a new state,
 * and restores the original state at destruction.
 *
 * @warning Not copyable nor movable to guarantee correct scoping
 */
struct pretty_mode_guard {
  bool old_pretty_mode; ///< Saved state to restore

  /**
   * @brief Constructor that sets a new pretty mode state
   * @param new_mode true to enable pretty mode, false to disable
   */
  pretty_mode_guard(bool new_mode) : old_pretty_mode(pretty_mode) {
    pretty_mode = new_mode;
  }

  /// Destructor: restores previous state
  ~pretty_mode_guard() { pretty_mode = old_pretty_mode; }

  // Deleted copy/move for safety
  pretty_mode_guard(const pretty_mode_guard &) = delete;
  pretty_mode_guard &operator=(const pretty_mode_guard &) = delete;
  pretty_mode_guard(pretty_mode_guard &&) = delete;
  pretty_mode_guard &operator=(pretty_mode_guard &&) = delete;
};

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

/**
 * @brief Returns the indentation string for the current level
 *
 * Constructs a string by repeating indent_string for current_indent times.
 * Used internally to format output in pretty mode.
 *
 * @return String containing the appropriate indentation
 *
 * @note Thread-safe due to current_indent being thread_local
 * @note Optimized with reserve() to avoid multiple reallocations
 */
inline std::string get_indent() {
  if (current_indent <= 0) {
    return {}; // No allocation for indent 0
  }

  std::string result;
  result.reserve(current_indent * indent_string.size());

  for (int i = 0; i < current_indent; ++i) {
    result += indent_string;
  }
  return result;
}

/**
 * @brief Normalizes a separator by removing outer whitespace
 *
 * Removes spaces and tabs at the beginning and end of the separator.
 * If the input is empty, returns ", " as default.
 * If the input contains only whitespace, preserves it (user's intention).
 *
 * @param sep Separator to normalize
 * @return Normalized separator (or ", " if empty)
 *
 * @note constexpr for compile-time evaluation when possible
 *
 * @code
 * trim_separator("  ,  ")    // Returns ","
 * trim_separator("   ")      // Returns "   " (preserves whitespace)
 * trim_separator(" | ")      // Returns "|"
 * trim_separator("")         // Returns ", " (default)
 * trim_separator(" ")        // Returns " " (single space preserved)
 * @endcode
 */
constexpr std::string_view trim_separator(std::string_view sep) {
  if (sep.empty()) {
    return ", ";
  }

  // Find first non-whitespace character
  size_t first = 0;
  while (first < sep.size() && (sep[first] == ' ' || sep[first] == '\t')) {
    ++first;
  }

  // Find last non-whitespace character
  size_t last = sep.size() - 1;
  while (last > first && (sep[last] == ' ' || sep[last] == '\t')) {
    --last;
  }

  // All whitespace: preserve original (user's intention)
  if (first > last) {
    return sep;
  }

  return sep.substr(first, last - first + 1);
}

/**
 * @brief Converts a normal separator to one suitable for pretty mode
 *
 * Adds a newline at the end of the separator if not present.
 * Used to separate elements on different lines in pretty mode.
 *
 * @param sep Base separator
 * @return Separator with guaranteed trailing newline
 */
inline std::string ensure_trailing_newline(std::string_view sep) {
  std::string result(sep);
  if (result.empty() || result.back() != '\n') {
    result += '\n';
  }
  return result;
}

/**
 * @brief Parses format specification to extract separator and pretty mode
 *
 * Analyzes the format string to identify:
 * - Custom separator (part before ':')
 * - "pretty" option (after ':')
 *
 * @param ctx Parsing context from std::format
 * @return Tuple containing: (separator, pretty_flag, end_iterator)
 *
 * @par Supported formats
 * - `{}`            separator ", ", pretty=false
 * - `{:pretty}`     separator ", ", pretty=true
 * - `{:;}`          separator ";", pretty=false
 * - `{: | :pretty}` separator " | ", pretty=true
 * - `{::pretty}`    separator ", ", pretty=true (empty before colon)
 *
 * @par Invalid formats (fallback to default)
 * - `{:a:b:c}`      Multiple colons not allowed
 *
 * @note constexpr for compile-time evaluation
 */
constexpr auto parse_format_spec(std::format_parse_context &ctx)
    -> std::tuple<std::string_view, bool, std::format_parse_context::iterator> {
  auto it = ctx.begin();
  auto end = ctx.end();

  // Case 1: Empty format {}
  if (it == end || *it == '}') {
    return {", ", false, it};
  }

  // Extract full specification
  auto spec_start = it;
  while (it != end && *it != '}') {
    ++it;
  }

  std::string_view full_spec(spec_start, it - spec_start);

  // Validate: count colons
  size_t colon_count = 0;
  for (char c : full_spec) {
    if (c == ':')
      ++colon_count;
  }

  // More than one colon is invalid (e.g., {:a:b:c})
  if (colon_count > 1) {
    // Cannot throw in constexpr, return default
    // std::format will handle if needed
    return {", ", false, it};
  }

  // Find first (and only) colon position
  size_t colon_pos = full_spec.find(':');

  // Case 2: No colon, could be "pretty" or custom separator
  if (colon_pos == std::string_view::npos) {
    if (full_spec == "pretty") {
      return {", ", true, it};
    }
    // Entire text is the separator
    return {trim_separator(full_spec), false, it};
  }

  // Case 3: Have colon, format is [separator]:[options]

  // Extract separator (part before ':')
  std::string_view separator = ", "; // default
  if (colon_pos > 0) {
    separator = trim_separator(full_spec.substr(0, colon_pos));
  }
  // If colon_pos == 0, format like {:pretty}, separator remains default

  // Extract options (part after ':')
  std::string_view options = full_spec.substr(colon_pos + 1);

  // Validate options
  bool pretty = false;
  if (!options.empty()) {
    if (options == "pretty") {
      pretty = true;
    }
    // Unknown options are silently ignored (could add warning/logging)
  }

  return {separator, pretty, it};
}

// ============================================================================
// BASE FORMATTERS
// ============================================================================

/**
 * @brief Base formatter for all containers
 *
 * Provides common format string parsing and parameter storage
 * (separator and pretty mode).
 * Derived classes only need to implement the format() method.
 *
 * @par Format parameters
 * - Separator: any string before ':'
 * - Pretty option: keyword "pretty" after ':'
 *
 * @see parse_format_spec for parsing details
 */
struct basic_formatter {
  std::string_view separator = ", "; ///< Separator between elements
  bool pretty = false;               ///< Flag for pretty-print mode

  /**
   * @brief Parses the format string and sets parameters
   * @param ctx Parsing context provided by std::format
   * @return Iterator to the end of the specification
   */
  constexpr auto parse(std::format_parse_context &ctx) {
    auto result = parse_format_spec(ctx);
    separator = std::get<0>(result);
    pretty = std::get<1>(result);
    return std::get<2>(result);
  }
};

// ============================================================================
// FORMATTING FUNCTIONS
// ============================================================================

/**
 * @brief Formats a range-like container with customizable brackets
 *
 * @tparam Container Container type (must satisfy range_like concept)
 * @tparam OutputIt Output iterator type
 * @param out Output iterator where to write
 * @param container Container to format
 * @param open_bracket Opening character (e.g., '[')
 * @param close_bracket Closing character (e.g., ']')
 * @param separator Separator between elements
 * @param pretty true for pretty-print mode with indentation
 * @return Iterator after the last written character
 *
 * @par Example
 * @code
 * format_range(out, vec, '[', ']', ", ", false)
 * // Produces: [1, 2, 3]
 * @endcode
 */
template <range_like Container, typename OutputIt>
OutputIt format_range(OutputIt out, const Container &container,
                      char open_bracket, char close_bracket,
                      std::string_view separator, bool pretty) {
  *out++ = open_bracket;
  if (pretty && !std::ranges::empty(container)) {
    pretty_mode_guard pretty_guard(true);
    std::string pretty_sep = ensure_trailing_newline(separator);
    std::string parent_indent = get_indent();
    {
      indent_guard guard;
      *out++ = '\n';
      bool first = true;
      for (const auto &elem : container) {
        if (!first) {
          out = std::format_to(out, "{}", pretty_sep);
        }
        out = std::format_to(out, "{}", get_indent());
        out = std::format_to(out, "{}", elem);
        first = false;
      }
    }
    *out++ = '\n';
    out = std::format_to(out, "{}", parent_indent);
  } else {
    bool first = true;
    for (const auto &elem : container) {
      if (!first)
        out = std::format_to(out, "{}", separator);
      out = std::format_to(out, "{}", elem);
      first = false;
    }
  }
  *out++ = close_bracket;
  return out;
}

/**
 * @brief Formats tuple elements with indices
 *
 * @tparam Tuple Tuple type (must satisfy formattable_tuple concept)
 * @tparam OutputIt Output iterator type
 * @tparam Is Index sequence for tuple elements
 * @param out Output iterator
 * @param tuple Tuple to format
 * @param separator Separator between elements
 * @param pretty Pretty mode flag
 * @param Index sequence (automatically deduced)
 * @return Iterator after writing
 */
template <formattable_tuple Tuple, typename OutputIt, size_t... Is>
OutputIt format_tuple_elements(OutputIt out, const Tuple &tuple,
                               std::string_view separator, bool pretty,
                               std::index_sequence<Is...>) {
  if constexpr (sizeof...(Is) > 0) {
    if (pretty) {
      pretty_mode_guard pretty_guard(true);
      std::string pretty_sep = ensure_trailing_newline(separator);
      {
        indent_guard guard;
        bool first = true;
        (([&] {
           if (!first) {
             out = std::format_to(out, "{}", pretty_sep);
           }
           out = std::format_to(out, "{}", get_indent());
           out = std::format_to(out, "{}", std::get<Is>(tuple));
           first = false;
         }()),
         ...);
      }
    } else {
      bool first = true;
      ((first ? (first = false,
                 out = std::format_to(out, "{}", std::get<Is>(tuple)))
              : (out = std::format_to(out, "{}{}", separator,
                                      std::get<Is>(tuple)))),
       ...);
    }
  }
  return out;
}

/**
 * @brief Formats a tuple
 *
 * @tparam Tuple Tuple type (must satisfy formattable_tuple concept)
 * @tparam OutputIt Output iterator type
 * @param out Output iterator
 * @param tuple Tuple to format
 * @param separator Separator between elements
 * @param pretty Pretty mode flag
 * @return Iterator after writing
 */
template <formattable_tuple Tuple, typename OutputIt>
OutputIt format_tuple(OutputIt out, const Tuple &tuple,
                      std::string_view separator, bool pretty) {
  *out++ = '(';
  if (pretty && std::tuple_size_v<Tuple> > 0) {
    *out++ = '\n';
    out = format_tuple_elements(
        out, tuple, separator, pretty,
        std::make_index_sequence<std::tuple_size_v<Tuple>>{});
    *out++ = '\n';
    out = std::format_to(out, "{}", get_indent());
  } else {
    out = format_tuple_elements(
        out, tuple, separator, pretty,
        std::make_index_sequence<std::tuple_size_v<Tuple>>{});
  }
  *out++ = ')';
  return out;
}

/**
 * @brief Unified base formatter for containers with brackets
 *
 * Extends basic_formatter by using template parameters to specify
 * opening/closing characters (e.g., '[', ']' or '{', '}').
 * This avoids code duplication between range and set formatters.
 *
 * @tparam OpenChar The opening character for the container
 * @tparam CloseChar The closing character for the container
 */
template <char OpenChar, char CloseChar>
struct basic_bracketed_formatter : basic_formatter {
  /**
   * @brief Formats the container using the specified brackets
   * @param container Container to format
   * @param ctx Format context from std::format
   * @return Iterator to output after writing
   */
  auto format(const auto &container, std::format_context &ctx) const {
    return format_range(ctx.out(), container, OpenChar, CloseChar, separator,
                        pretty);
  }
};

} // namespace impl
} // namespace pretty_format

// ============================================================================
// STD::FORMATTER SPECIALIZATIONS
// ============================================================================

/**
 * @brief Formatter specialization for std::pair
 *
 * Formats a pair as {first: second} with customizable separator.
 *
 * @tparam T1 Type of first element
 * @tparam T2 Type of second element
 *
 * @par Default format
 * `{key: value}`
 *
 * @par Examples
 * @code
 * std::pair<int, std::string> p{42, "hello"};
 *
 * std::format("{}", p);           // {42: hello}
 * std::format("{: => }", p);      // {42 => hello}
 * std::format("{:pretty}", p);    // {
 * //   42:
 * //   hello
 * // }
 * @endcode
 *
 * @note Cannot use requires clause due to circular dependency with
 * std::formattable. Constraints are enforced at instantiation.
 */
template <typename T1, typename T2>
struct std::formatter<std::pair<T1, T2>>
    : pretty_format::impl::basic_formatter {

  /**
   * @brief Constructor that sets the default separator for pairs
   * @note constexpr required by std::format for compile-time validation
   */
  constexpr formatter() noexcept : basic_formatter() { separator = ": "; }

  /**
   * @brief Formats the pair
   * @param p Pair to format
   * @param ctx Format context
   * @return Iterator to output
   */
  auto format(const std::pair<T1, T2> &p, format_context &ctx) const {
    auto out = ctx.out();
    *out++ = '{';
    if (pretty) {
      pretty_format::impl::pretty_mode_guard pretty_guard(true);
      std::string pretty_sep =
          pretty_format::impl::ensure_trailing_newline(separator);
      std::string parent_indent = pretty_format::impl::get_indent();
      {
        pretty_format::impl::indent_guard guard;
        *out++ = '\n';
        out = std::format_to(out, "{}", pretty_format::impl::get_indent());
        out = std::format_to(out, "{}", p.first);
        out = std::format_to(out, "{}", pretty_sep);
        out = std::format_to(out, "{}", pretty_format::impl::get_indent());
        out = std::format_to(out, "{}", p.second);
      }
      *out++ = '\n';
      out = std::format_to(out, "{}", parent_indent);
    } else {
      out = std::format_to(out, "{}{}{}", p.first, separator, p.second);
    }
    *out++ = '}';
    return out;
  }
};

/**
 * @brief Formatter for std::tuple
 *
 * @tparam Ts Types of tuple elements
 *
 * @par Examples
 * @code
 * std::tuple<int, std::string, double> t{42, "hello", 3.14};
 *
 * std::format("{}", t);           // (42, hello, 3.14)
 * std::format("{: -- }", t);      // (42 -- hello -- 3.14)
 * std::format("{:pretty}", t);    // (
 * //   42,
 * //   hello,
 * //   3.14
 * // )
 * @endcode
 *
 * @note Cannot use requires clause due to circular dependency with
 * std::formattable. Constraints are enforced at instantiation.
 */
template <typename... Ts>
struct std::formatter<std::tuple<Ts...>>
    : pretty_format::impl::basic_formatter {
  /**
   * @brief Formats the tuple
   * @param t Tuple to format
   * @param ctx Format context
   * @return Iterator to output
   */
  auto format(const std::tuple<Ts...> &t, format_context &ctx) const {
    return pretty_format::impl::format_tuple(ctx.out(), t, separator, pretty);
  }
};

// ============================================================================
// SEQUENCE CONTAINERS
// ============================================================================

/**
 * @brief Formatter for std::vector
 *
 * @tparam T Element type
 * @tparam Alloc Allocator type
 *
 * @par Examples
 * @code
 * std::vector<int> v = {1, 2, 3};
 *
 * std::format("{}", v);           // [1, 2, 3]
 * std::format("{:;}", v);         // [1;2;3]
 * std::format("{: | }", v);       // [1 | 2 | 3]
 * std::format("{:pretty}", v);    // [
 * //   1,
 * //   2,
 * //   3
 * // ]
 * @endcode
 *
 * @note Element type T must have a valid std::formatter specialization.
 * Cannot enforce with requires clause due to circular dependencies.
 */
template <typename T, typename Alloc>
struct std::formatter<std::vector<T, Alloc>>
    : pretty_format::impl::basic_bracketed_formatter<'[', ']'> {};

/**
 * @brief Formatter for std::deque
 *
 * @tparam T Element type
 * @tparam Alloc Allocator type
 *
 * @note Element type T must have a valid std::formatter specialization.
 */
template <typename T, typename Alloc>
struct std::formatter<std::deque<T, Alloc>>
    : pretty_format::impl::basic_bracketed_formatter<'[', ']'> {};

/**
 * @brief Formatter for std::list
 *
 * @tparam T Element type
 * @tparam Alloc Allocator type
 *
 * @note Element type T must have a valid std::formatter specialization.
 */
template <typename T, typename Alloc>
struct std::formatter<std::list<T, Alloc>>
    : pretty_format::impl::basic_bracketed_formatter<'[', ']'> {};

/**
 * @brief Formatter for std::array
 *
 * @tparam T Element type
 * @tparam N Array size
 *
 * @note Element type T must have a valid std::formatter specialization.
 */
template <typename T, std::size_t N>
struct std::formatter<std::array<T, N>>
    : pretty_format::impl::basic_bracketed_formatter<'[', ']'> {};

/**
 * @brief Formatter for std::span
 *
 * @tparam T Element type
 * @tparam Extent Span extent
 *
 * @note Useful for formatting C-style arrays via std::span
 * @note Element type T must have a valid std::formatter specialization.
 */
template <typename T, std::size_t Extent>
struct std::formatter<std::span<T, Extent>>
    : pretty_format::impl::basic_bracketed_formatter<'[', ']'> {};

// ============================================================================
// ASSOCIATIVE CONTAINERS
// ============================================================================

/**
 * @brief Formatter for std::set
 *
 * @tparam Key Element type
 * @tparam Compare Comparison function
 * @tparam Alloc Allocator type
 *
 * @par Example
 * @code
 * std::set<int> s = {1, 2, 3};
 * std::format("{}", s);  // {1, 2, 3}
 * @endcode
 *
 * @note Key type must have a valid std::formatter specialization.
 */
template <typename Key, typename Compare, typename Alloc>
struct std::formatter<std::set<Key, Compare, Alloc>>
    : pretty_format::impl::basic_bracketed_formatter<'{', '}'> {};

/**
 * @brief Formatter for std::multiset
 *
 * @tparam Key Element type
 * @tparam Compare Comparison function
 * @tparam Alloc Allocator type
 *
 * @note Key type must have a valid std::formatter specialization.
 */
template <typename Key, typename Compare, typename Alloc>
struct std::formatter<std::multiset<Key, Compare, Alloc>>
    : pretty_format::impl::basic_bracketed_formatter<'{', '}'> {};

/**
 * @brief Formatter for std::unordered_set
 *
 * @tparam Key Element type
 * @tparam Hash Hash function
 * @tparam KeyEqual Equality comparison
 * @tparam Alloc Allocator type
 *
 * @note Key type must have a valid std::formatter specialization.
 */
template <typename Key, typename Hash, typename KeyEqual, typename Alloc>
struct std::formatter<std::unordered_set<Key, Hash, KeyEqual, Alloc>>
    : pretty_format::impl::basic_bracketed_formatter<'{', '}'> {};

/**
 * @brief Formatter for std::unordered_multiset
 *
 * @tparam Key Element type
 * @tparam Hash Hash function
 * @tparam KeyEqual Equality comparison
 * @tparam Alloc Allocator type
 *
 * @note Key type must have a valid std::formatter specialization.
 */
template <typename Key, typename Hash, typename KeyEqual, typename Alloc>
struct std::formatter<std::unordered_multiset<Key, Hash, KeyEqual, Alloc>>
    : pretty_format::impl::basic_bracketed_formatter<'{', '}'> {};

/**
 * @brief Formatter for std::map
 *
 * Formats the map as a set of pairs {key: value}.
 *
 * @tparam Key Key type
 * @tparam T Value type
 * @tparam Compare Comparison function
 * @tparam Alloc Allocator type
 *
 * @par Examples
 * @code
 * std::map<int, std::string> m = {{1, "one"}, {2, "two"}};
 *
 * std::format("{}", m);        // {{1: one}, {2: two}}
 * std::format("{:pretty}", m); // {
 * //   {1: one},
 * //   {2: two}
 * // }
 * @endcode
 *
 * @note Key and T types must have valid std::formatter specializations.
 */
template <typename Key, typename T, typename Compare, typename Alloc>
struct std::formatter<std::map<Key, T, Compare, Alloc>>
    : pretty_format::impl::basic_bracketed_formatter<'{', '}'> {};

/**
 * @brief Formatter for std::multimap
 *
 * @tparam Key Key type
 * @tparam T Value type
 * @tparam Compare Comparison function
 * @tparam Alloc Allocator type
 *
 * @note Key and T types must have valid std::formatter specializations.
 */
template <typename Key, typename T, typename Compare, typename Alloc>
struct std::formatter<std::multimap<Key, T, Compare, Alloc>>
    : pretty_format::impl::basic_bracketed_formatter<'{', '}'> {};

/**
 * @brief Formatter for std::unordered_map
 *
 * @tparam Key Key type
 * @tparam T Value type
 * @tparam Hash Hash function
 * @tparam KeyEqual Equality comparison
 * @tparam Alloc Allocator type
 *
 * @note Key and T types must have valid std::formatter specializations.
 */
template <typename Key, typename T, typename Hash, typename KeyEqual,
          typename Alloc>
struct std::formatter<std::unordered_map<Key, T, Hash, KeyEqual, Alloc>>
    : pretty_format::impl::basic_bracketed_formatter<'{', '}'> {};

/**
 * @brief Formatter for std::unordered_multimap
 *
 * @tparam Key Key type
 * @tparam T Value type
 * @tparam Hash Hash function
 * @tparam KeyEqual Equality comparison
 * @tparam Alloc Allocator type
 *
 * @note Key and T types must have valid std::formatter specializations.
 */
template <typename Key, typename T, typename Hash, typename KeyEqual,
          typename Alloc>
struct std::formatter<std::unordered_multimap<Key, T, Hash, KeyEqual, Alloc>>
    : pretty_format::impl::basic_bracketed_formatter<'{', '}'> {};

// ============================================================================
// CONTAINER ADAPTERS
// ============================================================================

/**
 * @brief Formatter for std::stack
 *
 * @warning This formatter copies the stack to iterate through it.
 * For very large stacks, consider using std::vector directly
 * to avoid the copy overhead.
 *
 * @tparam T Element type
 * @tparam Container Underlying container (default: std::deque<T>)
 *
 * @par Behavior
 * The stack is copied and emptied to extract elements from top to bottom.
 * The order shown is that of successive pop operations.
 *
 * @code
 * std::stack<int> s;
 * s.push(1);
 * s.push(2);
 * s.push(3);
 * std::format("{}", s);  // [3, 2, 1] (top â†’ bottom)
 * @endcode
 *
 * @note Element type T must have a valid std::formatter specialization.
 */
template <typename T, typename Container>
struct std::formatter<std::stack<T, Container>>
    : pretty_format::impl::basic_formatter {

  constexpr auto parse(std::format_parse_context &ctx) {
    return basic_formatter::parse(ctx);
  }

  /**
   * @brief Formats the stack
   * @param s Stack to format
   * @param ctx Format context
   * @return Iterator to output
   *
   * @note Creates a copy of the stack for iteration
   */
  auto format(const std::stack<T, Container> &s, format_context &ctx) const {
    auto s_copy = s;
    std::vector<T> elements;
    elements.reserve(s_copy.size());
    while (!s_copy.empty()) {
      elements.push_back(s_copy.top());
      s_copy.pop();
    }
    return pretty_format::impl::format_range(ctx.out(), elements, '[', ']',
                                             separator, pretty);
  }
};

/**
 * @brief Formatter for std::queue
 *
 * @warning This formatter copies the queue to iterate through it.
 *
 * @tparam T Element type
 * @tparam Container Underlying container (default: std::deque<T>)
 *
 * @par Behavior
 * The queue is copied and emptied to extract elements from front to back.
 * The order shown is that of successive front/pop operations.
 *
 * @code
 * std::queue<int> q;
 * q.push(1);
 * q.push(2);
 * q.push(3);
 * std::format("{}", q);  // [1, 2, 3] (front â†’ back)
 * @endcode
 *
 * @note Element type T must have a valid std::formatter specialization.
 */
template <typename T, typename Container>
struct std::formatter<std::queue<T, Container>>
    : pretty_format::impl::basic_formatter {

  constexpr auto parse(std::format_parse_context &ctx) {
    return basic_formatter::parse(ctx);
  }

  /**
   * @brief Formats the queue
   * @param q Queue to format
   * @param ctx Format context
   * @return Iterator to output
   *
   * @note Creates a copy of the queue for iteration
   */
  auto format(const std::queue<T, Container> &q, format_context &ctx) const {
    auto q_copy = q;
    std::vector<T> elements;
    elements.reserve(q_copy.size());
    while (!q_copy.empty()) {
      elements.push_back(q_copy.front());
      q_copy.pop();
    }
    return pretty_format::impl::format_range(ctx.out(), elements, '[', ']',
                                             separator, pretty);
  }
};

/**
 * @brief Formatter for std::priority_queue
 *
 * @warning This formatter copies the priority queue to iterate through it.
 *
 * @tparam T Element type
 * @tparam Container Underlying container (default: std::vector<T>)
 * @tparam Compare Comparison function (default: std::less<T>)
 *
 * @par Behavior
 * The priority queue is copied and emptied to extract elements in priority
 * order. The order shown is that of successive top/pop operations (highest
 * priority first).
 *
 * @code
 * std::priority_queue<int> pq;
 * pq.push(30);
 * pq.push(100);
 * pq.push(20);
 * std::format("{}", pq);  // [100, 30, 20] (priority order)
 * @endcode
 *
 * @note Element type T must have a valid std::formatter specialization.
 */
template <typename T, typename Container, typename Compare>
struct std::formatter<std::priority_queue<T, Container, Compare>>
    : pretty_format::impl::basic_formatter {

  constexpr auto parse(std::format_parse_context &ctx) {
    return basic_formatter::parse(ctx);
  }

  /**
   * @brief Formats the priority queue
   * @param pq Priority queue to format
   * @param ctx Format context
   * @return Iterator to output
   *
   * @note Creates a copy of the priority queue for iteration
   */
  auto format(const std::priority_queue<T, Container, Compare> &pq,
              format_context &ctx) const {
    auto pq_copy = pq;
    std::vector<T> elements;
    elements.reserve(pq_copy.size());
    while (!pq_copy.empty()) {
      elements.push_back(pq_copy.top());
      pq_copy.pop();
    }
    return pretty_format::impl::format_range(ctx.out(), elements, '[', ']',
                                             separator, pretty);
  }
};
#endif // PRETTY_FORMAT_HXX