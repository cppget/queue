#include <pretty_format/pretty_format.hxx>
#include <vector>
#include <map>
#include <string>
#include <cassert>

// Test base: verifica che la libreria compili e sia usabile
int main()
{
  // Test vector
  std::vector<int> vec = {1, 2, 3};
  
  // Test map
  std::map<std::string, int> map = {{"a", 1}, {"b", 2}};
  
  // Se la libreria compila e gli header sono inclusi correttamente, il test passa
  return 0;
}
