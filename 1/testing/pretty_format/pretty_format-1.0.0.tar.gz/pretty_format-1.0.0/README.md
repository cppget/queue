# pretty_format

A modern C++23 header-only library that extends `std::format` to automatically format all STL containers with customizable separators and pretty-printing support.

## Features

- **Zero configuration** - Just include and use with `std::format()`
- **All STL containers** - vector, map, set, list, deque, array, span, and more
- **Pretty-print mode** - Automatic indentation for nested structures
- **Customizable** - Custom separators and indentation strings
- **Container adapters** - Support for stack, queue, priority_queue
- **Thread-safe** - Uses thread-local storage for configuration
- **Header-only** - No linking required
- **Educational** - Clean code demonstrating modern C++ techniques

## Quick Start
```cpp
#include "pretty_format.hxx"
#include <format>
#include <iostream>
#include <vector>
#include <map>

int main() {
    // Basic usage
    std::vector<int> v = {1, 2, 3, 4, 5};
    std::cout << std::format("{}", v);  // [1, 2, 3, 4, 5]
    
    // Custom separator
    std::cout << std::format("{:;}", v);  // [1;2;3;4;5]
    
    // Pretty-print mode
    std::cout << std::format("{:pretty}", v);
    // [
    //   1,
    //   2,
    //   3,
    //   4,
    //   5
    // ]
    
    // Works with nested containers
    std::map<int, std::vector<std::string>> data = {
        {1, {"hello", "world"}},
        {2, {"foo", "bar"}}
    };
    std::cout << std::format("{:pretty}", data);
    
    return 0;
}
```

## Format Specification

The format syntax is: `{:[separator][:pretty]}`

|Format|Description|Example Output|
|---|---|---|
|{}|Default separator ", "| [1, 2, 3]|
|{:;}|Custom separator ";"|[1;2;3]|
|{: \| }|Custom separator " \| "|[1 \| 2 \| 3]|
|{:pretty}|Pretty-print with default separator|Multi-line with indentation|
|{:;:pretty}|Pretty-print with custom separator|Multi-line with ";" separator|

## Supported Containers

### Sequence Containers

- std::vector
- std::deque
- std::list
- std::array
- std::span

### Associative Containers

- std::set / std::multiset
- std::map / std::multimap
- std::unordered_set / std::unordered_multiset
- std::unordered_map / std::unordered_multimap

### Container Adapters

- std::stack
- std::queue
- std::priority_queue

### Other

- std::pair
- std::tuple

## Configuration API

Customize indentation globally (thread-local)

```cpp

// Set custom indentation (e.g., 4 spaces or tabs)
pretty_format::set_indent_string("    ");  // 4 spaces
pretty_format::set_indent_string("\t");    // tabs

// Get current indentation
auto indent = pretty_format::get_indent_string();

// Reset to default (2 spaces)
pretty_format::reset_indent_string();
```


## Requirements

### Compiler Support

This library requires a C++23 compliant compiler with full support for:

- std::format and std::formatter
- std::ranges
- std::print / std::println

Minimum compiler versions:
|Compiler|Minimum Version|Notes|
|---|---|---|
|GCC|13.1|Full C++23 std::format support|
|Clang|17.0|Requires libc++ 17+ or libstdc++ 13+|
|MSVC|19.37 (VS 2022 17.7)|Full std::format support|

### Build Flags

```bash
# GCC/Clang
g++ -std=c++23 your_code.cpp -o your_program

# MSVC
cl /std:c++latest your_code.cpp
```


## Platform Support

- Linux (GCC 13+, Clang 17+)
- macOS (Clang 17+ with Xcode 15+)
- Windows (MSVC 19.37+, Visual Studio 2022 17.7+)

## Installation
This is a header-only library. Simply copy pretty_format.hxx to your project 
and include it:

```cpp
#include "pretty_format.hxx"
```

Or use it as a git submodule:
```bash
git submodule add https://gitlab.com/weltluft/pretty_format.git libs/pretty_format
```

## Important Notes

### Thread-Local State

The indentation configuration is thread-local and persists across std::format()
calls within the same thread:
```cpp
pretty_format::set_indent_string("\t");
auto s1 = std::format("{:pretty}", vec1);  // Uses tabs
auto s2 = std::format("{:pretty}", vec2);  // Still uses tabs
pretty_format::reset_indent_string();      // Back to default
```

### Container Adapters Performance

std::stack, std::queue, and std::priority_queue are copied during formatting to
access their elements. For very large containers (>10,000 elements), 
consider using std::vector directly to avoid the O(n) copy overhead.

### Element Formattability

All container element types must have a valid std::formatter specialization. 
For custom types, provide your own formatter:

```cpp
struct MyType {
    int value;
};

template <>
struct std::formatter<MyType> : std::formatter<int> {
    auto format(const MyType& obj, std::format_context& ctx) const {
        return std::formatter<int>::format(obj.value, ctx);
    }
};
```

## Examples

See the test suite in main.cxx for comprehensive examples covering:

- Nested containers (up to 4 levels deep)
- Custom separators (including whitespace-only)
- Pretty-print formatting
- All STL container types
- Edge cases (empty containers, single elements)
- Configuration API usage


## License

This project is licensed under the MIT License - see the LICENSE file for 
details.

## Contributing

Contributions are welcome! Please feel free to submit issues or pull requests.

## Author

Daskalte Weltluft - daskalte@pm.me
