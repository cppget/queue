// ============================================================================
// MAIN - TEST SUITE
// ============================================================================

/**
 * @brief Main function with comprehensive test suite
 *
 * Tests all formatters with various format specifications including:
 * - Basic formatting
 * - Custom separators
 * - Pretty mode
 * - Custom indentation
 * - Nested containers
 * - Edge cases (empty containers, single elements)
 * - All STL container types
 * - Container adapters
 * - Configuration API
 *
 * @return 0 on success
 */

#include <pretty_format/pretty_format.hxx>

int main() {
  using namespace pretty_format;

  std::cout << "=== Basic Tests ===\n";

  std::vector<int> vec = {1, 2, 3, 4, 5};
  std::cout << std::format("Default: {}\n", vec);
  std::cout << std::format("Custom sep: {: | }\n", vec);
  std::cout << "Pretty:\n" << std::format("{:pretty}\n", vec);

  std::cout << "\n=== Pair Tests ===\n";

  std::pair<std::string, int> p = {"key", 100};
  std::cout << "Default: " << std::format("{}\n", p);
  std::cout << "Custom sep: " << std::format("{: => }\n", p);
  std::cout << "Pretty:\n" << std::format("{:pretty}\n", p);
  std::cout << "Pretty with custom sep:\n"
            << std::format("{: => :pretty}\n", p);

  std::cout << "\n=== Tuple Tests ===\n";

  std::tuple<int, std::string, double> tpl = {42, "hello", 3.14};
  std::cout << "Default: " << std::format("{}\n", tpl);
  std::cout << "Custom separator: " << std::format("{: -- }\n", tpl);
  std::cout << "Pretty:\n" << std::format("{:pretty}\n", tpl);
  std::cout << "Pretty with custom sep:\n"
            << std::format("{: -- :pretty}\n", tpl);

  std::tuple<> empty_tuple;
  std::cout << "Empty tuple: " << std::format("{}\n", empty_tuple);

  std::tuple<int> single_tuple = {42};
  std::cout << "Single element tuple: " << std::format("{}\n", single_tuple);

  std::cout << "\n=== Separator Tests ===\n";

  std::vector<int> sep_test = {10, 20, 30, 40, 50};

  std::cout << "Default separator: " << std::format("{}\n", sep_test);
  std::cout << "Semicolon: " << std::format("{:;}\n", sep_test);
  std::cout << "Pipe: " << std::format("{: | }\n", sep_test);
  std::cout << "Arrow: " << std::format("{: -> }\n", sep_test);
  std::cout << "Tab: " << std::format("{:\t}\n", sep_test);

  std::cout << "\n=== Whitespace Separator Tests ===\n";

  std::vector<int> ws_test = {1, 2, 3};

  std::cout << "Single space: '" << std::format("{: }", ws_test) << "'\n";
  // Expected: '[1 2 3]'

  std::cout << "Three spaces: '" << std::format("{:   }", ws_test) << "'\n";
  // Expected: '[1   2   3]'

  std::cout << "Five spaces: '" << std::format("{:     }", ws_test) << "'\n";
  // Expected: '[1     2     3]'

  std::cout << "Tab: '" << std::format("{:\t}", ws_test) << "'\n";
  // Expected: '[1	2	3]'

  std::cout << "Empty (uses default): '" << std::format("{:}", ws_test)
            << "'\n";
  // Expected: '[1, 2, 3]'

  std::cout << "\n=== Pretty Mode with Custom Separators ===\n";

  std::vector<int> pretty_sep_test = {10, 20, 30};

  std::cout << "Pretty with default separator:\n"
            << std::format("{:pretty}\n", pretty_sep_test);

  std::cout << "Pretty with semicolon:\n"
            << std::format("{:;:pretty}\n", pretty_sep_test);

  std::cout << "Pretty with pipe:\n"
            << std::format("{: | :pretty}\n", pretty_sep_test);

  std::cout << "Pretty with arrow:\n"
            << std::format("{: -> :pretty}\n", pretty_sep_test);

  std::cout << "\n=== Indentation Configuration API ===\n";

  std::cout << "Current indent: '" << get_indent_string() << "'\n";

  set_indent_string("    ");
  std::cout << "After set to 4 spaces: '" << get_indent_string() << "'\n";

  std::vector<std::vector<int>> indent_test = {{1, 2}, {3, 4}};
  std::cout << "Nested with 4 spaces:\n"
            << std::format("{:pretty}", indent_test) << "\n";

  set_indent_string("\t");
  std::cout << "After set to tabs: '" << get_indent_string() << "'\n";
  std::cout << "Nested with tabs:\n"
            << std::format("{:pretty}", indent_test) << "\n";

  reset_indent_string();
  std::cout << "After reset: '" << get_indent_string() << "'\n";
  std::cout << "Nested with default (2 spaces):\n"
            << std::format("{:pretty}", indent_test) << "\n";

  std::cout << "\n=== Nested Containers (2 levels) ===\n";

  std::vector<std::vector<int>> nested2 = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
  std::cout << "Default: " << std::format("{}\n", nested2);
  std::cout << "Pretty:\n" << std::format("{:pretty}\n", nested2);
  std::cout << "Pretty with semicolon:\n"
            << std::format("{:;:pretty}\n", nested2);

  std::cout << "\n=== Nested Containers (3 levels) ===\n";

  std::vector<std::vector<std::vector<int>>> nested3 = {{{1, 2}, {3, 4}},
                                                        {{5, 6}, {7, 8}}};
  std::cout << "Default: " << std::format("{}\n", nested3);
  std::cout << "Pretty:\n" << std::format("{:pretty}\n", nested3);

  std::cout << "\n=== Nested Containers (4 levels) ===\n";

  std::vector<std::vector<std::vector<std::vector<int>>>> nested4 = {
      {{{1, 2}, {3, 4}}, {{5, 6}, {7, 8}}},
      {{{9, 10}, {11, 12}}, {{13, 14}, {15, 16}}}};
  std::cout << "Pretty:\n" << std::format("{:pretty}\n", nested4);

  std::cout << "\n=== Sets ===\n";

  std::set<std::string> s = {"apple", "banana", "cherry"};
  std::cout << "Set default: " << std::format("{}\n", s);
  std::cout << "Set pretty:\n" << std::format("{:pretty}\n", s);
  std::cout << "Set pretty with semicolon:\n"
            << std::format("{:;:pretty}\n", s);

  std::multiset<int> ms = {1, 2, 2, 3, 3, 3};
  std::cout << "\nMultiset: " << std::format("{}\n", ms);
  std::cout << "Multiset pretty:\n" << std::format("{:pretty}\n", ms);

  std::cout << "\n=== Maps ===\n";

  std::map<int, std::string> m = {{1, "one"}, {2, "two"}, {3, "three"}};
  std::cout << "Map default: " << std::format("{}\n", m);
  std::cout << "Map pretty:\n" << std::format("{:pretty}\n", m);
  std::cout << "Map pretty with pipe:\n" << std::format("{: | :pretty}\n", m);

  std::multimap<int, std::string> mm = {{1, "a"}, {1, "b"}, {2, "c"}};
  std::cout << "\nMultimap: " << std::format("{}\n", mm);
  std::cout << "Multimap pretty:\n" << std::format("{:pretty}\n", mm);

  std::cout << "\n=== Unordered Containers ===\n";

  std::unordered_set<int> us = {5, 3, 1, 4, 2};
  std::cout << "Unordered set: " << std::format("{}\n", us);
  std::cout << "Unordered set pretty:\n" << std::format("{:pretty}\n", us);

  std::unordered_multiset<std::string> ums = {"a", "b", "b", "c", "c", "c"};
  std::cout << "\nUnordered multiset: " << std::format("{}\n", ums);
  std::cout << "Unordered multiset pretty:\n"
            << std::format("{:pretty}\n", ums);

  std::unordered_map<std::string, int> um = {
      {"alpha", 1}, {"beta", 2}, {"gamma", 3}};
  std::cout << "\nUnordered map: " << std::format("{}\n", um);
  std::cout << "Unordered map pretty:\n" << std::format("{:pretty}\n", um);

  std::unordered_multimap<int, std::string> umm = {
      {1, "a"}, {1, "b"}, {2, "c"}, {2, "d"}};
  std::cout << "\nUnordered multimap: " << std::format("{}\n", umm);
  std::cout << "Unordered multimap pretty:\n"
            << std::format("{:pretty}\n", umm);

  std::cout << "\n=== Sequence Containers ===\n";

  std::array<int, 5> arr = {1, 2, 3, 4, 5};
  std::cout << "std::array: " << std::format("{}\n", arr);
  std::cout << "std::array pretty:\n" << std::format("{:pretty}\n", arr);

  std::deque<int> deq = {1, 2, 3, 4, 5};
  std::cout << "\nstd::deque: " << std::format("{}\n", deq);
  std::cout << "std::deque pretty:\n" << std::format("{:pretty}\n", deq);

  std::list<int> lst = {10, 20, 30};
  std::cout << "\nstd::list: " << std::format("{}\n", lst);
  std::cout << "std::list pretty:\n" << std::format("{:pretty}\n", lst);

  int carr[5] = {1, 2, 3, 4, 5};
  std::cout << "\nC-style array (via std::span): "
            << std::format("{}\n", std::span{carr});
  std::cout << "C-style array pretty:\n"
            << std::format("{:pretty}\n", std::span{carr});

  std::cout << "\n=== Container Adapters ===\n";

  std::stack<int> st;
  st.push(1);
  st.push(2);
  st.push(3);
  std::cout << "Stack: " << std::format("{}\n", st);
  std::cout << "Stack pretty:\n" << std::format("{:pretty}\n", st);

  std::queue<std::string> q;
  q.push("first");
  q.push("second");
  q.push("third");
  std::cout << "\nQueue: " << std::format("{}\n", q);
  std::cout << "Queue pretty:\n" << std::format("{:pretty}\n", q);

  std::priority_queue<int> pq;
  pq.push(30);
  pq.push(100);
  pq.push(20);
  std::cout << "\nPriority Queue: " << std::format("{}\n", pq);
  std::cout << "Priority Queue pretty:\n" << std::format("{:pretty}\n", pq);

  std::cout << "\n=== Complex Nested Types ===\n";

  std::map<std::string, std::vector<std::pair<int, std::string>>> complex = {
      {"group1", {{1, "a"}, {2, "b"}}}, {"group2", {{3, "c"}, {4, "d"}}}};
  std::cout << "Map of vector of pairs:\n" << std::format("{}\n", complex);
  std::cout << "Pretty:\n" << std::format("{:pretty}\n", complex);

  std::vector<std::set<int>> vec_of_sets = {{1, 2, 3}, {4, 5}, {6, 7, 8, 9}};
  std::cout << "\nVector of sets:\n" << std::format("{}\n", vec_of_sets);
  std::cout << "Pretty:\n" << std::format("{:pretty}\n", vec_of_sets);

  std::map<int, std::vector<std::string>> map_of_vecs = {
      {1, {"a", "b", "c"}}, {2, {"d", "e"}}, {3, {"f"}}};
  std::cout << "\nMap of vectors:\n" << std::format("{}\n", map_of_vecs);
  std::cout << "Pretty:\n" << std::format("{:pretty}\n", map_of_vecs);

  std::cout << "\n=== Edge Cases: Empty Containers ===\n";

  std::vector<int> empty_vec;
  std::cout << "Empty vector: " << std::format("{}\n", empty_vec);
  std::cout << "Empty vector pretty: " << std::format("{:pretty}\n", empty_vec);

  std::set<int> empty_set;
  std::cout << "Empty set: " << std::format("{}\n", empty_set);

  std::map<int, std::string> empty_map;
  std::cout << "Empty map: " << std::format("{}\n", empty_map);

  std::cout << "\n=== Edge Cases: Single Element ===\n";

  std::vector<int> single = {42};
  std::cout << "Single element: " << std::format("{}\n", single);
  std::cout << "Single element pretty:\n" << std::format("{:pretty}\n", single);
  std::cout << "Single with custom sep pretty:\n"
            << std::format("{:;:pretty}\n", single);

  std::cout << "\n=== Edge Cases: Special Characters in Separator ===\n";

  std::vector<std::string> words = {"Hello", "World", "Test"};
  std::cout << "Newline separator:\n" << std::format("{:\n}\n", words);
  std::cout << "Tab separator: " << std::format("{:\t}\n", words);
  std::cout << "Mixed separator: " << std::format("{: -> }\n", words);

  std::cout << "\n=== Edge Cases: Invalid Format Specs (fallback to "
               "default) ===\n";

  try {
    std::vector<int> fallback_test = {1, 2, 3};
    std::cout << "Format {::}: " << std::format("{::}", fallback_test) << "\n";
    std::cout << "Format {:a::b}: " << std::format("{:a::b}", fallback_test)
              << "\n";
    std::cout << "Format {:a:b:c}: " << std::format("{:a:b:c}", fallback_test)
              << "\n";
    std::cout << "All invalid specs handled gracefully (fallback to default)\n";
  } catch (const std::format_error &e) {
    std::cout << "Unexpected error: " << e.what() << "\n";
  }

  std::cout << "\n=== Using std::println() ===\n";

  std::println("Vector: {}", vec);
  std::println("Vector pretty:\n{:;:pretty}", vec);
  std::println("Map: {}", m);
  std::println("Nested: {}", nested2);

  std::cout << "\n=== Thread-Local State Verification ===\n";

  std::cout << "Setting indent to '>>>>'...\n";
  set_indent_string(">>>>");
  std::vector<std::vector<int>> thread_test = {{1, 2}, {3, 4}};
  std::cout << std::format("{:pretty}", thread_test) << "\n";

  std::cout << "Resetting indent...\n";
  reset_indent_string();
  std::cout << std::format("{:pretty}", thread_test) << "\n";

  std::cout << "\n=== Concept Validation ===\n";

  std::vector<int> valid_vec = {1, 2, 3};
  std::cout << "Valid vector: " << std::format("{}", valid_vec) << "\n";

  std::tuple<int, std::string, double> valid_tuple{42, "test", 3.14};
  std::cout << "Valid tuple: " << std::format("{}", valid_tuple) << "\n";

  // Uncommenting the following would produce a compile-time error:
  /*
  struct NonFormattable { int x; };
  std::vector<NonFormattable> invalid_vec = {{1}, {2}};
  std::cout << std::format("{}", invalid_vec) << "\n";
  // Error: No std::formatter specialization for NonFormattable
  */

  std::cout << "\nConcept validation passed!\n";
  std::cout << "\nV All tests completed successfully!\n";

  return 0;
}
