# libQt6Gui

This package contains the Qt6 GUI library and the plugins it uses.
