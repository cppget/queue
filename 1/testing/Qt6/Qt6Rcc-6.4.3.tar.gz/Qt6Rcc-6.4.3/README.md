# Qt6Rcc

This package contains the Qt6 resource compiler (`rcc`).
