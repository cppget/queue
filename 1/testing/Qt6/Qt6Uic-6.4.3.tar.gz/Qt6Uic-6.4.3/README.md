# Qt6Uic

This package contains the Qt6 user interface compiler (`uic`).
