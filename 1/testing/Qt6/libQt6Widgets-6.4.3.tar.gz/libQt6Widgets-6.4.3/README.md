# libQt6Widgets

This package contains the Qt6 Widgets library and the plugins it uses.
