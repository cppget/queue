#ifndef OPENSIM_COMMON_ABOUT_H_
#define OPENSIM_COMMON_ABOUT_H_
/* -------------------------------------------------------------------------- *
 *                            OpenSim:  About.h                               *
 * -------------------------------------------------------------------------- *
 * The OpenSim API is a toolkit for musculoskeletal modeling and simulation.  *
 * See http://opensim.stanford.edu and the NOTICE file for more information.  *
 * OpenSim is developed at Stanford University and supported by the US        *
 * National Institutes of Health (U54 GM072970, R24 HD065690) and by DARPA    *
 * through the Warrior Web program.                                           *
 *                                                                            *
 * Copyright (c) 2005-2018 Stanford University and the Authors                *
 * Author(s): Christopher Dembia                                              *
 *                                                                            *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may    *
 * not use this file except in compliance with the License. You may obtain a  *
 * copy of the License at http://www.apache.org/licenses/LICENSE-2.0.         *
 *                                                                            *
 * Unless required by applicable law or agreed to in writing, software        *
 * distributed under the License is distributed on an "AS IS" BASIS,          *
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   *
 * See the License for the specific language governing permissions and        *
 * limitations under the License.                                             *
 * -------------------------------------------------------------------------- */

#include "osimCommonDLL.h"

extern "C" {

OSIMCOMMON_API
    void opensim_version_common(int* major, int* minor, int* build);
OSIMCOMMON_API
    void opensim_about_common(const char* key, int maxlen, char* value);

}

#if defined(__cplusplus) || defined(SWIG)
#include <string>
namespace OpenSim {
OSIMCOMMON_API std::string GetVersionAndDate();
OSIMCOMMON_API std::string GetVersion();
OSIMCOMMON_API std::string GetOSInfoVerbose();
OSIMCOMMON_API std::string GetOSInfo();
OSIMCOMMON_API std::string GetCompilerVersion();
}
#endif

#endif // OPENSIM_COMMON_ABOUT_H_
