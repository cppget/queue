#ifndef OPENSIM_MOCOSTUDY_H
#define OPENSIM_MOCOSTUDY_H
/* -------------------------------------------------------------------------- *
 * OpenSim: MocoStudy.h                                                       *
 * -------------------------------------------------------------------------- *
 * Copyright (c) 2017 Stanford University and the Authors                     *
 *                                                                            *
 * Author(s): Christopher Dembia                                              *
 *                                                                            *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may    *
 * not use this file except in compliance with the License. You may obtain a  *
 * copy of the License at http://www.apache.org/licenses/LICENSE-2.0          *
 *                                                                            *
 * Unless required by applicable law or agreed to in writing, software        *
 * distributed under the License is distributed on an "AS IS" BASIS,          *
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.   *
 * See the License for the specific language governing permissions and        *
 * limitations under the License.                                             *
 * -------------------------------------------------------------------------- */

#include "MocoSolver.h"
#include "MocoProblem.h"
#include "MocoUtilities.h"

#include <OpenSim/Common/Object.h>
#include <OpenSim/Simulation/Model/Model.h>

namespace OpenSim {

class MocoProblem;
class MocoCasADiSolver;

/** The top-level class for solving a custom optimal control problem.

This class consists of a MocoProblem, which describes the optimal control
problem, and a MocoSolver, which describes the numerical method for
solving the problem.

Workflow
========
When building a MocoStudy programmatically (e.g., in C++), the workflow is
as follows:

1. Build the MocoProblem (set the model, constraints, etc.).
2. Call MocoStudy::initSolver(), which returns a reference to the
MocoSolver.
   After this, you cannot edit the MocoProblem.
3. Edit the settings of the MocoSolver (returned by initSolver()).
4. Call MocoStudy::solve(). This returns the MocoSolution.
5. (Optional) Postprocess the solution, perhaps using
MocoStudy::visualize().

After calling solve(), you can edit the MocoProblem and/or the MocoSolver.
You can then call solve() again, if you wish.

Obtaining the solution
----------------------
The most common way to obtain the MocoStudy is in code, using the MocoSolution
object returned by solve(). This norm differs from the behavior of OpenSim's
other tools, which do not make their results available in code and instead write
their results to file. If you want MocoStudy to write the solution to file at
the end of solve(), use set_write_solution() and set_results_directory(). The
name of the solution file is "<study-name>_solution.sto" or
"MocoStudy_solution.sto" if the MocoStudy object has no name. Alternatively, you
can write the solution to file yourself:

@code
MocoSolution solution = study.solve();
solution.write("solution.sto");
@endcode

Saving the study setup to a file
--------------------------------
You can save the MocoStudy to a file by calling MocoStudy::print(), and you
can load the setup using MocoStudy(const std::string& omocoFile).
MocoStudy setup files have a `.omoco` extension.

Solver
------
The default solver, MocoCasADiSolver, uses the **CasADi** automatic
differentiation and optimization library. We would like to
support users plugging in their own solvers, but there is no timeline for this.
*/
class OSIMMOCO_API MocoStudy : public Object {
    OpenSim_DECLARE_CONCRETE_OBJECT(MocoStudy, Object);

public:
    OpenSim_DECLARE_PROPERTY(write_solution, bool,
            "Should the solution be written to a file at the end of solving "
            "the problem? Default: false.");
    OpenSim_DECLARE_PROPERTY(results_directory, std::string,
            "Provide the folder path (relative to working directory) to which "
            "the solution file should be written. Default: './'.");

    MocoStudy();

    /// Load a MocoStudy setup file.
    MocoStudy(const std::string& omocoFile);

    /// Access the MocoProblem within this study.
    const MocoProblem& getProblem() const;

    /// Access the MocoProblem within this study. This function allows you to
    /// modify the MocoProblem.
    /// If using this method in C++, make sure to include the "&" in the
    /// return type; otherwise, you'll make a copy of the problem, and the copy
    /// will have no effect on this MocoStudy. See this example:
    /// @code{.cpp}
    /// MocoProblem& problem = study.updProblem();
    /// @endcode
    MocoProblem& updProblem();

    /// Call this method once you have finished setting up your MocoProblem.
    /// This returns a reference to the MocoSolver, which you can then edit.
    /// If using this method in C++, make sure to include the "&" in the
    /// return type; otherwise, you'll make a copy of the solver, and the copy
    /// will have no effect on this MocoStudy.
    /// This deletes the previous solver if one exists.
    MocoCasADiSolver& initCasADiSolver();

    /// Access the solver. Make sure to call `initSolver()` beforehand.
    /// If using this method in C++, make sure to include the "&" in the
    /// return type; otherwise, you'll make a copy of the solver, and the copy
    /// will have no effect on this MocoStudy.
    MocoSolver& updSolver();

    /// Solve the provided MocoProblem using the provided MocoSolver, and obtain
    /// the solution to the problem. If the write_solution property is true,
    /// then the solution is also written to disk in the directory specified in
    /// the results_directory property.
    /// @precondition
    ///     You must have finished setting up both the problem and solver.
    /// This reinitializes the solver so that any changes you have made will
    /// hold.
    ///
    /// Use MocoSolution::success() on the returned solution to detect if the
    /// solver succeeded. If the solver did not succeed the solution will be
    /// sealed: you will not be able to use the failed solution
    /// until you acknowledge the failure by invoking MocoSolution::unseal().
    MocoSolution solve() const;

    /// Interactively visualize a trajectory using the simbody-visualizer. The
    /// trajectory could be an initial guess, a solution, etc.
    /// @precondition
    ///     The MocoProblem must contain the model corresponding to
    ///     the provided trajectory.
    void visualize(const MocoTrajectory& traj) const;

    /// Calculate the requested outputs using the model in the problem and the
    /// states and controls in the MocoTrajectory.
    /// The output paths can be regular expressions. For example,
    /// ".*activation" gives the activation of all muscles.
    /// Constraints are not enforced but prescribed motion (e.g.,
    /// PositionMotion) is.
    /// @see OpenSim::analyze<T>() OpenSim::analyzeMocoTrajectory<T>()
    /// @note Parameters in the MocoTrajectory are **not** applied to the model.
    /// @note If the MocoTrajectory was generated from a MocoStudy with 
    ///       Controller%s in the model, first call 
    ///       MocoTrajectory::generateControlsFromModelControllers() to populate 
    ///       the trajectory with the correct model controls.
    template <typename T>
    TimeSeriesTable_<T> analyze(const MocoTrajectory& traj,
            const std::vector<std::string>& outputPaths) const {
        return OpenSim::analyzeMocoTrajectory<T>(
            get_problem().createRep().getModelBase(), traj, outputPaths);
    }

    // @copydoc analyze()
    TimeSeriesTable analyze(const MocoTrajectory& traj,
            const std::vector<std::string>& outputPaths) const {
        return analyze<double>(traj, outputPaths);
    }

    /// Compute the generalized coordinate forces for the provided trajectory 
    /// based on a set of applied model Force%s. This can be used to compute 
    /// an inverse dynamics solution from a MocoTrajectory, where the applied 
    /// model Force%s are typically external forces in the system (e.g., 
    /// ExternalForce or SmoothSphereHalfSpaceForce). However, the `forcePaths`
    /// argument can contain paths to any Force%s in the model.
    ///
    /// @param traj       The MocoTrajectory for which to compute the 
    ///                   generalized forces.
    /// @param forcePaths The model paths to the Force%s which will be applied
    ///                   to the model to compute the generalized forces.
    ///
    /// @note Force's `appliesForce` property is obeyed when calculating the
    ///       generalized forces.
    ///
    /// @pre The MocoProblem must contain the model corresponding to the 
    ///      provided trajectory.
    TimeSeriesTable calcGeneralizedForces(const MocoTrajectory& traj,
            const std::vector<std::string>& forcePaths) const;

    /// @name Using other solvers
    /// @{
    template <typename SolverType>
    void setCustomSolver() {
        set_solver(SolverType());
    }

    /// @precondition If not using MocoCasADiSolver, you must invoke 
    /// setCustomSolver() first.
    template <typename SolverType>
    SolverType& initSolver() {
        return dynamic_cast<SolverType&>(initSolverInternal());
    }

    template <typename SolverType>
    SolverType& updSolver() {
        return dynamic_cast<SolverType&>(upd_solver());
    }
    /// @}

protected:
    OpenSim_DECLARE_PROPERTY(
            problem, MocoProblem, "The optimal control problem to solve.");
    OpenSim_DECLARE_PROPERTY(solver, MocoSolver,
            "The optimal control algorithm for solving the problem.");

private:
    void initSolverInternal() const;
    void constructProperties();
};

template <>
OSIMMOCO_API MocoCasADiSolver& MocoStudy::initSolver<MocoCasADiSolver>();

} // namespace OpenSim

#endif // OPENSIM_MOCOSTUDY_H
