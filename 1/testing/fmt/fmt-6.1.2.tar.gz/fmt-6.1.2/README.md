`{fmt}` library - Build2 package
================================

This is the source code for the build2 package of the `{fmt}` C++ library.

 - Build2 : https://build2.org
 - `{fmt}` : https://github.com/fmtlib/fmt/

Currently, the tests from the library are not built (it requires a lot of work to make them work because they depend on gmock).
As a basic test we just try to use the library in an executable using code from the readme of this version.

See ./upstream/Readme.rst for the library's details.
