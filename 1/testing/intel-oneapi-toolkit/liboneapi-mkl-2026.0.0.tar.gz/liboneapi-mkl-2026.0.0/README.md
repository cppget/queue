# liboneapi-mkl - Intel oneAPI Math Kernel Library

> **NOTE:**  
This package is not open source and does not contain any source code. Instead,
in order to "build" the exported target(s) it downloads (potentially large)
pre-built binaries provided by Intel for the target platform.
>
> CI for this package is disabled due to the above.  
Supported platforms/compilers are Windows/MSVC and Linux.

This is a `build2` package for the [Intel oneAPI Math Kernel Library
(oneMKL)](https://www.intel.com/content/www/us/en/developer/tools/oneapi/onemkl.html)
C++ library. It provides highly optimized routines for linear algebra (BLAS,
LAPACK), discrete Fourier transforms, vector mathematics, and sparse solvers,
shipped as dynamically dispatched shared libraries that select the best
computational kernel for the detected hardware at runtime.


## Usage

To start using `liboneapi-mkl` in your project, add the following `depends`
value to your `manifest`, adjusting the version constraint as appropriate:

```
depends: liboneapi-mkl ^2026.0.0
```

Then import the library in your `buildfile`:

```
import libs = liboneapi-mkl%libs{mkl}
```


## Linking strategies

MKL supports two mutually exclusive linking strategies.

**SDL (Single Dynamic Library):** Link only `libs{mkl}`. The runtime
library dispatches to the appropriate computational kernels automatically.
Use this for BLAS, LAPACK, DFT, and VML. ScaLAPACK and BLACS are not
available in SDL mode.

**Layered:** Link an interface layer, a threading layer, and core
explicitly. Use this when you need to control the threading layer or when
using ScaLAPACK. Import and compose the targets you need:

```
import libs += liboneapi-mkl%libs{mkl-lp64}       \
               liboneapi-mkl%libs{mkl-thread-seq}

exe{myapp}: ... $libs
```

For ScaLAPACK with Intel MPI (lp64 interface, sequential threading):

```
import libs += liboneapi-mkl%libs{mkl-lp64}                  \
               liboneapi-mkl%libs{mkl-thread-seq}            \
               liboneapi-mkl%libs{mkl-cluster-lp64-intelmpi}

exe{myapp}: ... $libs
```

The threading target (`mkl-thread-seq`, `mkl-thread-intel`, etc.) brings
in `mkl-core` transitively. The cluster target (`mkl-cluster-lp64-*`)
brings in ScaLAPACK and BLACS, and the interface layer (`mkl-lp64`)
transitively.


## Importable targets

This package provides the following importable targets:

```
# Single Dynamic Library (SDL)
libs{mkl}

# Layered: interface layer (pick one)
libs{mkl-lp64}
libs{mkl-ilp64}
libs{mkl-gf-lp64}                  (Linux only)
libs{mkl-gf-ilp64}                 (Linux only)

# Layered: threading layer (pick one)
libs{mkl-thread-seq}
libs{mkl-thread-intel}
libs{mkl-thread-gnu}               (Linux only)
libs{mkl-thread-tbb}

# Layered: ScaLAPACK
libs{mkl-cluster-lp64}
libs{mkl-cluster-lp64-intelmpi}
libs{mkl-cluster-lp64-openmpi}     (Linux only)
libs{mkl-cluster-lp64-msmpi}       (Windows only)
libs{mkl-cluster-ilp64}
libs{mkl-cluster-ilp64-intelmpi}
libs{mkl-cluster-ilp64-openmpi}    (Linux only)
libs{mkl-cluster-ilp64-msmpi}      (Windows only)

# Pulled in transitively, rarely imported directly
libs{mkl-core}
libs{mkl-dispatch}
libs{mkl-imalloc}                  (Windows only)

# SYCL
libs{mkl-sycl}
```


## Configuration variables

This package provides the following configuration variables:

```
[dir_path] config.liboneapi_mkl.cache ?= $out_root
```

The directory used to cache downloaded binary archives between builds. If
`config.liboneapi.cache` is set (a shared project-wide cache directory), it
takes precedence over the per-package default of `$out_root`.
