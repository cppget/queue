// Portable stub for avx512_bc1ComputeBestEndpoints when the AVX-512 TU is
// not compiled. bc1_cmp.h takes the address of this symbol unconditionally.

#include "core_simd.h"

#include <cstdlib>

float
avx512_bc1ComputeBestEndpoints (float*, float*, float*, float*, float*, int, int)
{
  std::abort ();
}
