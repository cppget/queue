// Portable stub for sse_bc1ComputeBestEndpoints when the SSE TU is not
// compiled. bc1_cmp.h takes the address of this symbol unconditionally.

#include "core_simd.h"

#include <cstdlib>

float
sse_bc1ComputeBestEndpoints (float*, float*, float*, float*, float*, int, int)
{
  std::abort ();
}
