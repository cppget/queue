// Portable stub for avx_bc1ComputeBestEndpoints when the AVX TU is not
// compiled. bc1_cmp.h takes the address of this symbol unconditionally.

#include "core_simd.h"

#include <cstdlib>

float
avx_bc1ComputeBestEndpoints (float*, float*, float*, float*, float*, int, int)
{
  std::abort ();
}
