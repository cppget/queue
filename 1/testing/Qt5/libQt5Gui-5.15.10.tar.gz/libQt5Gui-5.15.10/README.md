# libQt5Gui

This package contains the Qt5 GUI library.
