# libQt5Widgets

This package contains the Qt5 Widgets library.
