# strong_type-tests

Just tests for strong_type lib.
