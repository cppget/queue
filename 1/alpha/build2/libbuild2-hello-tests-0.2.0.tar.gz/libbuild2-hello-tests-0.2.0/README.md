# libbuild2-hello-tests

Tests package for the test build system module for `build2`.
