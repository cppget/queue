// file      : bbot/diagnostics.cxx -*- C++ -*-
// copyright : Copyright (c) 2014-2019 Code Synthesis Ltd
// license   : TBC; see accompanying LICENSE file

#include <bbot/diagnostics.hxx>

#include <bbot/utility.hxx>

using namespace std;
using namespace butl;

namespace bbot
{
  // Diagnostics verbosity level.
  //
  uint16_t verb;

  // Diagnostic facility, project specifics.
  //

  void simple_prologue_base::
  operator() (const diag_record& r) const
  {
    if (type_ != nullptr)
      r << type_;

    if (name_ != nullptr)
      r << name_;

    if (data_ != nullptr)
      r << '(' << data_ << ')';

    if (name_ != nullptr || data_ != nullptr)
      r << ": ";
  }

  const char* trace_type = "trace: ";
  const char* trace_indent = "\n  ";

  trace_mark_base::
  trace_mark_base (const char* name, const char* data)
      : basic_mark_base (trace_type, trace_indent, name, data)
  {
  }

  basic_mark error ("error: ");
  basic_mark warn  ("warning: ");
  basic_mark info  ("info: ");
  basic_mark text  (nullptr);
  fail_mark  fail  ("error: ");

  const fail_end endf;

  // We used the right arrow Unicode character to signal line continuation.
  // It only looked cute when displayed properly.
  //
  const char systemd_indent[] = " \\\n";

  void
  systemd_diagnostics (bool with_critical)
  {
    trace_indent    =
      fail.indent_  =
      error.indent_ =
      warn.indent_  =
      info.indent_  =
      text.indent_  = systemd_indent;

    // We don't always see colorized output so keep 'error: ', etc.
    //
    fail.type_  = with_critical ? "<2>fatal: " : "<3>error: ";
    error.type_ = "<3>error: ";
    warn.type_  = "<4>warning: ";
    info.type_  = "<6>";
    trace_type  = "<7>";
  }

  // tracer
  //
  void tracer::
  operator() (const char* const args[], size_t n) const
  {
    if (verb >= 3)
    {
      diag_record dr (*this);
      process::print (dr.os, args, n);
    }
  }
}
