// file      : bdep/options-types.hxx -*- C++ -*-
// copyright : Copyright (c) 2014-2019 Code Synthesis Ltd
// license   : MIT; see accompanying LICENSE file

#ifndef BDEP_OPTIONS_TYPES_HXX
#define BDEP_OPTIONS_TYPES_HXX

namespace bdep
{
}

#endif // BDEP_OPTIONS_TYPES_HXX
