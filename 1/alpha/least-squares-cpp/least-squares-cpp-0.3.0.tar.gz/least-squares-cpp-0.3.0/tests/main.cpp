/// main.cpp
///
/// Author:     Fabian Meyer
/// Created on: 18 Jun 2018
/// License:    MIT

#define CATCH_CONFIG_MAIN
#include <catch2/catch.hpp>
