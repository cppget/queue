A "Hello, World!" is an introductory computer program.
