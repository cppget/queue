Project depends on these following dependencies:

libsqlite3

