#include "globals.hxx"

namespace trash {


} //namespace trash