# hello-b2

C++ executable
