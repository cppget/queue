# magic_enum

See [`magic_enum` documentation](https://github.com/Neargye/magic_enum/tree/master/doc) for usage and details and
limitations.

 - spdlog: https://github.com/Neargye/magic_enum
 - Build2: https://build2.org

Note: This is the source code for the build2 package of the `magic_enum` C++ library,
the actual library sources snapshot can be found in the `./upstream/` submodule.
